The scanpath data compared in Foulsham and Underwood (2008) and Foulsham et al., (under review) is now available for other researchers here. The text file lists the coordinates and duration of fixations made by 21 participants viewing 45 images on two occasions. The same data is also included as a MATLAB file. If you use this data please cite it's original source (Foulsham & Underwood, 2008).

See also https://sites.google.com/site/tomfoulshamresearch/research/scanpaths

Tom Foulsham, 2012
foulsham@essex.ac.uk

CONTENTS

*FoulshamScanpathData.txt

This is a tab-delimited text file containing the scanpath data. Each row contains the details of a fixation. Rows are organised by participant, image and viewing condition (i.e., "encoding" or "test"). For example, there are 14 fixations from participant 5 viewing image 34 at encoding. The scanpath for the same participant viewing the same image at test can be found further down the list (11 fixations).

*FoulshamScanpathData.mat

This contains the same data as a MATLAB variable. Each scanpath is a structure within a 21 x 45 array. For example, the scanpaths from participant 5 viewing image 34 are at 

DataByParticipantImage(5,34).encodingFixations and
DataByParticipantImage(5,34).testFixations

For each fixation in the above there is an x and y coordinate (within an image space of 1024 x 768 pixels) and a duration (in ms).