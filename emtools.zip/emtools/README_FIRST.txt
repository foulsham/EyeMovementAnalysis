INSTALLING/RUNNING EMTOOLS

SYSTEM REQUIREMENTS

EMTools is written in Java and requires the standard Java Runtime Environment to run.  
To compile the programs from source you will also need the Java Development Kit.
Finally, the program directories includes the Java Advanced Imaging extension.  
The programs will run on both PC (Windows) and Mac OS, provided that a recent Java package has been installed.  
Java comes as standard on Mac OS 10.x.  On Windows, it needs to be installed.  
The easiest way to check if you already have it is to open a command prompt and type "java -version".  
This will show you the version of the Java on your system.  If the command is not recognised, you'll need to install Java (see java.com).  
The installation process also assumes that you have the classpath set up correctly to point to your java libraries.

INSTALLATION

Two pairs of batch files are included in the main "/emtools" directory.  

On Windows: To launch the main menu, simply double click "run_emtools.bat".  If this doesn't work, or if you would like to compile the program from source, 
run the "compile_emtools.bat" file, and then try to run it again.

On Mac OS: Double click "compile_mac.command" and/or "run_mac.command".


If the batch files do not work, you may have to run the program yourself from the command line.  
Change to the "emtools/classes" directory and then type "java emtools.gui.MainMenu" to launch (for the full command line options, 
see the text in the batch files).




