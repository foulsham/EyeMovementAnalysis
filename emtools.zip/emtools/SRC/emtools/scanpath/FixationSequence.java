	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

// A general class for a sequence of fixations
package emtools.scanpath;

import java.awt.*;
import java.util.*;
import java.lang.Math;
import java.io.*;
import emtools.gui.*;

public class FixationSequence 
{
	public Vector <Point> fixations=new Vector <Point> (); //the x,y locations of each fixation are stored in a vector which will grow as you add items
	public String fname;//a name for the set, e.g. a trial filename
	
	public String getSp()
	//a method to return the scanpath coordinates as a string
	{
		String temp="";
		for(int i=0;i<fixations.size();i++)
		{
		temp=(temp + "( " + fixations.elementAt(i).x + " , " + fixations.elementAt(i).y + " ) , ");	
		}
		System.out.println(temp);
		return temp;
	}
	
	public String getScanpathString(DisplayProps props)
	//a method to return a series of characters representing the scanpath, according to the grid specified in the display props
	{
		String temp="";
		
		//first define the letters using a 2d array
		char [][] gridChars=new char [props.gridx][props.gridy];
		int charIndex=65;
		for(int y=0;y<props.gridy;y++)
		{
			for(int x=0;x<props.gridx;x++)
			{
				gridChars[x][y]=(char)charIndex;
				charIndex++; //move to the next char along
			//	System.out.print(gridChars[x][y]);
			}
		//System.out.println();				
		}
		
		//how big is each region? use double precision to reduce overflows
		double xreg=(double)(props.imagex/props.displayZoom)/(double)props.gridx;
		double yreg=(double)(props.imagey/props.displayZoom)/(double)props.gridy;
		//System.out.println(xreg+" x "+yreg);
		
		//then, for each fixation get the correct row and column, and return the char
		for(int i=0;i<fixations.size();i++)
		{			
			double col=fixations.elementAt(i).x / xreg;
			double row=fixations.elementAt(i).y / yreg;
			//System.out.println(col+" x "+row);
			//now adds a question mark if out of range
			if ( (((int)col) >= props.gridx) || (((int)row) >= props.gridy) || (((int)col) < 0) || (((int)row) < 0) )
			{
			temp=temp+"?";	
			}
			else
			{
			//System.out.println(fixations.elementAt(i).x+" x "+fixations.elementAt(i).y);
			//
			temp=temp+gridChars[(int)col][(int)row];	
			}
			//System.out.println(temp);
		}
		return temp;
	}
	
	public void zoomCoords(DisplayProps props)
	//a method which will transform the coordinates of the fixation sequence by zooming with the zoom factor in the properties argument
	{
		Point p;
		for(int i=0;i<fixations.size();i++)
		//for each fixation, scale the coordinates and replace the Point variable
		{
			p=new Point (fixations.elementAt(i).x/props.displayZoom,fixations.elementAt(i).y/props.displayZoom);
			fixations.setElementAt(p,i);
		}		
	}	
	
	public void zoomCoords(int zf)
	//a method which will transform the coordinates of the fixation sequence by zooming with the zoom factor in the properties argument
	{
		Point p;
		for(int i=0;i<fixations.size();i++)
		//for each fixation, scale the coordinates and replace the Point variable
		{
			p=new Point (fixations.elementAt(i).x/zf,fixations.elementAt(i).y/zf);
			fixations.setElementAt(p,i);
		}		
	}	
	
	public void fillRandom(int length, int x, int y)
	//a method to fill the fixation sequence with randomly generated fixations
	// length gives the length of the scanpath, if <=0 then will randomly choose between 1 and 20
	//x and y are screen dimensions
	{
		if(length <= 0)
		{
			length = (int)(19*java.lang.Math.random())+1;
		}
		
		for(int i=0; i<length; i++)
		{
			fixations.add(new Point((int)(x*java.lang.Math.random()),(int) (y*java.lang.Math.random())));
		}
	}
	
	public void printToFile(RandomAccessFile r)
	//a method which prints the fixations to the file argument
	{
		try
		{
			for(int f=0;f<fixations.size();f++)
			{
				if(fname!=null)
				{
				r.writeBytes(fname+"\t");	
				}	
				r.writeBytes((f+1)+"\t");
				r.writeBytes(fixations.elementAt(f).x+"\t");					
				r.writeBytes(fixations.elementAt(f).y+"\n");
			}
		}	
		
		catch (IOException e) // NB remember the error handling.
		{
		  System.out.println("An i/o error has occurred ["+e+"]");
		}			
	}
	
     public static void main(String[] args) 
     {
	    FixationSequence testA=new FixationSequence();
	    FixationSequence testB=new FixationSequence();
	    testA.fixations.add(new Point(256,196));
	    testA.getSp();
		testA.getScanpathString(new DisplayProps(1));
	    testB.getSp();
		testB.getScanpathString(new DisplayProps(1));	
	    testB.fixations.add(new Point(100,100));
	    testA.getSp();
		testA.getScanpathString(new DisplayProps(1));
	    testB.getSp();
		testB.getScanpathString(new DisplayProps(1));
			
    }	
}
