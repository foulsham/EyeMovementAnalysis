	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

// A class which holds two fixation sequences, and various methods for comparing them
// NB. Unique assignment method requires PermutationGenerator class

package emtools.scanpath;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.lang.Math;
import java.io.*;
import emtools.gui.*;

public class ScanpathComparison 
{
	public FixationSequence spA, spB;	//the to-be-compared scanpaths
	public static String a,b; //the strings can be stored for convenience
	
	public JFrame scf; //a frame and labels to display the comparison
	JTextArea output; 
	JLabel [] lbls;
	
	//variables to log the computed similarity measures
	public double sd,sdNorm,sdSim;
	public double md,rmd,mSim;
	public double uad,ruad,uaSim;
	public int[] uaNearestArray;	
	public double wd,wdNorm,wdSim;
	
	public ScanpathComparison(FixationSequence fsA, FixationSequence fsB)
	//constructor, has to have two FixationSequence arguments
	{
		spA=fsA;
		spB=fsB;	
	}
	
	public int[] getSizes()
	//convenience method to return both sizes easily
	{
		int[] rv=new int[2];
		rv[0]=spA.fixations.size();
		rv[1]=spB.fixations.size();
		return rv;		
	}
	
	public void getStrings(int x,int y,int gridx, int gridy)
	//convenience method to set the strings
	//requires dimensions of image and grid
	{
		//put all info in properties class
		DisplayProps props=new DisplayProps(1);
		props.imagex=x;
		props.imagey=y;
		props.gridx=gridx;
		props.gridy=gridy;
		props.displayZoom=1;
		
		//get strings using fixation sequence method
		a=spA.getScanpathString(props);
		b=spB.getScanpathString(props);			
	}	
	
	public void trimScanpaths(int min,int max, boolean makeEqual)
	//method to trim the sequences
	//last argument specifies whether scanpaths are made the same size (by setting max to length of shorter string)
	{
		//loop through the fixations, and add them to temp only if within bounds
		FixationSequence temp = new FixationSequence();
		for (int i=0;i<spA.fixations.size();i++)
		{
			if	( (i >= min) && (i <= max) )
			{
			temp.fixations.add(spA.fixations.elementAt(i));	
			}
		}
		spA=temp;
		FixationSequence temp2 = new FixationSequence();
		for (int i=0;i<spB.fixations.size();i++)
		{
			if	( (i >= min) && (i <= max) )
			{
			temp2.fixations.add(spB.fixations.elementAt(i));	
			}
		}		
		spB=temp2;
		FixationSequence temp3 = new FixationSequence();
		
		//if scanpaths are different in size, and if required, make them equal
		if( ( getSizes()[0] != getSizes()[1] ) && makeEqual )
		{
			//find the (trimmed) length of the smaller scanpath then crop the larger to this
			int cropTo;
			if( getSizes()[0] > getSizes()[1] )
			{
				cropTo = getSizes()[1];
				for (int i=0;i<cropTo;i++)
				{
					temp3.fixations.add(spA.fixations.elementAt(i));	
				}
				spA=temp3;				
			}
			else
			{
				cropTo = getSizes()[0];
				for (int i=0;i<cropTo;i++)
				{
					temp3.fixations.add(spB.fixations.elementAt(i));	
				}
				spB=temp3;				
			}			
		}										
	}
	
	public void condenseStrings()
	//method which collapses local fixations into one
	//if consecutive fixations (characters) are the same then combine
	{
		String temp = "" + a.charAt(0);	//set the string to the first letter
		for (int c=1;c<a.length();c++)
		{
			if( a.charAt(c) != a.charAt(c-1) )	
			{
			temp=temp+a.charAt(c);	//add subsequent letters only if different
			}
		}
		a=temp;

		temp = "" + b.charAt(0);	//set the string to the first letter
		for (int c=1;c<b.length();c++)
		{
			if( b.charAt(c) != b.charAt(c-1) )	
			{
			temp=temp+b.charAt(c);	//add subsequent letters only if different
			}
		}
		b=temp;				
	}	
	
	public void trimStrings(int min,int max, boolean makeEqual)
	//a separate method for trimming strings
	{
		a=a.substring(min);
		b=b.substring(min);
		if( a.length()>max )
		{
		a=a.substring(0,max);	
		}
		else
		{
		a=a.substring(0,a.length());	
		}
		if( b.length()>max )
		{
		b=b.substring(0,max);	
		}
		else
		{
		b=b.substring(0,b.length());	
		}		
		
		if ( makeEqual && b.length() > a.length() )
		{
			b=b.substring(0,a.length());
		}
		if ( makeEqual && a.length() > b.length() )
		{
			a=a.substring(0,b.length());
		}		
	}	
	
	public void showComparisonFrame(int h)
	//a method which will display a frame for listing comparison stats
	{
		JPanel mainPanel=new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		JPanel labelPanel=new JPanel();
		labelPanel.setLayout(new GridLayout(5,2,5,5));
		labelPanel.setPreferredSize(new Dimension(250, 250));
		
		output=new JTextArea ();
        output.setEditable(false);	
        output.setMargin(new Insets(5,5,5,5));    
	    output.setCaretPosition(0);
		output.setLineWrap(true);
		output.setWrapStyleWord(true);	
		    
        JScrollPane sPane = new JScrollPane(output);
        sPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);		
		sPane.setPreferredSize(new Dimension(250, h - 250));
		
		lbls=new JLabel[10];
		for(int l=0;l<10;l++)
		{
			lbls[l]=new JLabel();
			lbls[l].setHorizontalAlignment(SwingConstants.CENTER);
			labelPanel.add(lbls[l]);
		}
		lbls[2].setText("String edit similarity");
		lbls[4].setText("Mannan similarity");
		lbls[6].setText("UA similarity");	
		lbls[8].setText("Weighted similarity");	
		
		mainPanel.add(sPane);
		mainPanel.add(labelPanel);
		
		//set up and display the frame
		scf=new JFrame("Scanpath comparison");
		scf.setContentPane(mainPanel);
		scf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		scf.pack();
		scf.setVisible(true);
	}
	
	public void doComparison(DisplayProps props)
	//a method which will actually do the comparison
	{
		java.text.DecimalFormat f = new java.text.DecimalFormat("###.#####");
		a=spA.getScanpathString(props);
		b=spB.getScanpathString(props);	
				
		//begin the comparisons by printing the strings
		output.append("Scanpath A: " + spA.getSp() + "\n");
		output.append("String A: " + a + "\n" + "\n");
		output.append("Scanpath B: " + spB.getSp() + "\n");
		output.append("String B: " + b + "\n" + "\n");
		lbls[0].setText(a);
		lbls[0].setForeground(props.sac1col);
		lbls[1].setText(b);
		lbls[1].setForeground(props.sac2col);
		
		//string edit distance
		output.append("STRING EDIT DISTANCE..." + "\n" + "\n");
		stringEditDistance();
		output.append("   " + "...Edits required: " + f.format(sd) + "\n");
		output.append("   " + "...Normalised distance: " + f.format(sdNorm) + "\n");
		output.append("   " + "...Similarity: " + f.format(sdSim) + "\n" + "\n");
		lbls[3].setText(f.format(sdSim));
		
		//Mannan distance
		output.append("MANNAN DISTANCE..." + "\n" + "\n");
		mannanDistance(props.imagex/props.displayZoom, props.imagey/props.displayZoom);
		output.append("   " + "...Mean normalised distance between fixations: " + f.format(md) + "\n");
		output.append("   " + "...Retrieving mean randomly generated distance: ");
		//get the drand value from a text file resource (only goes up to 50 x 50)
			if( (spA.fixations.size()>50) || (spB.fixations.size()>50) )
			{
			rmd=retrieveCell(50,50,"/../resources/drand.txt");
			output.append("\n" + "scanpaths are bigger than largest random estimate, returning DRAND for 50 x 50... ");	
			}
			else
			{
			rmd=retrieveCell(spA.fixations.size(),spB.fixations.size(),"/../resources/drand.txt");	
			}		
		output.append(f.format(rmd) + "\n");
		mSim=(1-(md/rmd))*100;	
		output.append("   " + "...Similarity index: " + f.format(mSim) + "\n" + "\n");				
		lbls[5].setText(f.format(mSim));
		
		//Unique assignment distance
		output.append("UNIQUE ASSIGNMENT DISTANCE..." + "\n" + "\n");
		//check scanpaths are same size
		if(spA.fixations.size() != spB.fixations.size())
		{
			output.append("Not computing UA distance (scanpaths are not the same size)...." + "\n"+ "\n");
		}
		else
		{
		uaDistance(props.imagex/props.displayZoom, props.imagey/props.displayZoom);
		output.append("   " + "...Smallest mean normalised distance between fixations: " + f.format(uad) + "\n");
		output.append("   " + "...Combination with smallest distance: ");
			for(int i=0;i < spA.fixations.size(); i++)
			{
				output.append("A" + (i+1) + " vs. B" + (uaNearestArray[i]+1) + " ");
			}
		output.append("\n" + "   " + "...Retrieving mean randomly generated distance: ");
		//get the drand value from a text file resource (only goes up to 50 x 50)
			if( (spA.fixations.size()>50) || (spB.fixations.size()>50) )
			{
			ruad=retrieveCell(50,50,"/../resources/uadrand.txt");
			output.append("\n" + "scanpaths are bigger than largest random estimate, returning DRAND for 50 x 50... ");	
			}
			else
			{
			ruad=retrieveCell(spA.fixations.size(),spB.fixations.size(),"/../resources/uadrand.txt");	
			}		
		output.append(f.format(ruad) + "\n");
		uaSim =(1-(uad/ruad))*100;	
		output.append("   " + "...Similarity index: " + f.format(uaSim) + "\n" + "\n");		
		lbls[7].setText(f.format(uaSim));
		}
		
		//Unique assignment distance
		output.append("LINEAR DISTANCE WEIGHTED STRING EDIT DISTANCE..." + "\n" + "\n");	
		weightedEditDistance(props.imagex/props.displayZoom, props.imagey/props.displayZoom);	
		output.append("   " + "...Total weighted distance: " + f.format(wd) + "\n");
		output.append("   " + "...Normalised weighted distance: " + f.format(wdNorm) + "\n");
		output.append("   " + "...Similarity: " + f.format(wdSim) + "\n");
		lbls[9].setText(f.format(wdSim));
		
	}
	
	public double stringEditDistance()
	{
	  //*****************************
	  // Compute Levenshtein distance
	  //*****************************
	  //based on code at http://www.merriampark.com/ld.htm
	
	  int d[][]; // matrix
	  int n; // length of first
	  int m; // length of second
	  int i; // iterates through first
	  int j; // iterates through second
	  char s_i; // ith character of first
	  char t_j; // jth character of second
	  int cost; // cost
	
	    // Step 1: if either string is empty, distance is length of the other
	    n = a.length ();
	    m = b.length ();
	    if (n == 0) 
	    {
	      sd = m;
	      return sd;
	    }
	    if (m == 0) 
	    {
	      sd = n;	      
	      return sd;
	    }

	    d = new int[n+1][m+1];
	
	    // Step 2: set the first row/column to integers ascending from 1		
	    for (i = 0; i <= n; i++) 
	    {
	      d[i][0] = i;
	    }		
	    for (j = 0; j <= m; j++) 
	    {
	      d[0][j] = j;
	    }
	
	    // Step 3: loop through the first string		
	    for (i = 1; i <= n; i++) 
	    {		
	      s_i = a.charAt (i - 1);
	
	      // Step 4: loop through the second string		
	      for (j = 1; j <= m; j++) 
	      {		
	        t_j = b.charAt (j - 1);
	
	        // Step 5: compare the two characters		
	        if (s_i == t_j) 
	        {
	          cost = 0;
	        }
	        else 
	        {
	          cost = 1;	//cost for unequal characters is 1
	        }
	
	        // Step 6: set the current cell
	        d[i][j] = findlowest (d[i-1][j]+1, d[i][j-1]+1, d[i-1][j-1] + cost);		
	      }		
	    }
	
	    // Step 7: distance is bottom left cell
	    sd = d[n][m];
	
		//Step 8: normalise the distance over the length of the longer string
       	if (n>=m){sdNorm = sd/n;}
    	else {sdNorm = sd/m;}
    	    	
    	//similarity is 1 minus the normalised distance
    	sdSim = 1-sdNorm;
    	return sd;	
	}
	
    public int findlowest(int int1,int int2,int int3)	//this method finds the lowest of three integers
	{
        if (int2<int1)
        {
        int1=int2;
        }
        if (int3<int1)
        {
        int1=int3;
        }
        
        return int1;
    }
    
    public double findlowest(double d1,double d2,double d3)	//this method finds the lowest of three doubles
	{
        if (d2<d1)
        {
        d1=d2;
        }
        if (d3<d1)
        {
        d1=d3;
        }
        
        return d1;
    }    
        	
	public double mannanDistance(int x, int y)
	  //*****************************
	  // Compute Mannan distance
	  //*****************************
	  //based on Mannan et al (1995)
	{
		double d[][]; // matrix
	  	int n; // length of first
	  	int m; // length of second	
	 	int i; // iterates through first
		int j; // iterates through second	 
		double d1i = 0; //the sum of squared distances from the ith fixation in the 1st scanpath to its nearest neighbour
		double d2j = 0; //the sum of squared distances from the jth fixation in the 2nd scanpath to its nearest neighbour
		
		 		  	
		//make a matrix of the distance between each of the fixations
		//the lowest in each column/row gives the nearest neighbour distance
		n=spA.fixations.size();
		m=spB.fixations.size();
		d=new double [n][m];
		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++)
			{
				d[i][j]=spA.fixations.elementAt(i).distance(spB.fixations.elementAt(j));
			}
		}		
		
		double lowest;
		for(i=0;i<n;i++)
		{
		lowest=100000;
			for(j=0;j<m;j++)
			{
				if (d[i][j]<lowest){lowest=d[i][j];}
			}
		d1i=d1i+(lowest*lowest);//sum the squared distances from A to B
		}	
		
		for(j=0;j<m;j++)
		{
		lowest=100000;
			for(i=0;i<n;i++)
			{
				if (d[i][j]<lowest){lowest=d[i][j];}
			}
		d2j=d2j+(lowest*lowest);//sum the squared distances from B to A
		}

		double dsquared = (n*d2j)+(m*d1i);	//multiply the sum of squares by the length of each scanpath
		dsquared = dsquared /((2*n*m)*((x*x)+(y*y)));	//normalise over the display size
		md=Math.sqrt(dsquared);		
		return md;
	}    

	public double uaDistance(int x, int y)
	  //*****************************
	  // Compute Unique-Assignment variant of Mannan distance
	  //*****************************
	  //based on Mannan et al (1995) and Henderson et al (2007)
	  //requires two equally sized scanpaths
	{
		PermutationGenerator pairings; //an instance of the permutation generator
		int[] pairingArray;  //array to store the pairing
		int i; // iterates through first scanpath
		double d,lowestD; //the distance, and the current lowest distance
		double d1i; //the sum of squared distances from the ith fixation in the 1st scanpath to its counterpart
		
		//get all possible permutations of a scanpath of this length
		pairings = new PermutationGenerator (spA.fixations.size());
		uaNearestArray = new int[spA.fixations.size()];
		System.out.print("Total number of permutations: "+pairings.getTotal()+"\n");
		lowestD=10000000;	
		
		//loop through all permutations
		while (pairings.hasMore ()) 
		{
		//System.out.println("Permutation number:"+p);
		d=0;
		d1i=0;
		pairingArray = pairings.getNext ();	//gets the current permutation
		
			//for each fixation, pair with the permutation in the other scanpath
			for(i=0;i<spA.fixations.size();i++)	
			{
				//System.out.println(pairingArray[i]);
				d=spA.fixations.elementAt(i).distance(spB.fixations.elementAt(pairingArray[i]));
				//System.out.println("Comparing A"+i+" and B"+(pairingArray[i])+" distance is "+d);
				d1i=d1i+(d*d);									
			}
			//System.out.println("Sum of d1i/d2j squared for this pairing: "+d1i);
			
			//store the lowest mean distance, and the associated pairing
			if(d1i < lowestD)
			{
			//System.out.println("Lowest pairing is now: "+uaNearestArray[0]+uaNearestArray[1]+uaNearestArray[2]+uaNearestArray[3]);
			lowestD = d1i;	
			java.lang.System.arraycopy(pairingArray,0,uaNearestArray,0,pairingArray.length);
			}
		}
					
		//System.out.println("Sum of squared distances for the lowest pairing: "+lowestD);
		d1i=lowestD;
	
		int n=spA.fixations.size();
			
		double dsquared=(n*d1i)+(n*d1i); //multiply sum of squares by scanpath length
		dsquared=dsquared/((2*n*n)*((x*x)+(y*y))); //normalise by display size
		uad=Math.sqrt(dsquared);		
		return uad;
	
	}	
	
	public double weightedEditDistance(int x, int y)
	  //*****************************
	  // Compute distance-weighted version of the Levenshtein distance
	  //*****************************	
	{
	  double d[][]; // matrix is now of doubles, allowing variable costs
	  int n; // length of first
	  int m; // length of second
	  int i; // iterates through first
	  int j; // iterates through second
	  char s_i; // ith character of first
	  char t_j; // jth character of second
	  double cost; // cost of the operation, will vary according to normalised distance
	  
	    // Step 1: if either string is empty, distance is length of the other
	    n = a.length ();
	    m = b.length ();
	    if (n == 0) 
	    {
	      wd = m;
	      return sd;
	    }
	    if (m == 0) 
	    {
	      wd = n;	      
	      return wd;
	    }

	    d = new double[n+1][m+1];
	
	    // Step 2: set the first row/column to integers ascending from 1		
	    for (i = 0; i <= n; i++) 
	    {
	      d[i][0] = i;
	    }		
	    for (j = 0; j <= m; j++) 
	    {
	      d[0][j] = j;
	    }
	
	    // Step 3: loop through the first string		
	    for (i = 1; i <= n; i++) 
	    {		
	      s_i = a.charAt (i - 1);
	
	      // Step 4: loop through the second string		
	      for (j = 1; j <= m; j++) 
	      {		
	        t_j = b.charAt (j - 1);
	
	        // Step 5: compare the two characters		
	        //costs in this method vary as a function of their linear distance
	        cost=spA.fixations.elementAt(i - 1).distance(spB.fixations.elementAt(j - 1));
	        //normalised over display size, needs to be between 1 and 0
	        //biggest possible distance (cost of 1) will be equal to central diagonal
	        cost = cost/Math.sqrt((x*x)+(y*y));	        
	        //System.out.print("cost "+i+" : "+j+" = "+cost+" ,");
	
	        // Step 6: set the current cell
	        d[i][j] = findlowest (d[i-1][j]+1, d[i][j-1]+1, d[i-1][j-1] + cost);		
	      }		
	    }
	
	    // Step 7: distance is bottom left cell
	    wd = d[n][m];
	   // System.out.print("wd = "+wd+" ,");
	
		//Step 8: normalise the distance over the length of the longer string
       	if (n>=m){wdNorm = wd/n;}
    	else {wdNorm = wd/m;}
    	    	
    	//similarity is 1 minus the normalised distance
    	wdSim = 1-wdNorm;
    	return wd;		  		
	}
	    
	public double retrieveCell(int a,int b,String fpath)
	//convenience method for retrieving a value from a 2d array stored in a file
	{	
		try
		{
			//load the file
			fpath=System.getProperty("user.dir")+fpath;
			System.out.println("loading ["+fpath+"]");
			RandomAccessFile fileIn = new RandomAccessFile(fpath, "r");
			String wholeline="";
			//read b lines, parsing into an array
			for(int ln=0;ln<b;ln++)
			{
				wholeline=fileIn.readLine();
			}
			//extract column a from this line
			Double rv=new Double(wholeline.split("\t")[a-1]);
			return rv.doubleValue();
			
		}
		catch (IOException e) // NB remember the error handling.
		{
		  System.out.println("An i/o error has occurred ["+e+"]");
		  return -1;
		}		
	}
	
	
	
	public static void main(String[] args) 
    {
	    int simulations=10000;
	    int x=512;
	    int y=384;
	    double avMetric;
	    
	    ScanpathComparison sp;
	    FixationSequence fa;
	    FixationSequence fb;
	    
	    try
	    {
	    RandomAccessFile fileOut=new RandomAccessFile("C:/Documents and Settings/Tom/My Documents/uadrand.txt","rw");
	    
		for(int a=1;a<=50;a++)
		{							
			for(int b=1;b<=50;b++)
			{
				
				if(a==b)
				{
					avMetric=0;	
					for(int n=0;n<simulations;n++)
					{					
						fa=new FixationSequence();
						fb=new FixationSequence();
						for(int z=0;z<a;z++)
						{
						fa.fixations.add(new Point((int)(x*java.lang.Math.random()),(int) (y*java.lang.Math.random())));						
						}	
						for(int z=0;z<b;z++)
						{
						fb.fixations.add(new Point((int)(x*java.lang.Math.random()),(int) (y*java.lang.Math.random())));						
						}	
					//for each simulation add the similarity
					sp=new ScanpathComparison(fa,fb);	
					avMetric = avMetric + sp.mannanDistance(x,y);				
					}
				//make an average and write to the file
				avMetric = avMetric / simulations;
				fileOut.writeBytes(avMetric + "\t");
			
				}		
				else
				{
					fileOut.writeBytes(-1 + "\t");
				}								
			}
		fileOut.writeBytes("\n");
		}
		
		}
		
		catch (IOException e) // NB remember the error handling.
		{
		  System.out.println("An i/o error has occurred ["+e+"]");
		}
		
		//test the new methods
		/*
		FixationSequence myseq1=new FixationSequence();
		myseq1.fixations.add(new Point(10,20));
		myseq1.fixations.add(new Point(100,20));
		myseq1.fixations.add(new Point(10,200));
		myseq1.fixations.add(new Point(100,200));
		myseq1.fixations.add(new Point(1,20));
		FixationSequence myseq2=new FixationSequence();
		myseq2.fixations.add(new Point(10,20));
		myseq2.fixations.add(new Point(100,20));
		myseq2.fixations.add(new Point(10,200));
		myseq2.fixations.add(new Point(100,200));
		myseq2.fixations.add(new Point(1,20));	
		myseq2.fixations.add(new Point(10,200));
		myseq2.fixations.add(new Point(100,200));
		myseq2.fixations.add(new Point(1,20));		
		
		ScanpathComparison sc=new ScanpathComparison (myseq1,myseq2);
		sc.spA.getSp();
		sc.spB.getSp();		
		sc.getStrings(1024,768,5,5);
		System.out.println(a);
		System.out.println(b);	
		
		sc.condenseStrings();
		System.out.println(a);
		System.out.println(b);	
		sc.trimScanpaths(0,10,true);		
		sc.getStrings(1024,768,5,5);
		sc.condenseStrings();
		System.out.println(a);
		System.out.println(b);	*/	
		
    }    	
}
