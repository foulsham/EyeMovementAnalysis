	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* a class which represents the Region(s) of Interest in an image or display
ROIs are stored as a Vector of Rectangles. Future implementations might add other shapes.  
*/
package emtools.io;

import java.io.*;
import java.util.*;
import java.awt.*;


public class ROI 
{

//a label describing the related image or similar
public String label;

//IDs describing the ROIs
public Vector <String> ids=new Vector <String> ();

//The ROIs as a growable vector of rectangles; empty when originally constructed
public Vector <Rectangle> rois=new Vector <Rectangle> ();

//default size for the regions
int d_x=140;
int d_y=140;

	public boolean loadFromFile(String filepath)
	//this method loads the ROIs from a file
	//first line indicates the type of file layout to expect
	{
		try
		{
		RandomAccessFile inFile = new RandomAccessFile(filepath, "r");
		String s=inFile.readLine();
		
		if(s.startsWith("FOAradius"))
		//saliency model type
		{
			inFile.readLine();
			inFile.readLine();
			//sets the label to the filename indicated in the model output
			label=inFile.readLine();
			label=label.substring(label.indexOf("=")+1).trim();
			
			//then loops through a series of points, defining rectangles using the default dims
			int r=0;
			while(( s=inFile.readLine()) != null)
			{
				String coords=s.substring(s.indexOf("= ")+1).trim();
				Integer i=new Integer(0);
				int x=i.parseInt(coords.split(" ")[0]);
				int y=i.parseInt(coords.split(" ")[1]);
				addROI(new Point(x,y),d_x,d_y,(label+"_"+r),1);
				r++;
			}			
		}
		else
		//standard type
		{		
		//first line gives label
		label=s;
		//then loop through subsequent lines and create the ROIs
			int r=0;
			while(( s=inFile.readLine()) != null)
			{
				Integer i=new Integer(0);
				int x=i.parseInt(s.split("\t")[1]);
				int y=i.parseInt(s.split("\t")[2]);
				int w=i.parseInt(s.split("\t")[3]);
				int h=i.parseInt(s.split("\t")[4]);				
				addROI(new Point(x,y),w,h,s.split("\t")[0],0);
				r++;
			}		
		}

		return true;
		}
		catch(IOException e) // NB remember the error handling.
		{
		System.out.println("An i/o error has occurred ["+e+"]");
		return false;
		}	
	}
	
	public void addROI(Point p,int w, int h, String id,int type)
	//method to add regions
	//last argument indicates whether start point is Top Left or Centre
	{
		int x,y;
		
		if(type==1)
		{
		//central points
		x=p.x-(w/2);
		y=p.y-(h/2);
		}
		else
		{
		//top left points
		x=p.x;
		y=p.y;
		}
		
		rois.add(new Rectangle(x,y,w,h));
		ids.add(id);
	}
	
	public void addROI(Rectangle r,String id)
	//method to add regions
	{
		rois.add(r);
		ids.add(id);
	}	
	
	public Point getCentre(int i)
	//method to return central coordinate
	{
		int x=rois.elementAt(i).x + (rois.elementAt(i).width/2);
		int y=rois.elementAt(i).y + (rois.elementAt(i).height/2);		
		return (new Point(x,y));
	}		
	
	public int contains(Point p)
	//method to check whether point is contained within any of the current ROIs
	{
		for(int r=0;r<rois.size();r++)
		{
			if(rois.elementAt(r).contains(p))
			{
			return r;
			//if so returns index of ROI which does
			}
		}
		return -1;
		//if not returns -1
	}
	
	public double getDistance(Point p, int i)
	//method to get the distance between a point and the centre of a ROI
	{
		return p.distance(getCentre(i));
	}	
	
	public int getNearest(Point p)
	//method to get the nearest ROI to a point (still returns even if within)
	{
		double d=100000;
		int i=-1;
		for(int r=0;r<rois.size();r++)
		{
			if(getDistance(p,r)<d)
			{
			d=getDistance(p,r);
			i=r;
			}
		}
		return i;
	}
	
	public int findID(String s)
	//method which will return the index of the ROI whose ID starts with the argument
	//if none is found return -1
	{
		int i=-1;
		for(int r=0;r<rois.size();r++)
		{
			if(ids.elementAt(r).startsWith(s))
			{
			i=r;
			}
		}
		return i;		
	}	
	
	public void printToFile(String filepath)
	//a method to store the ROI to the path indicated
	{
		try
		{
		RandomAccessFile outFile = new RandomAccessFile(filepath, "rw");
		System.out.println("writing to file.....");
		
		//write the label first
		outFile.writeBytes(label+"\n");
		
		//then, for each ROI
		for(int r=0;r<rois.size();r++)
		{
			outFile.writeBytes(ids.elementAt(r) + "\t" + rois.elementAt(r).x + "\t" + rois.elementAt(r).y);
			outFile.writeBytes("\t" + rois.elementAt(r).width + "\t" + rois.elementAt(r).height + "\n");
		}		

		}
		
		catch(IOException e) // NB remember the error handling.
		{
		System.out.println("An i/o error has occurred ["+e+"]");
		}	
						
	}

}
