	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)


// fixation parsing program
//takes a series of tab delimited lines giving fix num, x and y coords, and outputs a vector of fixation sequences
//updated to optionally take a trial/set name too
package emtools.io;

import java.io.*;
import java.awt.*;
import java.util.*;
import emtools.scanpath.*;

public class FixParse 
{	
	public Vector <FixationSequence> FixSeq=new Vector <FixationSequence> ();	//a growable set of fixation sequences (1 per trial)
	public boolean gettingNames; //a flag to test if we're getting names too
	
	public FixParse()
	//default empty constructor
	{
	
	}
	
	public FixParse(String filename)
	//constructor takes a filename from where it extracts the data
	{
		int trialCounter=-1;	//a variable to keep track of the different sets
		int x,y;	//coordinates to parse to		
		try
		{
			// Instantiate RandomAccessFile.  NB the file "input.txt" is opened for reading.
			RandomAccessFile fileIn = new RandomAccessFile(filename, "r");
            String wholeline,tempname="";
            
            // first check to see if the first column contains a name or a number
            wholeline=fileIn.readLine();
            wholeline=wholeline.substring(0,wholeline.indexOf("\t"));
            if(safeParse(wholeline).intValue()==-1)
            {
	         	//-1 flag indicates text in first column
	         	gettingNames=true;   
            }
            else
            {
	         	gettingNames=false;   
            }
            
            //remember to reset the pointer back to the beginning
            fileIn.seek(0);
            
            while ((( wholeline=fileIn.readLine()) != null) && (!wholeline.equals(""))) 
            {     
	            if(gettingNames)
	            {
		            //get the set name if necessary
		            tempname=wholeline.substring(0,wholeline.indexOf("\t"));
	                wholeline=wholeline.substring(wholeline.indexOf("\t"),wholeline.length());	
	                wholeline=wholeline.trim();		            
	        	} 
	        	   
	            //takes the first number as the fixation index
	            //should start at 1
	            //if 1, increase trial counter and add a new empty scanpath as it means a new trial 
            	if(safeParse(wholeline.substring(0,wholeline.indexOf("\t"))).intValue()==1)
            	{
	            	trialCounter++;
	            	FixSeq.add(new FixationSequence());
	            	if(gettingNames)
	            	{
		            	FixSeq.elementAt(trialCounter).fname=tempname;	
	            	}
	            	else
	            	{
		            	//if not using names use a trial index
		            	FixSeq.elementAt(trialCounter).fname=("Trial "+(trialCounter+1));
	            	}
            	}
            	
            	//reset wholeline to rest of line and get rid of any outer whitespace
                wholeline=wholeline.substring(wholeline.indexOf("\t"),wholeline.length());	
                wholeline=wholeline.trim();
                //parse the next two numbers
                x=safeParse(wholeline.substring(0,wholeline.indexOf("\t"))).intValue();
                wholeline=wholeline.substring(wholeline.indexOf("\t"));	//wholeline reset to rest of line
                wholeline=wholeline.trim();
                y=safeParse(wholeline).intValue();
                //NOTE: casts both ints and doubles to an int for the Point coordinates, therefore loses some precision                
				FixSeq.elementAt(trialCounter).fixations.add(new Point(x,y));	
			}
        }
                
        catch (IOException e) // NB remember the error handling.
		{
			System.out.println("An i/o error has occurred ["+e+"]");
		} 
	}
	
	public Number safeParse(String s)
	//method to parse a number, be it int or double
	{
		Integer i;	//wrapped variables to provide parsing methods
		Double d;	
			
		s=s.trim(); //remove whitespace
		try
		//try parsing as an integer
		{
			i=new Integer(s);
			return i;
		}
		//if that doesn't work, try parsing as a double
		catch (NumberFormatException e)
		{
			try
			{
			d= new Double(s);
			return d;
			}
			//if that doesn't work treat as text
			catch (NumberFormatException e2)
			{
				i=new Integer(-1);
				return i;
			}
		}
	}
	
	public void reset()
	//method to clear all contents
	{
		FixSeq.clear();
	}
	
	public FixParse[] splitBy(int sets)
	//method which will split a single parsed file into multiple files
	//argument gives number of sets per file
	//note that remaining sets are discarded
	{
		int f=FixSeq.size()/sets;
		FixParse[] fp=new FixParse[f];
		
		for(int a=0;a<f;a++)
		{
			for(int s=0;s<sets;s++)
			{
				fp[a].FixSeq.add(FixSeq.elementAt(s));
			}
		}
		return fp;
	}	
		
	public void writeToFile(String fname)
	//method which will write the fixation details to a tabbed text file
	{
			try
			{
			RandomAccessFile outFile = new RandomAccessFile(fname, "rw");
			System.out.println("writing to file.....");
				for(int s=0;s<FixSeq.size();s++)
				{
					for(int f=0;f<FixSeq.elementAt(s).fixations.size();f++)
					{
						if(gettingNames)
						{
						outFile.writeBytes(FixSeq.elementAt(s).fname+"\t");	
						}	
						outFile.writeBytes((f+1)+"\t");
						outFile.writeBytes(FixSeq.elementAt(s).fixations.elementAt(f).x+"\t");					
						outFile.writeBytes(FixSeq.elementAt(s).fixations.elementAt(f).y+"\n");
					}
				}
			}
			
			catch(IOException e) // NB remember the error handling.
			{
			System.out.println("An i/o error has occurred ["+e+"]");
			}			
	}
	
	public static void main(String[] args) 
	{
		FixParse fp=new FixParse("testnames.txt");
		for(int t=0;t<fp.FixSeq.size();t++)
		{
			System.out.println(fp.FixSeq.elementAt(t).fname);
			fp.FixSeq.elementAt(t).getSp();	
		}
		System.out.println("Returned with "+fp.FixSeq.size()+" sets");
	}
}
