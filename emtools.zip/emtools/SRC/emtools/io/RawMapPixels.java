	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* a simple class which attempts to read the pixel values from an ASCII .ppm or .pgm file

*/
package emtools.io;

import java.io.*;
import java.util.*;
import java.awt.*;

public class RawMapPixels
{
	//the filename of the associated saliency map
	public String filename="";
	
	//the array of pixel values
	public int[][] map;
	
	//min and max pixel values and mean of all values
	public int min_pixel, max_pixel;
	public double map_mean;

	public RawMapPixels(String source_file)
	//constructor which gets the source file from the path
	{
		filename=source_file;
		try
		{
		RandomAccessFile inFile = new RandomAccessFile(source_file, "r");
		int a[];
		String s;
		
			//ignore the first line and a subsequent one starting with hash (ie. comment lines)
			inFile.readLine();
			s=inFile.readLine();
			if(s.startsWith("#"))
			{
			s=inFile.readLine();	
			}
			
			//get the dimensions expected, if they're not there or parse failed, abort
			a=splitLineIntoNumbers(s);
			if(a[0]!=-1)
			{
				int w=a[0];
				int h=a[1];
				
				//ignore the next line (maximum number)
				inFile.readLine();
				
				//define array size
				map=new int[w][h];
				
				//then, read one pixel at a time, and place in array
				
				//keep track of pixels and array position
				int x=0,y=0;
					
				while(( s=inFile.readLine()) != null)
				//for each line...
				{
					//get the numbers
					a=splitLineIntoNumbers(s);
					
					//add them to the array and increment as you go
					for (int i=0;i<a.length;i++)
					{
						map[x][y]=a[i];
						x++;
						if(x==w)
						{
							x=0;
							y++;	
						}
					}				
				}
			} 

		}
		catch(IOException e) // NB remember the error handling.
		{
		System.out.println("An i/o error has occurred ["+e+"]");
		}
		
	}

	public RawMapPixels(int x,int y)
	//alternative constructor for making a blank salmap whose pixels are all given value 0
	{
		map=new int[x][y];
	}
		
	public int[] splitLineIntoNumbers(String line)
	//a method to easily split a line of text into integers, based on either tab or space delimiters
	{
		Integer p=new Integer(0);
		String delim;
		String [] s;
		int[] a;
		line=line.trim();
		
		//System.out.println(line);
		
		try
		{
			//try splitting by spaces
			int i=p.parseInt(line.split(" ")[0]);
			delim=" ";		
		}
		catch(NumberFormatException e)
		{
			//if that doesn't work try splitting by tabs
			try
			{
			int i=p.parseInt(line.split("\t")[0]);
			delim="\t";
			}
			catch(NumberFormatException e2)
			{			
				//if that doesn't work return -1 value
				a=new int[1];
				a[0]=-1;
				return a;	
			}
		}
		
		s=line.split(delim);
		
		Vector <String> v=new Vector <String> ();
		//deal with 0 length segments
		for (int i=0;i<s.length;i++)
		{
			if(s[i].length()>0)
			{
			v.add(s[i]);	
			}
		}				
		a=new int[v.size()];
		for (int i=0;i<v.size();i++)
		{
			a[i]=p.parseInt(v.elementAt(i));
			//System.out.println(a[i]);
		}
		return a;
	}

		public void setMinMaxMean()
		//sets the minimum and maximum pixel values
		{
		min_pixel=1000000;	
		max_pixel=0;
		map_mean=0;
	
		for(int x=0;x<map.length;x++)
		{
			for(int y=0;y<map[0].length;y++)
			{			
				if(map[x][y]>max_pixel){max_pixel=map[x][y];}
				if(map[x][y]<min_pixel){min_pixel=map[x][y];}
				map_mean+=map[x][y];
			}
		}
		map_mean=map_mean/(map.length*map[0].length);
		}
		
		public void scaleToRange()
		//a method which scales the pixel values so that the maximum pixel is 255
		{
			//first get the min and max
			setMinMaxMean();
			//then get the scale factor
			double sf=(double)255/max_pixel;
			//System.out.println("max is "+max_pixel+" ; scale factor is "+sf+" ; pixel of 500 will be reduced to "+((int)(500*sf)));
			//then scale each pixel
			for(int x=0;x<map.length;x++)
			{
				for(int y=0;y<map[0].length;y++)
				{			
					map[x][y]=(int)(map[x][y]*sf);
				}
			}			
		}

		public void printMapToFile(String filename, int code)
		//prints the whole map to a txt file
		//code argument specifies a plain txt (0) or .pgm file (=>1)
		{	
			try
			{
			RandomAccessFile outFile = new RandomAccessFile(filename, "rw");
			System.out.println("writing to file.....");
			if(code>0)
			{
			outFile.writeBytes("P2"+"\n"+"#."+"\n"+map.length+" "+map[0].length+"\n"+"255"+"\n");	
			}
				for(int y=0;y<map[0].length;y++)
				{		
					for(int x=0;x<map.length;x++)
					{			
						outFile.writeBytes(map[x][y]+" ");
					}
				outFile.writeBytes("\n");
				}	
			}
			
			catch(IOException e) // NB remember the error handling.
			{
			System.out.println("An i/o error has occurred ["+e+"]");
			}	
				
		}
		
		public double getAreaAbove(int threshold)
		//count the pixels greater than threshold and return area as a proportion of the total area
		{
			int totalArea=map.length*map[0].length;
			int pixels=0;
				for(int y=0;y<map[0].length;y++)
				{		
					for(int x=0;x<map.length;x++)
					{			
						if(map[x][y]>threshold)
						{
							pixels++;
						}
					}
				}
			double areaAbove=pixels/totalArea;
			System.out.println(pixels + " out of " + totalArea + " greater than " + threshold + " = " + areaAbove);
			return areaAbove;
		}
		
		public int getThresholdFromArea (double areaAbove)
		//the inverse of the previous method; gets the the highest threshold x whereby x % of the pixels are greater
		//returns minus one if not possible 
		{
			int totalArea=map.length*map[0].length;
			int pixels=0;
			int targetPixels=(int)(totalArea*areaAbove);
			System.out.println(targetPixels);
			int threshold=-1;
			//count down from the max value until the required percentage is found
			setMinMaxMean();
			
			for(int t=max_pixel;t>0;t--)
			{
				for(int y=0;y<map[0].length;y++)
				{		
					for(int x=0;x<map.length;x++)
					{			
						if(map[x][y]>t)
						{
							pixels++;
						}
					}
				}
				if(pixels>targetPixels)
				{
				threshold=t;
				t=0;
				}
			}
			
			System.out.println("Threshold of " + threshold + " separates the highest " + areaAbove + " of the map");
			return threshold;			
		}
		
		public ROI describeAreaAbove (int threshold)
		//returns a series of rectangles which describe all pixels above a certain value
		{
			System.out.println("thresholding "+ map.length + " , " + map[0].length);
			
			ROI roi=new ROI();
			roi.label=filename+"_area_above_"+threshold;		
			
			//proceed through the map from left to right and top to down
				for(int y=0;y<map[0].length;y++)
				{		
					for(int x=0;x<map.length;x++)
					{			
						if( (map[x][y]>threshold) && (roi.contains(new Point(x,y))== -1) )
						//if pixel is bigger and not already within a ROI start making rectangles
						{
							//grow the rectangle as big as possible with pixels above t
							int maxArea=0;
							int maxW=0,maxH=0;
							
							//iterate through possible rectangles
							for(int rw=0;rw<map.length;rw++)
							{
								for(int rh=0;rh<map[0].length;rh++)
								{
									//System.out.println(x + " , " + y + " , " + rw + " , " + rh);
									if( ((x+rw)<map.length) && ((y+rh)<map[0].length) && ((rw*rh)>maxArea))
									//if this rectangle is within bounds and bigger than the current biggest....
									{
									Rectangle r1=new Rectangle(x,y,rw,rh);
										if(allRectIsAbove(r1,threshold))
										//then if all pixels within it are greater...
										{
											//set new biggest rectangle and store current size
											maxArea=rw*rh;
											maxW=rw;
											maxH=rh;
										}
									}
								}
							}
							//define the biggest rectangle which contains over-threshold pixels
							Rectangle r=new Rectangle(x,y,maxW,maxH);
							
							//add the biggest to the ROIs
							roi.addROI(r,("OVER_THRESHOLD_ROI_"+roi.rois.size()));
							System.out.println(".......adding rectangle "+ r.x + " , " + r.y + " , " + r.width + " , " + r.height);
						}
					}
				}			
			return roi;
		}
		
		public boolean allRectIsAbove(Rectangle r,int t)
		//tests whether all pixels within a rectangle are greater than t
		{
			boolean rv=true;
			for(int h=0;h<r.height;h++)
			{
				for(int w=0;w<r.width;w++)
				{
					//System.out.println(r.x + " , " + r.y + " , " + w + " , " + h);
					if(map[r.x+w][r.y+h]<=t)
					{
					rv= false;
					}
				}		
			}
			return rv;
		}
		
		public int getValueSafely(int x, int y)
		//gets a value from a point in the map, giving -1 if out of bounds
		{
			int rv=-1;
			if((x>=0) && (x<map.length) && (y>=0) && (y<map[0].length))
			{
				rv=map[x][y];	
			}
			
			return rv;
		}
}
