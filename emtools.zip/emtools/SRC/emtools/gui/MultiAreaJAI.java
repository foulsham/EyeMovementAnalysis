	  //*****************************
	  // Scanpath comparison programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

// SCANPATH AREA CLASS
//a class for building GUIs which displays a region and two scanpaths overlaid onto it
//modified to display many events on the same area
package emtools.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import javax.swing.event.MouseInputListener;
import javax.media.jai.*;
import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import java.awt.image.RenderedImage;
import javax.media.jai.InterpolationNearest;
import com.sun.media.jai.widget.DisplayJAI;
import com.sun.media.jai.mlib.*;
import java.awt.image.renderable.ParameterBlock;
import java.util.*;
import emtools.io.*;
import emtools.scanpath.*;

public class MultiAreaJAI extends DisplayJAI {
	    //this is an abstract class which shows an area with an image and scanpath information
        
	    Vector <FixationSequence> scanpaths=new Vector <FixationSequence> ();	//fixation sequences which can be displayed
	    DisplayProps props; //the display context
		int minfix,maxfix; //the index of the first and last fixation to include
    	
        public MultiAreaJAI(DisplayProps props) 
        //CONSTRUCTOR
        {
	        super();//the standard constructor, leads to an empty panel
			this.props=props;
			this.setPreferredSize(new Dimension((props.imagex/props.displayZoom),(props.imagey/props.displayZoom)));
			setBackground(Color.WHITE);       			
			minfix=0;//default allows all fixations from 0 to 1000
			maxfix=1000;
        }
    
        public void paintComponent(Graphics g) {
	        //First paint the component, including the background picture if its there
	        super.paintComponent(g);
			g.setFont(new Font(g.getFont().getFontName(),Font.BOLD,14));
			
            //Paint grid.
            if(props.gridOn)
            {
            g.setColor(props.gridcol);
            int xdim=(props.imagex/props.displayZoom)/props.gridx;
            int ydim=(props.imagey/props.displayZoom)/props.gridy;
            drawGrid(g, xdim,ydim);
        	}
            
			for(int s=0;s<scanpaths.size();s++)
			//for each scanpath
			{
	        //draw the fixation markers, saccades and numbers if necessary
	            if(props.fixOn)
		        {
			        g.setColor(props.fix1col);
	        		for (int i=minfix; i<scanpaths.elementAt(s).fixations.size(); i++)
		            {
			        int x=scanpaths.elementAt(s).fixations.elementAt(i).x;
		            int y=scanpaths.elementAt(s).fixations.elementAt(i).y;	
		            props.paintFix(g,x,y);				    		            	            
					//g.drawOval(x-((props.fixdim-1)/2), y -((props.fixdim-1)/2),props.fixdim, props.fixdim);		
					if(i==maxfix)
					{
					i=scanpaths.elementAt(s).fixations.size();
					}
					}
				}	        
				
	            if(props.sacsOn)
				{
					g.setColor(props.sac1col);
					for (int i=minfix; i<scanpaths.elementAt(s).fixations.size(); i++)
	            	{   				    		            	            
  						if(i>minfix)
  						{
			            int x=scanpaths.elementAt(s).fixations.elementAt(i).x;
			            int y=scanpaths.elementAt(s).fixations.elementAt(i).y;	
			            int x2=scanpaths.elementAt(s).fixations.elementAt(i-1).x;
			            int y2=scanpaths.elementAt(s).fixations.elementAt(i-1).y;						     
				        props.paintSac(g,x,y,x2,y2);
			            // g.drawLine(x,y,x2,y2);
		        		}
					if(i==maxfix)
					{
					i=scanpaths.elementAt(s).fixations.size();
					}						
					}
				}	
				
	            if(props.numsOn)
	            {
		            g.setColor(props.numcol);				        
        		    for (int i=minfix; i<scanpaths.elementAt(s).fixations.size(); i++)
	            	{
			            int x=scanpaths.elementAt(s).fixations.elementAt(i).x;
			            int y=scanpaths.elementAt(s).fixations.elementAt(i).y;	
			            Integer j=new Integer(i+1);				
			              //calls a method which draws a number slightly above the fixation
		                g.drawString(j.toString(),x,y-15);
					if(i==maxfix)
					{
					i=scanpaths.elementAt(s).fixations.size();
					}
											
            		}
            	}
        	}				    
        }
        
        //Draws a grid using the current color.
        private void drawGrid(Graphics g, int gridSpaceX, int gridSpaceY) 
        {
	        //arguments give graphics context and number of divisions to make
            Insets insets = getInsets();
            int firstX = insets.left;
            int firstY = insets.top;
            int lastX = getWidth() - insets.right;
            int lastY = getHeight() - insets.bottom;
            
            //Draw vertical lines.
            int x = firstX;
            while (x < lastX) {
                g.drawLine(x, firstY, x, lastY);
                x += gridSpaceX;
            }
            
            //Draw horizontal lines.
            int y = firstY;
            while (y < lastY) {
                g.drawLine(firstX, y, lastX, y);
                y += gridSpaceY;
            }
        }

        public void clearArea()
        //clear the area
        { 
	        scanpaths.clear();
			scanpaths=new Vector <FixationSequence> ();
            repaint();
     	}
		
		public void setFixationLimits(int a, int b)
		//a method to set the limit variables
		{
		minfix=a;
		maxfix=b;
		}
     	
        public void paintFix(Graphics g,int x, int y)
        //a convenience method for painting the fixation marker
        //arguments are the graphics context and the centre point of the fix
        { 
			g.drawOval(x-((props.fixdim-1)/2), y -((props.fixdim-1)/2),props.fixdim, props.fixdim);
			g.drawOval(x-((props.fixdim-1)/2)-1, y -((props.fixdim-1)/2)-1,props.fixdim+2, props.fixdim+2);	
     	}     	
     	
		public void changeBackground(String i)
		{	
			if(i!=null)
			{
				//make an image from the argument path
		        PlanarImage image,scaled_image;
		        image=JAI.create("fileload", i);
		        
			    //get the original image size
			    int x=image.getWidth();
			    int y=image.getHeight();
			    //System.out.println(x+" "+y);
			    
			    //get the zoomed image size
			    float scalex=(props.imagex/props.displayZoom);
			    float scaley=(props.imagey/props.displayZoom); 
			    //System.out.println(scalex+" "+scalex);
			    
			    //determine scale factor
			    scalex=scalex /x;
			    scaley=scaley /y;
			    //System.out.println(scalex+" "+scalex);
			    
			    if((scalex>0)&&(scaley>0))
			    //don't scale if already correct size
			    {
				    //create a pb and add the image, two floats indicating scaling, two floats indicating translation, and an interpolation constant
				    ParameterBlock pb= new ParameterBlock();
				    pb.addSource(image);
					pb.add(scalex);
					pb.add(scaley);
					pb.add(0.0f);
					pb.add(0.0f);
					pb.add(new InterpolationNearest());
					scaled_image=JAI.create("scale", pb);
					set(scaled_image);
				}
				else
				{
					set(image);	
				}	
			}
			else
			{
				removeAll();
			}
		}     	                  
    }