	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* 
	-a class to hold the display properties for showing scanpaths
	-also contains some general methods for drawing scanpaths
*/
package emtools.gui;

import java.awt.*;

public class DisplayProps 
{
public Color fix1col,fix2col,sac1col,sac2col,gridcol,numcol;//colours of each of the drawn components
public boolean gridOn,sacsOn,fixOn,numsOn; //flags for whether to show each component
public int gridx,gridy;	
public int imagex,imagey,displayZoom;	
public int fixdim;	
public int sacwidth;	//allows the size of the grid/index/fixation markers/saccade trajectories to be varied

	public DisplayProps(int scheme)
	//CONSTRUCTOR takes an argument indicating one of the default display schemes
	{
		if(scheme==1)
		{
			fix1col=Color.RED;
			fix2col=Color.GREEN;
			sac1col=Color.RED;
			sac2col=Color.GREEN;
			gridcol=Color.BLACK;
			numcol=Color.BLACK;
			gridOn=true;
			sacsOn=true;
			fixOn=true;
			numsOn=true;
			gridx=5;
			gridy=5;	
			imagex=1024;	
			imagey=768;	
			displayZoom=2;
			fixdim=9;
			sacwidth=2;			
		}

		if(scheme==2)
		{
			fix1col=Color.RED;
			fix2col=Color.GREEN;
			sac1col=Color.RED;
			sac2col=Color.GREEN;
			gridcol=Color.BLACK;
			numcol=Color.BLACK;
			gridOn=false;
			sacsOn=false;
			fixOn=true;
			numsOn=false;
			gridx=5;
			gridy=5;	
			imagex=1024;	
			imagey=768;	
			displayZoom=2;
			fixdim=3;
			sacwidth=1;			
		}		
	}
	
        public void paintFix(Graphics g,int x, int y)
        //a convenience method for painting the fixation marker
        //arguments are the graphics context and the centre point of the fix
        { 
	        //draw the inner circle first
			g.drawOval(x-((fixdim-1)/2), y -((fixdim-1)/2),fixdim, fixdim);
			
			//then outline it as many times as necessary
			for(int c=1;c<=sacwidth;c++)
			{
			g.drawOval(x-((fixdim-1)/2)-c, y -((fixdim-1)/2)-c,fixdim+(2*c), fixdim+(2*c));	
			}
				
     	}	
     	
        public void paintSac(Graphics g,int x, int y,int x2, int y2)
        //a convenience method for painting saccades
        //arguments are the graphics context and the start/end point
        { 
	        //int s=sacwidth-1;
	        //draw the innermost line first
			g.drawLine(x,y,x2,y2);
			
			//then draw more lines as required
			//for(int l=1;l<s;l++)
			//{
			//g.drawLine(x-l,y-l,x2-l,y2-l);	
			//g.drawLine(x+l,y+l,x2+l,y2+l);
			//}
				
     	}     	
}