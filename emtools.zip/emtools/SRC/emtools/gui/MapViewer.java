	  //*****************************
	  // Scanpath comparison programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

// MAP VIEWER CLASS
//a class for building GUIs which displays an image/feature/saliency map
//needs to be able to handle .ppm/.pgm files
package emtools.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import java.awt.image.RenderedImage;
import javax.media.jai.InterpolationNearest;
import com.sun.media.jai.widget.DisplayJAI;
import com.sun.media.jai.mlib.*;
import java.awt.image.renderable.ParameterBlock;
import emtools.io.*;


public class MapViewer extends JFrame implements MouseMotionListener
{
	PlanarImage image,scaled_image;//the image
	RawMapPixels map;//the values
	JLabel label; //a label which will display the pixel value at a certain point
	float scalex,scaley; //variables to store scale picture when picture is zoomed
	CustomDisplayJAI dj;
	
    public MapViewer(String i,DisplayProps props) 
    //CONSTRUCTOR, arguments give path to the required image and props for size information
    {
  	setTitle("Map display");
  	label=new JLabel ("Location:       ; Value:    ");
    Container contentPane = getContentPane();
    contentPane.setLayout(new BorderLayout()); 
    
    //create and resize the image
    image=JAI.create("fileload", i);
    scaled_image=changeSize(props.imagex/props.displayZoom, props.imagey/props.displayZoom); 
    
    //get the raw pixel data
    map=new RawMapPixels(i);
     
    dj = new CustomDisplayJAI(scaled_image);
    dj.addMouseMotionListener(this);
    // Add the DisplayJAI instance.
    contentPane.add(dj,BorderLayout.CENTER);
    // Add a text label with the image information.
    contentPane.add(label,BorderLayout.SOUTH);    
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    pack(); // adjust the frame size.
    setVisible(true); // show the frame.    	 			
    }

    
    
    public PlanarImage changeSize(float desiredX,float desiredY)
    //a method to resize the map in order to display it at the same size as the source image 
    {
	    //get the original image size
	    int x=image.getWidth();
	    int y=image.getHeight();
	    //System.out.println(x+" "+y);
	    
	    //determine scale factors
	    scalex=desiredX/x;
	    scaley=desiredY/y;
	    //System.out.println(scalex+" "+scalex);
	    
	    if((scalex>0)&&(scaley>0))
	    //don't scale if already correct size
	    {
		    //create a pb and add the image, two floats indicating scaling, two floats indicating translation, and an interpolation constant
		    ParameterBlock pb= new ParameterBlock();
		    pb.addSource(image);
			pb.add(scalex);
			pb.add(scaley);
			pb.add(0.0f);
			pb.add(0.0f);
			pb.add(new InterpolationNearest());
			return JAI.create("scale", pb);
		}
		else
		{
		return image;	
		}
    }
    
    public int getValue(int x, int y)
    //get the value from a parsed map
    {
	 	//need to scale the coordinates to fit zoomed map
	 	if((scalex>0)&&(scaley>0))
	 	{
	    x=(int)(x/scalex);
	    y=(int)(y/scaley);
    	}
    	//System.out.println(x+" "+y);
    	
    	if((map.map!=null)&&(map.map[0][0]!=-1))
    	{
	    	return map.map[x][y];
	    		
    	}
    	else
    	{
	    	return -1;
	    	//return -1 if map hasn't been parsed properly	
		}
    }
    
    public void updateValue(int x, int y)
    //update the label to show the position and the corresponding value
    //can also be called from the scanpath viewer component
    {
		//get the value at this location, or ERR if map hasn't been parsed
		int v=getValue(x,y);
		String sv=" "+v+" ";
		if(v==-1)
		{sv="ERR";}
		
		//display the info
		label.setText("Location: "+ x + " , " +y + " ; Value: " + sv); 	 	   
    }
     
        
    //Methods required by the MouseInputListener interface.
    public void mouseMoved(MouseEvent me) 
    {
	//get the current coordinates
	int x=me.getX();
	int y=me.getY(); 
	updateValue(x,y);
  
	}
    public void mouseDragged(MouseEvent e) { }
}


//extra extension of DisplayJAI to allow painting over it
class CustomDisplayJAI extends DisplayJAI
{
    	
	boolean markerOn=false;//controls if a dot is going to track movements on the sv component
	Point p;

  	public CustomDisplayJAI(RenderedImage image)
    {
    super(image);
	}	
	
	
     /**
  * This method paints the component, calling the paint method of the ancestral
  * class and then paints a dot if necessary
  */
  	public void paint(Graphics g)
    {
    super.paint(g);
    
    if(markerOn && p!=null)
    {
	    g.setColor(Color.RED);
	    g.fillOval(p.x-3, p.y -3,6, 6);
    }

    }	
}
