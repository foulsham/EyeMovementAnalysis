	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* a GUI class which does the following:
	-displays one (of a set) of stimuli
	-displays several scanpaths overlaid onto this stimulus
	-outputs to an image or a .ppm fixation map

*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.text.Position.*;
import java.net.URL;
import java.awt.event.MouseEvent;
import javax.swing.event.*;
import java.io.*;
import java.awt.image.*;
import com.sun.image.codec.jpeg.*;
import emtools.io.*;
import emtools.scanpath.*;


public class MultiScanpathViewer extends JFrame implements ActionListener
{
	
	//GUI COMPONENTS
	static JPanel mainPanel,imagePanel,controlPanel,sourcePanel,setsPanel,fixPanel,buttonPanel;	//creates panels	
    static JButton getSourceImagesBtn,getSourceDataBtn;//buttons to load external data
    static JButton plotBtn,resetBtn,displayOptionsBtn;	//buttons for other options
    static JButton saveImage,saveMap;
    static JList imageList,dataList;//list the chosen files to display
    DefaultListModel imageListModel,dataListModel;
    static JScrollPane imageSP,dataSP; //scroll panes for long lists
    static JFileChooser imageFC,dataFC;//allow user to select the files they want
    File [] images,dataSources;//the chosen files
    static JRadioButton allTrials,theseTrialsOnly,allFixes,theseFixesOnly; //buttons to choose what to do 
    
    static JTextField trialFilter;
    static JSpinner fromFix,toFix;
    static SpinnerNumberModel fromFixModel, toFixModel;
    static JLabel lbl;
    
    static MultiAreaJAI area;
    
    //GRAPHIC VARIABLES (to control properties of the scanpath display, uses DisplayProps class)
	DisplayProps displayProps;
	
	//OTHER FRAMES WHICH WILL BE LAUNCHED WHEN NECESSARY
    JFrame DisplayOptionsFrame;	    
	
	//FIXATION DATA VARIABLES
	FixParse fp; //an instance of the fix parsing class which will hold all trials/sets from one data file
	
    //CONSTRUCTOR WHICH BUILDS THE GUI
    public MultiScanpathViewer()
    {
	    //BUILD PANELS
	    mainPanel = new JPanel();//contains everything else
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
	    	//mainPanel.setLayout(new GridLayout(0,1,5,3));
	    imagePanel = new JPanel();	//holds image and scanpath
	    sourcePanel = new JPanel();	//holds controls regarding which picture / data to use
			sourcePanel.setLayout(new GridLayout(2,2,5,3));
        controlPanel = new JPanel();	//holds user controls
        controlPanel.setLayout(new GridLayout(0,2,0,0));
        setsPanel = new JPanel();
        fixPanel = new JPanel();
		buttonPanel = new JPanel();	
			buttonPanel.setLayout(new GridLayout(3,2,5,3));	
		//comparePanel = new JPanel();  //holds controls for scanpath comparison     
        
        //initialise buttons
        getSourceImagesBtn = new JButton("Add images");
        	getSourceImagesBtn.addActionListener(this);
        	getSourceImagesBtn.setActionCommand("add_ims"); 
        getSourceDataBtn = new JButton("Add EM data");
        	getSourceDataBtn.addActionListener(this);
        	getSourceDataBtn.setActionCommand("add_ems"); 
        plotBtn = new JButton("Plot");
        	plotBtn.addActionListener(this);
        	plotBtn.setActionCommand("plot");	 
        resetBtn = new JButton("Reset");
        	resetBtn.addActionListener(this);
        	resetBtn.setActionCommand("reset"); 
        saveImage = new JButton("Save as image");
        	saveImage.addActionListener(this);
        	saveImage.setActionCommand("save"); 
		saveMap = new JButton("Save fixation density map");
        	saveMap.addActionListener(this);
        	saveMap.setActionCommand("savefm");
        displayOptionsBtn = new JButton("Options");
        	displayOptionsBtn.addActionListener(this);
        	displayOptionsBtn.setActionCommand("opt");          	        	
        allTrials=new JRadioButton("Load all sets"); 
        theseTrialsOnly=new JRadioButton("Load only sets with set name containing");
        allFixes=new JRadioButton("Load all fixations");
        theseFixesOnly=new JRadioButton("Load only fixations from");
        
        trialFilter=new JTextField(15);
        toFixModel =new SpinnerNumberModel(10, 1, 100,1);
		fromFixModel =new SpinnerNumberModel(1, 1, 100,1);
        fromFix=new JSpinner(fromFixModel);
        toFix=new JSpinner(toFixModel);
        lbl=new JLabel(" to ");
          
        //Group the radio buttons and add listeners
        ButtonGroup trialOptions = new ButtonGroup();
        trialOptions.add(allTrials);
        	allTrials.setSelected(true);
        trialOptions.add(theseTrialsOnly);
        	theseTrialsOnly.setSelected(false);   
        ButtonGroup fixOptions = new ButtonGroup();
        fixOptions.add(allFixes);
        	allFixes.setSelected(true);
        fixOptions.add(theseFixesOnly);
        	theseFixesOnly.setSelected(false);         	     	               	      	
        	
        //initialise lists
        imageListModel=new DefaultListModel();
        imageList=new JList (imageListModel);
        imageSP=new JScrollPane (imageList);
        makeList(imageList,imageListModel,imageSP);
        dataListModel=new DefaultListModel();
        dataList=new JList (dataListModel);
        dataSP=new JScrollPane (dataList);
        makeList(dataList,dataListModel,dataSP);  
        dataList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);         
        
        //add stuff to the panels
        displayProps=new DisplayProps(2);
		area=new MultiAreaJAI(displayProps);     
		imagePanel.add(area);
		
        sourcePanel.add(getSourceImagesBtn);
        sourcePanel.add(getSourceDataBtn);
		sourcePanel.add(imageSP);
        sourcePanel.add(dataSP);
		controlPanel.add(sourcePanel);
		
        buttonPanel.add(plotBtn);
		buttonPanel.add(displayOptionsBtn);
        buttonPanel.add(resetBtn);	
        buttonPanel.add(saveImage);  
        buttonPanel.add(saveMap);
		controlPanel.add(buttonPanel);	
										
		setsPanel.add(allTrials);
        setsPanel.add(theseTrialsOnly);
        setsPanel.add(trialFilter);		
								  		          
        fixPanel.add(allFixes);
        fixPanel.add(theseFixesOnly);
        fixPanel.add(fromFix);
        fixPanel.add(lbl);
        fixPanel.add(toFix);        
		     	
        mainPanel.add(imagePanel); 
        mainPanel.add(controlPanel);   	       
		mainPanel.add(setsPanel);
		mainPanel.add(fixPanel);
    }
    
    
    //METHOD REQUIRED BY THE ACTION LISTENER TRIGGERED BY BUTTON PRESS
    public void actionPerformed(ActionEvent event) 
    {
	    mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));//show egg-timer
	    
	    if (event.getActionCommand().equals("add_ims"))
	    {
	        //instantiates file chooser window which allows multiple files to be selected
	        imageFC = new JFileChooser("../my_files/images");
			imageFC.setMultiSelectionEnabled(true);
			String exts[]={"jpg", "bmp","gif","tiff"};
		    CustomFileFilter filter = new CustomFileFilter(exts, "Accepted image formats");
		    imageFC.setFileFilter(filter);			
			int returnVal = imageFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				//ie. not if cancelled
				{
					images=new File[imageFC.getSelectedFiles().length];
					images=imageFC.getSelectedFiles();
					getListItems(images,imageListModel);	//calls a method to add the names of the selected files to the list
				}				    
     	}         
     	
	    if (event.getActionCommand().equals("add_ems"))
	    {
	        dataFC = new JFileChooser("../my_files/data");
			dataFC.setMultiSelectionEnabled(true);
		    CustomFileFilter filter = new CustomFileFilter("txt","Text files");
		    dataFC.setFileFilter(filter);				
			int returnVal = dataFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					dataSources=new File[dataFC.getSelectedFiles().length];
					dataSources=dataFC.getSelectedFiles();
					getListItems(dataSources,dataListModel);
				}				    
     	}       	

     	if (event.getActionCommand().equals("opt"))
	    {
        //Create and set up the window.
        DisplayOptionsFrame = new JFrame("Display options");
        DisplayOptionsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //Create a new instance and so trigger constructor.
        DisplayOptions displayOptions = new DisplayOptions(displayProps,this);         
        DisplayOptionsFrame.setContentPane(displayOptions.mainPanel);
        DisplayOptionsFrame.pack();
        DisplayOptionsFrame.setLocationRelativeTo(this);
			displayOptions.showSacs.setSelected(true);
			displayOptions.showFix.setSelected(true);
			displayOptions.showNums.setSelected(true);
			displayOptions.showGrid.setSelected(true);	        
        DisplayOptionsFrame.setVisible(true);  						    
     	}
     	
     	if (event.getActionCommand().equals("plot"))
	    {     	     
		    //first load the background	   	 	  
	    	if((imageList.isSelectionEmpty())||(imageList.getSelectedValue()=="None"))
	    	{
	    	}
	    	else
	    	{
			 area.changeBackground(images[imageList.getSelectedIndex()-1].getAbsolutePath());   		
	 		}
			
			//set the fixation criteria
			if(theseFixesOnly.isSelected())
			{
			area.setFixationLimits(fromFixModel.getNumber().intValue()-1,toFixModel.getNumber().intValue()-1);
			}
			else
			{
			area.setFixationLimits(0,1000);	
			}
	 		
	 		//then parse each selected em file one at a time
		    if((dataList.isSelectionEmpty())||(dataList.getSelectedValue()=="None"))
		    {
			}
			else
			{
				for(int f=0;f<dataList.getSelectedValues().length;f++)
				{
					//parse this file, note takes index i+1 as list will always start with "None"
					fp=new FixParse(dataSources[dataList.getSelectedIndices()[f]-1].getAbsolutePath());
					//add the data to the plot if necessary
				    for(int t=0;t<fp.FixSeq.size();t++)
				    {
					    if(allTrials.isSelected())
					    {
							fp.FixSeq.elementAt(t).zoomCoords(displayProps);
							area.scanpaths.add(fp.FixSeq.elementAt(t));
						}	    
						else
						{
							if(theseTrialsOnly.isSelected() && fp.gettingNames && (fp.FixSeq.elementAt(t).fname.indexOf(trialFilter.getText())!=-1) )
							{
									fp.FixSeq.elementAt(t).zoomCoords(displayProps);
									area.scanpaths.add(fp.FixSeq.elementAt(t));
							}
						}
				    }
		    	}				
			}
			area.repaint();	 		
	    } 
	    
     	if (event.getActionCommand().equals("save"))
	    {   
		   JFileChooser saveFC = new JFileChooser("../my_files/output");
		   int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
		       Dimension size = area.getSize();
		       BufferedImage myImage = new BufferedImage(size.width, size.height,BufferedImage.TYPE_INT_RGB);
		       Graphics2D g2 = myImage.createGraphics();
		       area.paint(g2);
		       
		       File f=new File(saveFC.getSelectedFile().getAbsolutePath()+".jpg");
		       
		       try 
		       {
		         OutputStream out = new FileOutputStream(f);
		         JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
		         encoder.encode(myImage);
		         out.close();
		       } 
		       catch (Exception e) 
		       {
		         System.out.println(e); 
		       } 
			}
	    }	    
	    
     	if (event.getActionCommand().equals("reset"))
	    {     	     
		    resetPanels();	   	 	  
	    }	    
		
     	if (event.getActionCommand().equals("savefm"))
	    {     	     	   
			//loop through scanpaths and fixations and add 1 to pixels where fixated
			//don't change original scanpath but a copy
			int z=displayProps.displayZoom;
			//create the map at a scale 1/4th of the visible version
				DisplayProps dp=new DisplayProps(1);
				dp=displayProps;
				RawMapPixels fm=new RawMapPixels((dp.imagex/dp.displayZoom)/4,(dp.imagey/dp.displayZoom)/4);
				System.out.println("map dims "+fm.map.length+" , "+fm.map[0].length);				
				dp.displayZoom=4;			
				//use a very basic gaussian kernel to distribute the fixations
					//int kernel[][]=new int[13][13];
					int k1 []={1,1,1,1,1,1,1,1,1,1,1,1,1};
					int k2 []={1,17,17,17,17,17,17,17,17,17,17,17,1};
					int k3 []={1,17,118,118,118,118,118,118,118,118,118,17,1};
					int k4 []={1,17,118,371,371,371,371,371,371,371,118,17,1};
					int k5 []={1,17,118,371,623,623,623,623,623,371,118,17,1};
					int k6 []={1,17,118,371,623,724,724,724,623,371,118,17,1};
					int k7 []={1,17,118,371,623,724,740,724,623,371,118,17,1};
					int k8 []={1,17,118,371,623,724,724,724,623,371,118,17,1};
					int k9 []={1,17,118,371,623,623,623,623,623,371,118,17,1};
					int k10 []={1,17,118,371,371,371,371,371,371,371,118,17,1};
					int k11 []={1,17,118,118,118,118,118,118,118,118,118,17,1};
					int k12 []={1,17,17,17,17,17,17,17,17,17,17,17,1};
					int k13 []={1,1,1,1,1,1,1,1,1,1,1,1,1};
					int kernel[][]={k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13};			
					
			for(int s=0;s<area.scanpaths.size();s++)
			//for each scanpath...
			{
				//copy into a new fs
				FixationSequence fs=new FixationSequence();
				fs=area.scanpaths.elementAt(s);
				//fs.getSp();
				//scale the coords
				fs.zoomCoords(dp);
				//fs.getSp();
									
				System.out.println("plotting "+fs.fixations.size()+" fixations....");	
				//System.out.println("k6,6 "+kernel[6][6]);
				for(int f=area.minfix;f<fs.fixations.size();f++)
				//for each fixation
				{

					int x=fs.fixations.elementAt(f).x-6;
					int y=fs.fixations.elementAt(f).y-6;

					for(int a=0;a<13;a++)
					{
						for(int b=0;b<13;b++)
						{
							if(((x+a)<fm.map.length) && ((y+b)<fm.map[0].length) && ((x+a)>=0) && ((y+b)>=0))
							{
							fm.map[x+a][y+b]+=kernel[a][b];
							}				
						}
					}					
				/*/unless fixation is off screen, add to map
					if((fs.fixations.elementAt(f).x<fm.map.length) && (fs.fixations.elementAt(f).y<fm.map[0].length) && (fs.fixations.elementAt(f).x>=0) && (fs.fixations.elementAt(f).y>=0))
					{
					fm.map[fs.fixations.elementAt(f).x][fs.fixations.elementAt(f).y]+=1;
					}*/
					
					if(f==area.maxfix){f=fs.fixations.size();}	
				}
			}	 	  
			//fm.printMapToFile("/Users/xxxxxx/Desktop/debug1.pgm",1);
			fm.scaleToRange();
			//fm.printMapToFile("/Users/xxxxxx/Desktop/debug2.pgm",1);
		   JFileChooser saveFC = new JFileChooser("../my_files/output");
		   int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
				System.out.println("writing to file... "+saveFC.getSelectedFile().getAbsolutePath());
				fm.printMapToFile(saveFC.getSelectedFile().getAbsolutePath(),1);
			}			
		displayProps.displayZoom=z;
		}
	mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));//Return to normal cursor    	
	}
	
    
    //METHOD TO POPULATE LIST WITH FILE NAMES
    public void getListItems(File[] files, DefaultListModel model)
    {
	    //loop through the files and add the name of each one to the list
	    for(int f=0;f<files.length;f++)
	    {
			model.addElement(files[f].getName());	    
	    }
    }
    
    //METHOD TO SET-UP THE LIST COMPONENTS
    public void makeList(JList list,DefaultListModel model, JScrollPane spane)
    {
	    model.clear();
        model.addElement("None");
        list.setVisibleRowCount(-1);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        spane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        spane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        spane.setPreferredSize(new Dimension(80, 80));	    

    }      
    
    //METHOD TO RESET LABELS ETC.
    public void resetPanels()
    {
	    //remove the image and scanpaths
	    //area=new ScanpathAreaJAI(displayProps,this);
	    area.clearArea();
		imagePanel.remove(area);
		imagePanel.add(area);    	
    	//reset the trial list (leave selected files and images?)
    	//makeList(trialList,trialListModel,trialSP);
    	//reset entry options 	
    	
    }
	
    
    //METHOD TO RECEIVE NEW DISPLAY PROPS AND CLOSE
    public void passOptions(DisplayProps newprops)
    {
		DisplayOptionsFrame.dispose();
		if((newprops.imagex!=displayProps.imagex)||(newprops.imagey!=displayProps.imagey)||(newprops.displayZoom!=displayProps.displayZoom))
		{
			//if area has been resized, clear entered scanpaths to stop them being hidden, confused	
			area.clearArea();
		}
			
		displayProps=newprops;
		area.props=displayProps;
		area.setPreferredSize(new Dimension((displayProps.imagex/displayProps.displayZoom),(displayProps.imagey/displayProps.displayZoom)));		
		area.repaint();
		imagePanel.remove(area);
		imagePanel.add(area);
		validate();	
		pack();
		//mainPanel.paint();
    }   
   
}



