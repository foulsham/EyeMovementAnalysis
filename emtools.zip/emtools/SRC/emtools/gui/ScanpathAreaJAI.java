	  //*****************************
	  // Scanpath comparison programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

// ScanpathAreaJAI
//a class for building GUIs which displays a region and two scanpaths overlaid onto it

package emtools.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import javax.swing.event.MouseInputListener;
import javax.media.jai.*;
import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import java.awt.image.RenderedImage;
import javax.media.jai.InterpolationNearest;
import com.sun.media.jai.widget.DisplayJAI;
import com.sun.media.jai.mlib.*;
import java.awt.image.renderable.ParameterBlock;
import emtools.io.*;
import emtools.scanpath.*;

public class ScanpathAreaJAI extends DisplayJAI implements MouseInputListener {
	    //this is an abstract class which shows an area with an image and scanpath information
        
	    ScanpathComparison scanpaths;	//fixation sequences which can be displayed
	    DisplayProps props; //the display context
	    int scanpathNumber;//the scanpath which is currently being filled
    	ScanpathViewerJAI container;
    	boolean clickable=true;//flag for whether we are accepting clicks
    	
        public ScanpathAreaJAI(DisplayProps props,ScanpathViewerJAI container) 
        //CONSTRUCTOR
        {
	        super();//the standard constructor, leads to an empty panel
			this.props=props;
            addMouseListener(this);
            addMouseMotionListener(this);
			//setBorder(BorderFactory.createLoweredBevelBorder());
			this.setPreferredSize(new Dimension((props.imagex/props.displayZoom),(props.imagey/props.displayZoom)));
			setBackground(Color.WHITE);
        
            scanpathNumber=0;
            this.container=container;
			scanpaths=new ScanpathComparison(new FixationSequence(),new FixationSequence()); //constructs the (empty) scanpaths          			
        }
    
        public void paintComponent(Graphics g) {
	        //First paint the component, including the background picture if its there
	        super.paintComponent(g);
			g.setFont(new Font(g.getFont().getFontName(),Font.BOLD,14));
            //Paint grid.
            if(props.gridOn)
            {
            g.setColor(props.gridcol);
            int xdim=(props.imagex/props.displayZoom)/props.gridx;
            int ydim=(props.imagey/props.displayZoom)/props.gridy;
            drawGrid(g, xdim,ydim);
        	}
            
        	if(scanpaths.getSizes()[0]>0)//if the first scanpath is filled
        	{
	        //System.out.println(g.getFont().getSize()); 
	        System.out.println("A has size "+scanpaths.getSizes()[0]);	
	        //draw the fixation markers, saccades and numbers if necessary
	            if(props.fixOn)
		        {
			        g.setColor(props.fix1col);
	        		for (int i=0; i<scanpaths.spA.fixations.size(); i++)
		            {
			        int x=scanpaths.spA.fixations.elementAt(i).x;
		            int y=scanpaths.spA.fixations.elementAt(i).y;	
		            props.paintFix(g,x,y);				    		            	            
					//g.drawOval(x-((props.fixdim-1)/2), y -((props.fixdim-1)/2),props.fixdim, props.fixdim);		
					}
				}	        
				
	            if(props.sacsOn)
				{
					g.setColor(props.sac1col);
					for (int i=0; i<scanpaths.spA.fixations.size(); i++)
	            	{   				    		            	            
  						if(i>0)
  						{
			            int x=scanpaths.spA.fixations.elementAt(i).x;
			            int y=scanpaths.spA.fixations.elementAt(i).y;	
			            int x2=scanpaths.spA.fixations.elementAt(i-1).x;
			            int y2=scanpaths.spA.fixations.elementAt(i-1).y;		
			            props.paintSac(g,x,y,x2,y2);				     
				        //g.drawLine(x,y,x2,y2);
		        		}
					}
				}	
				
	            if(props.numsOn)
	            {
		            g.setColor(props.numcol);				        
        		    for (int i=0; i<scanpaths.spA.fixations.size(); i++)
	            	{
			            int x=scanpaths.spA.fixations.elementAt(i).x;
			            int y=scanpaths.spA.fixations.elementAt(i).y;	
			            Integer j=new Integer(i+1);				
			              //calls a method which draws a number slightly above the fixation
		                g.drawString(j.toString(),x,y-15);
            		}
            	}
        	}
			         
        	if(scanpaths.getSizes()[1]>0)//if the second scanpath is filled
        	{
	        
	        System.out.println("B has size "+scanpaths.getSizes()[1]);	
	        //draw the fixation markers, saccades and numbers if necessary
	            if(props.fixOn)
		        {
			        g.setColor(props.fix2col);
	        		for (int i=0; i<scanpaths.getSizes()[1]; i++)
		            {
			        int x=scanpaths.spB.fixations.elementAt(i).x;
		            int y=scanpaths.spB.fixations.elementAt(i).y;
		            props.paintFix(g,x,y);					    		            	            
					//g.drawOval(x-((props.fixdim-1)/2), y -((props.fixdim-1)/2),props.fixdim, props.fixdim);		
					}
				}	        
				
	            if(props.sacsOn)
				{
					g.setColor(props.sac2col);
					for (int i=0; i<scanpaths.getSizes()[1]; i++)
	            	{   				    		            	            
  						if(i>0)
  						{
			            int x=scanpaths.spB.fixations.elementAt(i).x;
			            int y=scanpaths.spB.fixations.elementAt(i).y;	
			            int x2=scanpaths.spB.fixations.elementAt(i-1).x;
			            int y2=scanpaths.spB.fixations.elementAt(i-1).y;	
			            props.paintSac(g,x,y,x2,y2);					     
				        //g.drawLine(x,y,x2,y2);
		        		}
					}
				}	
				
	            if(props.numsOn)
	            {
		            g.setColor(props.numcol);				        
        		    for (int i=0; i<scanpaths.getSizes()[1]; i++)
	            	{
			            int x=scanpaths.spB.fixations.elementAt(i).x;
			            int y=scanpaths.spB.fixations.elementAt(i).y;	
			            Integer j=new Integer(i+1);				
			              //calls a method which draws a number slightly above the fixation
		                g.drawString(j.toString(),x,y-15);
            		}
            	}
        	}						    
        }
        
        //Draws a grid using the current color.
        private void drawGrid(Graphics g, int gridSpaceX, int gridSpaceY) 
        {
	        //arguments give graphics context and number of divisions to make
            Insets insets = getInsets();
            int firstX = insets.left;
            int firstY = insets.top;
            int lastX = getWidth() - insets.right;
            int lastY = getHeight() - insets.bottom;
            
            //Draw vertical lines.
            int x = firstX;
            while (x < lastX) {
                g.drawLine(x, firstY, x, lastY);
                x += gridSpaceX;
            }
            
            //Draw horizontal lines.
            int y = firstY;
            while (y < lastY) {
                g.drawLine(firstX, y, lastX, y);
                y += gridSpaceY;
            }
        }

        public void clearArea()
        //clear the area
        { 
	        scanpathNumber=0;
	        scanpaths.spA.fixations.clear();
	        scanpaths.spB.fixations.clear();
            repaint();
     	}  	
     	
		public void changeBackground(String i)
		{	
			if(i!=null)
			{
				//make an image from the argument path
		        PlanarImage image,scaled_image;
		        image=JAI.create("fileload", i);
		        
			    //get the original image size
			    int x=image.getWidth();
			    int y=image.getHeight();
			    //System.out.println(x+" "+y);
			    
			    //get the zoomed image size
			    float scalex=(props.imagex/props.displayZoom);
			    float scaley=(props.imagey/props.displayZoom); 
			    //System.out.println(scalex+" "+scalex);
			    
			    //determine scale factor
			    scalex=scalex /x;
			    scaley=scaley /y;
			    //System.out.println(scalex+" "+scalex);
			    
			    if((scalex>0)&&(scaley>0))
			    //don't scale if already correct size
			    {
				    //create a pb and add the image, two floats indicating scaling, two floats indicating translation, and an interpolation constant
				    ParameterBlock pb= new ParameterBlock();
				    pb.addSource(image);
					pb.add(scalex);
					pb.add(scaley);
					pb.add(0.0f);
					pb.add(0.0f);
					pb.add(new InterpolationNearest());
					scaled_image=JAI.create("scale", pb);
					set(scaled_image);
				}
				else
				{
					set(image);	
				}	
			}
			else
			{
				removeAll();
			}
		}     	
        
        public void setClickable(boolean b)
        //controls whether area is accepting user clicks
        {
	        clickable=b;
        }        
            
        //Methods required by the MouseInputListener interface.
        public void mouseClicked(MouseEvent e) 
        {
	        if(clickable)
	        {
		        //when clicked, store the point, print to console and add to current scanpath
		        Point temp;
	            int x = e.getX();
	            int y = e.getY();
	
	            temp=new Point(x,y);
	            
	            if(scanpathNumber==0)
	            {
		         scanpathNumber++;   
	            }            
	            
	            if(scanpathNumber==1)
	            {
		            container.updateClickPoint(temp);
			        scanpaths.spA.fixations.add(temp);		        
		            System.out.println("adding "+temp+ " to " +scanpathNumber);
	            }
	            
	            if(scanpathNumber==2)
	            {
		            container.updateClickPoint(temp);
			        scanpaths.spB.fixations.add(temp);		        
		            System.out.println("adding "+temp+ " to " +scanpathNumber);
		            System.out.println(scanpaths.spB.fixations.elementAt(0));
	            }
	
	            //selector.updateClickPoint(scanpaths[scanpathNumber].fixations[1]); //feed back to host component*/
	            repaint();
        	}
        }

        public void mouseMoved(MouseEvent e) 
        {	
	        //if there is a map window open, update the mouse tracking label
	        if(container.mv!=null)
	        {
		        int x=e.getX();
				int y=e.getY(); 
				container.mv.updateValue(x,y);
				container.mv.dj.p=new Point(x,y);
				container.mv.dj.repaint();
			}
		}
		//when within this component, display a marker on the mv
        public void mouseExited(MouseEvent e) 
        {
	       	if(container.mv!=null)
	        {
				container.mv.dj.markerOn=false;
				container.mv.dj.repaint();
			}
		}
        public void mouseReleased(MouseEvent e) { }
        public void mouseEntered(MouseEvent e) 
        { 
	        if(container.mv!=null)
	        {
				container.mv.dj.markerOn=true;
			}	        
	    }
        public void mousePressed(MouseEvent e) { }
        public void mouseDragged(MouseEvent e) { }
    }