	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/*
ScanpathViewerJAI
 a GUI class which does the following:
	-displays one (of a set) of stimuli
	-displays one or two (of a set) of scanpaths overlaid onto this stimulus
	-optionally displays one (of a set) of matching feature/salience maps
	-allows user to save display to an image

*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.text.Position.*;
import java.net.URL;
import java.awt.event.MouseEvent;
import javax.swing.event.*;
import java.io.*;
import java.awt.image.*;
import com.sun.image.codec.jpeg.*;
import emtools.io.*;
import emtools.scanpath.*;


public class ScanpathViewerJAI extends JFrame implements ActionListener, ItemListener, ListSelectionListener,ChangeListener
{
	
	//GUI COMPONENTS
	static JPanel mainPanel,imagePanel,sourcePanel,controlPanel,comparePanel;	//creates panels	
	//static JLabel leftString, rightString, feedback;	//labels to show strings and comparison
    static JButton getSourceImagesBtn,getSourceDataBtn,loadTrialsBtn,getSourceMapsBtn;//buttons to load external data
    static JButton plotBtn,resetBtn,displayOptionsBtn,doneBtn,addSecond;	//buttons for other options
    static JButton saveImage,compSP;
    static JList imageList,dataList,trialList,mapList;//list the chosen files to display
    DefaultListModel imageListModel,dataListModel,trialListModel,mapListModel;
    static JScrollPane imageSP,dataSP,trialSP,mapSP; //scroll panes for long lists
    static JFileChooser imageFC,dataFC,mapFC;//allow user to select the files they want
    File [] images,dataSources,maps;//the chosen files
    static JRadioButton fromFile,fromClick; //buttons to choose what to do 
    
    static ScanpathAreaJAI area;
    	
    //GRAPHIC VARIABLES (to control properties of the scanpath display, uses DisplayProps class)
	DisplayProps displayProps;
	
	//FIXATION DATA VARIABLES
	FixParse fp; //an instance of the fix parsing class which will hold all trials/sets from one data file
	
	//OTHER FRAMES WHICH WILL BE LAUNCHED WHEN NECESSARY
    JFrame DisplayOptionsFrame;
    MapViewer mv;
    
    //ImageIcon bground;
	
    //CONSTRUCTOR WHICH BUILDS THE GUI
    public ScanpathViewerJAI()
    {
	    //BUILD PANELS
	    mainPanel = new JPanel();//contains everything else
	    	mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
	    imagePanel = new JPanel();	//holds image and scanpath
	    sourcePanel = new JPanel();	//holds controls regarding which picture / data to use
	    	sourcePanel.setLayout(new GridLayout(3,4,5,3));
        controlPanel = new JPanel();	//holds user controls
        comparePanel = new JPanel();  //holds controls for scanpath comparison     
        
        //initialise buttons
        getSourceImagesBtn = new JButton("Add images");
        	getSourceImagesBtn.addActionListener(this);
        	getSourceImagesBtn.setActionCommand("add_ims"); 
        getSourceDataBtn = new JButton("Add EM data");
        	getSourceDataBtn.addActionListener(this);
        	getSourceDataBtn.setActionCommand("add_ems"); 
        loadTrialsBtn = new JButton("Load trials....");
        	loadTrialsBtn.addActionListener(this);
        	loadTrialsBtn.setActionCommand("load_trials");        	 
        getSourceMapsBtn = new JButton("Add maps");
        	getSourceMapsBtn.addActionListener(this);
        	getSourceMapsBtn.setActionCommand("add_maps");
        plotBtn = new JButton("Plot");
        	plotBtn.addActionListener(this);
        	plotBtn.setActionCommand("plot");
        	plotBtn.setEnabled(false);	
        displayOptionsBtn = new JButton("Options");
        	displayOptionsBtn.addActionListener(this);
        	displayOptionsBtn.setActionCommand("opt");   
        addSecond = new JButton("Add to 2nd scanpath");
        	addSecond.setEnabled(false);
        	addSecond.addActionListener(this);
        	addSecond.setActionCommand("add_sp");   
        resetBtn = new JButton("Reset");
        	resetBtn.addActionListener(this);
        	resetBtn.setActionCommand("reset"); 
        saveImage = new JButton("Save as image");
        	saveImage.addActionListener(this);
        	saveImage.setActionCommand("save"); 
        compSP = new JButton("Compare scanpaths...");
        	compSP.addActionListener(this);
        	compSP.setActionCommand("comp");        	        	
        fromFile=new JRadioButton("Plot from file"); 
        fromClick=new JRadioButton("Select manually");
        
        //Group the radio buttons and add listeners
        ButtonGroup options = new ButtonGroup();
        options.add(fromFile);
        	fromFile.addActionListener(this);
        	fromFile.setActionCommand("fromfile");
        	fromFile.setSelected(false);
        options.add(fromClick);
        	fromClick.addActionListener(this);
        	fromClick.setActionCommand("fromclick");
        	fromClick.setSelected(true);        	               	      	
        	
        //initialise lists
        imageListModel=new DefaultListModel();
        imageList=new JList (imageListModel);
        imageSP=new JScrollPane (imageList);
        makeList(imageList,imageListModel,imageSP);
        	imageList.addListSelectionListener(this);
        dataListModel=new DefaultListModel();
        dataList=new JList (dataListModel);
        dataSP=new JScrollPane (dataList);
        makeList(dataList,dataListModel,dataSP);
        trialListModel=new DefaultListModel();
        trialList=new JList (trialListModel);
        trialSP=new JScrollPane (trialList);     
        	//trialList.addListSelectionListener(this);   
        makeList(trialList,trialListModel,trialSP);        
        mapListModel=new DefaultListModel();
        mapList=new JList (mapListModel);
        mapSP=new JScrollPane (mapList);
        makeList(mapList,mapListModel,mapSP);
        	mapList.addListSelectionListener(this);
        
        //data lists and source buttons are disabled to begin with
        dataList.setEnabled(false);
        trialList.setEnabled(false);
        getSourceDataBtn.setEnabled(false);
        loadTrialsBtn.setEnabled(false);            
        
        //add stuff to the panels
        displayProps=new DisplayProps(1);
        sourcePanel.add(getSourceImagesBtn);
        sourcePanel.add(getSourceDataBtn);
        sourcePanel.add(loadTrialsBtn);
        sourcePanel.add(getSourceMapsBtn);
		area=new ScanpathAreaJAI(displayProps,this);        
          
        sourcePanel.add(imageSP);
        sourcePanel.add(dataSP);
        sourcePanel.add(trialSP);
        sourcePanel.add(mapSP); 
        sourcePanel.add(plotBtn);
        sourcePanel.add(fromFile);
        sourcePanel.add(fromClick);
        sourcePanel.add(addSecond);
        controlPanel.add(displayOptionsBtn);
        controlPanel.add(saveImage);      
        controlPanel.add(compSP); 	
        controlPanel.add(resetBtn);
        imagePanel.add(area); 
        mainPanel.add(sourcePanel); 
        mainPanel.add(imagePanel); 
        mainPanel.add(controlPanel);   	       
    }
    
    
    //METHOD REQUIRED BY THE ACTION LISTENER TRIGGERED BY BUTTON PRESS
    public void actionPerformed(ActionEvent event) 
    {
	    mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));//show egg-timer
	    
	    if (event.getActionCommand().equals("add_ims"))
	    {
	        //instantiates file chooser window which allows multiple files to be selected
	        imageFC = new JFileChooser("../my_files/images");
			imageFC.setMultiSelectionEnabled(true);
			String exts[]={"jpg", "bmp","gif","tiff"};
		    CustomFileFilter filter = new CustomFileFilter(exts, "Accepted image formats");
		    imageFC.setFileFilter(filter);			
			int returnVal = imageFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				//ie. not if cancelled
				{
					images=new File[imageFC.getSelectedFiles().length];
					images=imageFC.getSelectedFiles();
					getListItems(images,imageListModel);	//calls a method to add the names of the selected files to the list
				}				    
     	}         
     	
	    if (event.getActionCommand().equals("add_ems"))
	    {
	        dataFC = new JFileChooser("../my_files/data");
			dataFC.setMultiSelectionEnabled(true);
		    CustomFileFilter filter = new CustomFileFilter("txt","Text files");
		    dataFC.setFileFilter(filter);				
			int returnVal = dataFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					dataSources=new File[dataFC.getSelectedFiles().length];
					dataSources=dataFC.getSelectedFiles();
					getListItems(dataSources,dataListModel);
				}				    
     	}    
     	
	    if (event.getActionCommand().equals("add_maps"))
	    {
	        mapFC = new JFileChooser("../my_files/maps");
			mapFC.setMultiSelectionEnabled(true);
			String exts[]={"jpg", "bmp","ppm","pgm","pnm"};
		    CustomFileFilter filter = new CustomFileFilter(exts, "Accepted image formats");
		    mapFC.setFileFilter(filter);				
			int returnVal = mapFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					maps=new File[mapFC.getSelectedFiles().length];
					maps=mapFC.getSelectedFiles();
					getListItems(maps,mapListModel);
				}				    
     	}   
     	
	    if (event.getActionCommand().equals("load_trials"))
	    {
		    //reset the trial list
		    makeList(trialList,trialListModel,trialSP);
		    if(fp!=null)
		    {
			 fp.reset();   
		    }
		    
		    //only if a data file has been selected
		    if((dataList.isSelectionEmpty())||(dataList.getSelectedValue()=="None"))
		    {
			}
			else
			{
			//parse this file, note takes index i+1 as list will always start with "None"
			fp=new FixParse(dataSources[dataList.getSelectedIndex()-1].getAbsolutePath());
				//add the trial names to the trial list
			    for(int t=0;t<fp.FixSeq.size();t++)
			    {
					trialListModel.addElement(fp.FixSeq.elementAt(t).fname);	    
			    }				
			}							    
     	}      	

     	if (event.getActionCommand().equals("opt"))
	    {
        //Create and set up the window.
        DisplayOptionsFrame = new JFrame("Display options");
        DisplayOptionsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //Create a new instance and so trigger constructor.
        DisplayOptions displayOptions = new DisplayOptions(displayProps,this);         
        DisplayOptionsFrame.setContentPane(displayOptions.mainPanel);
        DisplayOptionsFrame.pack();
        DisplayOptionsFrame.setLocationRelativeTo(this);    
        DisplayOptionsFrame.setVisible(true);  						    
     	}
     	
     	if (event.getActionCommand().equals("plot"))
     	//if a trial is selected then get the relevant scanpath and display it
	    {     	     	   	 	  
		    //only if a trial file has been selected
		    if((trialList.isSelectionEmpty())||(trialList.getSelectedValue()=="None"))
		    {
			}
			else
			{
			//pass the fixation sequence to the scanpath area label
				if(area.scanpathNumber==0)
				{
					area.scanpaths.spA=fp.FixSeq.elementAt(trialList.getSelectedIndex()-1);
						if(displayProps.displayZoom!=1)
						{
							//if necessary zoom the coordinates
							area.scanpaths.spA.zoomCoords(displayProps);
						}
					area.scanpathNumber++;			
				}

				//if possible auto-select a background
				if((((String)trialList.getSelectedValue()).substring(0,5)!="Trial ")&&(imageListModel.size()>1))
				{
					int i=imageList.getNextMatch(((String)trialList.getSelectedValue()),1,javax.swing.text.Position.Bias.Forward);
					if(i!=-1)
					{
					area.changeBackground(images[i-1].getAbsolutePath());						
					}
				}
				
				//if possible auto-select a map, looking for a filename but with a different extension
				if((((String)trialList.getSelectedValue()).substring(0,5)!="Trial ")&&(mapListModel.size()>1))
				{
					String st=(String)trialList.getSelectedValue();
					st=st.substring(0,st.length()-4);
					int i=mapList.getNextMatch(st,1,javax.swing.text.Position.Bias.Forward);
					if(i!=-1)
					{
					mapList.setSelectedIndex(i);//trigger the listener						
					}
				}				
				area.repaint();					
			}
			plotBtn.setEnabled(false);
			addSecond.setEnabled(true);
	    } 

     	if (event.getActionCommand().equals("fromfile"))
	    {     	     	   	 	  
		  addSecond.setEnabled(false);
		  plotBtn.setEnabled(true);
		  area.clearArea();
		  area.setClickable(false);
	        dataList.setEnabled(true);
	        trialList.setEnabled(true);
	        getSourceDataBtn.setEnabled(true);
	        loadTrialsBtn.setEnabled(true);	    
	    }	
	    
     	if (event.getActionCommand().equals("save"))
	    {   
		   JFileChooser saveFC = new JFileChooser("../my_files/output");			   
		   int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
		       Dimension size = area.getSize();
		       BufferedImage myImage = new BufferedImage(size.width, size.height,BufferedImage.TYPE_INT_RGB);
		       Graphics2D g2 = myImage.createGraphics();
		       area.paint(g2);
		       
		       File f=new File(saveFC.getSelectedFile().getAbsolutePath()+".jpg");
		       try 
		       {
		         OutputStream out = new FileOutputStream(f);
		         JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
		         encoder.encode(myImage);
		         out.close();
		       } 
		       catch (Exception e) 
		       {
		         System.out.println(e); 
		       } 
			}
	    }	    
	    
     	if (event.getActionCommand().equals("fromclick"))
	    {     	     	   	 	  
		  plotBtn.setEnabled(false);
		  area.clearArea();  
		  area.setClickable(true);
	        dataList.setEnabled(false);
	        trialList.setEnabled(false);
	        getSourceDataBtn.setEnabled(false);
	        loadTrialsBtn.setEnabled(false);  
	    }	        	        	

     	if (event.getActionCommand().equals("add_sp"))
     	
	    {
		       	     	   	 	  
		  addSecond.setEnabled(false);  
		  
				if(fromFile.isSelected())
				{
					if(area.scanpathNumber==1)
					{
						area.scanpaths.spB=fp.FixSeq.elementAt(trialList.getSelectedIndex()-1);
							if(displayProps.displayZoom!=1)
							{
								//if necessary zoom the coordinates
								area.scanpaths.spB.zoomCoords(displayProps);
							}
						area.repaint();		
					}
				
				}
			area.scanpathNumber++;		  
	    }

     	if (event.getActionCommand().equals("comp"))
	    {     	     
		    //launch the comparison window, first killing any previous windows
		    	if(area.scanpaths.scf!=null)
		    	{
		    	area.scanpaths.scf.dispose();
	    		}	
	    		area.scanpaths.showComparisonFrame(mainPanel.getBounds().height);	
	    		area.scanpaths.scf.setLocation((this.getBounds().x+this.getBounds().width),0);  
	    		area.scanpaths.doComparison(area.props);	   	 	  
	    }	    
	    	    
     	if (event.getActionCommand().equals("reset"))
	    {     	     
		    resetPanels();	   	 	  
	    }	
	    
	 mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));//Return to normal cursor      
    }
    
    public void itemStateChanged(ItemEvent e) 
    {

	}
	
	public void valueChanged(ListSelectionEvent e) 
	{
    	if (e.getValueIsAdjusting() == false)
    	{
	    	if(e.getSource()==imageList)
	    	//if user has selected a new image
	    	{
		    	if((imageList.isSelectionEmpty())||(imageList.getSelectedValue()=="None"))
		    	{
			    area.changeBackground(null);
		    	}
		    	else
		    	{
			    //change the background 
				 area.changeBackground(images[imageList.getSelectedIndex()-1].getAbsolutePath());   		
		 		}
		    	if(imageList.getSelectedValue()=="None")
		    	//if they've chosen None, remove the icon altogether
		    	{
			    
		    	}		 		
 			}
 			
	    	if(e.getSource()==mapList)
	    	//if user has selected a map
	    	{
		    	//kill any previous windows
		    	if(mv!=null)
		    	{
		    	mv.dispose();
	    		}
		    	if((mapList.isSelectionEmpty())||(mapList.getSelectedValue()=="None"))
		    	{
		    	}
		    	else
		    	{
			    //make a new map viewer frame and display the chosen map
				mv=new MapViewer(maps[mapList.getSelectedIndex()-1].getAbsolutePath(),displayProps);
				//position the viewer to the right of the main program
				mv.setLocation((this.getBounds().x+this.getBounds().width),0);
		 		}
		    	if(mapList.getSelectedValue()=="None")
		    	//if they've chosen None, close the map viewer window
		    	{
				    	if(mv!=null)
				    	{
				    	mv.dispose();
			    		}
		    	}		 		
 			} 			
    	}
	}
	
	public void stateChanged(ChangeEvent e) 
	{
      
    } 
    
    //METHOD TO BE CALLED BY THE MOUSE LISTENER CLASS
 	public static void updateClickPoint(Point p)
    {
	    if(area.scanpathNumber==1)
	    {
  		addSecond.setEnabled(true);
		}
    }
    
    //METHOD TO POPULATE LIST WITH FILE NAMES
    public void getListItems(File[] files, DefaultListModel model)
    {
	    //loop through the files and add the name of each one to the list
	    for(int f=0;f<files.length;f++)
	    {
			model.addElement(files[f].getName());	    
	    }
    }
    
    //METHOD TO SET-UP THE LIST COMPONENTS
    public void makeList(JList list,DefaultListModel model, JScrollPane spane)
    {
	    model.clear();
        model.addElement("None");
        list.setVisibleRowCount(-1);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        spane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        spane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        spane.setPreferredSize(new Dimension(150, 80));	    

    }      
    
    //METHOD TO RESET LABELS ETC.
    public void resetPanels()
    {
	    //remove the image and scanpaths
	    //area=new ScanpathAreaJAI(displayProps,this);
	    area.clearArea();
		imagePanel.remove(area);
		imagePanel.add(area);    	
    	//reset the trial list (leave selected files and images?)
    	//makeList(trialList,trialListModel,trialSP);
    	//reset entry options
    	fromFile.setSelected(false);
    	fromClick.setSelected(true);
    	fromClick.doClick();
    	addSecond.setEnabled(false);
    	//kill any mv windows
    	if(mv!=null)
    	{
    	mv.dispose();
		}    	
    	if(area.scanpaths.scf!=null)
    	{
    	area.scanpaths.scf.dispose();
		}    	
    }
    
    
    //METHOD TO RECEIVE NEW DISPLAY PROPS AND CLOSE
    public void passOptions(DisplayProps newprops)
    {
		DisplayOptionsFrame.dispose();
		if((newprops.imagex!=displayProps.imagex)||(newprops.imagey!=displayProps.imagey)||(newprops.displayZoom!=displayProps.displayZoom))
		{
			//if area has been resized, clear entered scanpaths to stop them being hidden, confused	
			area.clearArea();
		}
    	//kill any mv windows
    	if(mv!=null)
    	{
    	mv.dispose();
		}    			
		displayProps=newprops;
		area.props=displayProps;
		area.setPreferredSize(new Dimension((displayProps.imagex/displayProps.displayZoom),(displayProps.imagey/displayProps.displayZoom)));		
		area.repaint();
		imagePanel.remove(area);
		imagePanel.add(area);
		validate();	
		pack();
		//mainPanel.paint();
    }   
   
}



