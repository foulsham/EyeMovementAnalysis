	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* a GUI class which does the following:
	-allows user to choose data files and ROIs
	-collects info from the data files on fixations in the ROIs

*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.text.Position.*;
import java.net.URL;
import javax.swing.event.*;
import java.io.*;
import emtools.io.*;
import emtools.scanpath.*;

public class RegionAnalyser extends JFrame implements ActionListener
{
	
	//GUI COMPONENTS
	static JPanel mainPanel,controlPanel,sourcePanel,setsPanel,fixPanel,buttonPanel;	//creates panels	
    static JButton getROIsBtn,getSourceDataBtn;//buttons to load external data
    static JButton outputBtn;	//buttons for other options
    static JList roiList,dataList;//list the chosen files to display
    DefaultListModel roiListModel,dataListModel;
    static JScrollPane roiSP,dataSP; //scroll panes for long lists
    static JFileChooser roiFC,dataFC;//allow user to select the files they want
    File [] rois,dataSources;//the chosen files
    static JRadioButton allTrials,matchROIFile,matchROIID,allFixes,theseFixesOnly; //buttons to choose what to do 
    
    //static JTextField trialFilter;
    static JSpinner fromFix,toFix;
    static SpinnerNumberModel fromFixModel, toFixModel;
    static JLabel lbl; 
	
	//options for what to report
	static JCheckBox fixReport,roiReport,incFixCount,incTotalFix,incFFI,incRoiID,incRegDist,incNearestID;
	
	//FIXATION DATA VARIABLES
	FixParse fp; //an instance of the fix parsing class which will hold all trials/sets from one data file
	RandomAccessFile fileOut,fixFileOut; //files to output to
	
    //CONSTRUCTOR WHICH BUILDS THE GUI
    public RegionAnalyser()
    {
	    //BUILD PANELS
	    mainPanel = new JPanel();//contains everything else
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
	    	//mainPanel.setLayout(new GridLayout(0,1,5,3));
		sourcePanel = new JPanel();	//holds controls regarding which picture / data to use
			sourcePanel.setLayout(new GridLayout(2,2,5,3));
        controlPanel = new JPanel();	//holds user controls
        controlPanel.setLayout(new GridLayout(4,2,0,0));
        setsPanel = new JPanel();
        fixPanel = new JPanel();
		//comparePanel = new JPanel();  //holds controls for scanpath comparison     
        
        //initialise buttons
        getROIsBtn = new JButton("Add ROI files");
        	getROIsBtn.addActionListener(this);
        	getROIsBtn.setActionCommand("add_rois"); 
        getSourceDataBtn = new JButton("Add EM data");
        	getSourceDataBtn.addActionListener(this);
        	getSourceDataBtn.setActionCommand("add_ems"); 
        outputBtn = new JButton("Output");
        	outputBtn.addActionListener(this);
        	outputBtn.setActionCommand("output");	          	        	
        allTrials=new JRadioButton("Include all sets"); 
        matchROIFile=new JRadioButton("Match set to ROI filename");
        matchROIID=new JRadioButton("Match set to ROI ID");
        matchROIFile=new JRadioButton("Include only sets which match ROI name");
        allFixes=new JRadioButton("Load all fixations");
        theseFixesOnly=new JRadioButton("Load only fixations from");
        
        toFixModel =new SpinnerNumberModel(10, 1, 100,1);
		fromFixModel =new SpinnerNumberModel(1, 1, 100,1);
        fromFix=new JSpinner(fromFixModel);
        toFix=new JSpinner(toFixModel);
        lbl=new JLabel(" to ");
          
        //Group the radio buttons and add listeners
        ButtonGroup trialOptions = new ButtonGroup();
        trialOptions.add(allTrials);
        	allTrials.setSelected(true);
        trialOptions.add(matchROIFile);
        	matchROIFile.setSelected(false);   
        trialOptions.add(matchROIID);
        	matchROIID.setSelected(false);          	
        ButtonGroup fixOptions = new ButtonGroup();
        fixOptions.add(allFixes);
        	allFixes.setSelected(true);
        fixOptions.add(theseFixesOnly);
        	theseFixesOnly.setSelected(false);         	     	               	      	
        	
        //initialise lists
        roiListModel=new DefaultListModel();
        roiList=new JList (roiListModel);
        roiSP=new JScrollPane (roiList);
        makeList(roiList,roiListModel,roiSP);
        dataListModel=new DefaultListModel();
        dataList=new JList (dataListModel);
        dataSP=new JScrollPane (dataList);
        makeList(dataList,dataListModel,dataSP);  
        dataList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);         
		
		//initialise the checkboxes
		fixReport=new JCheckBox("Output fixation data file",false);
		roiReport=new JCheckBox("Output ROI data file",true);
		incFixCount=new JCheckBox("Fixation count",true);
		incTotalFix=new JCheckBox("Total fixation count",true);
		incFFI=new JCheckBox("First fixation index",true);
		incRoiID=new JCheckBox("Fixated region ID",true);
		incNearestID=new JCheckBox("Nearest region ID",true);
		incRegDist=new JCheckBox("Distance to centre of nearest region",true);
        
        //add stuff to the panels	
        sourcePanel.add(getROIsBtn);
        sourcePanel.add(getSourceDataBtn);
		sourcePanel.add(roiSP);
        sourcePanel.add(dataSP);
		mainPanel.add(sourcePanel);

		setsPanel.add(allTrials);
        setsPanel.add(matchROIFile);
        setsPanel.add(matchROIID);								  		          
        fixPanel.add(allFixes);
        fixPanel.add(theseFixesOnly);
        fixPanel.add(fromFix);
        fixPanel.add(lbl);
        fixPanel.add(toFix);  
		mainPanel.add(setsPanel);
		mainPanel.add(fixPanel);
				
		controlPanel.add(roiReport);	
		controlPanel.add(fixReport);
		controlPanel.add(incFixCount);
		controlPanel.add(incRoiID);								
      	controlPanel.add(incTotalFix);
      	controlPanel.add(incNearestID);
      	controlPanel.add(incFFI);
      	controlPanel.add(incRegDist);
		     	
        mainPanel.add(controlPanel);
        mainPanel.add(outputBtn);   	       
    }
    
    
    //METHOD REQUIRED BY THE ACTION LISTENER TRIGGERED BY BUTTON PRESS
    public void actionPerformed(ActionEvent event) 
    {
	mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));//show egg-timer
	    if (event.getActionCommand().equals("add_rois"))
	    {
	        //instantiates file chooser window which allows multiple files to be selected
	        roiFC = new JFileChooser("../my_files/rois");
			roiFC.setMultiSelectionEnabled(true);
		    CustomFileFilter filter = new CustomFileFilter("txt","Text files");
		    roiFC.setFileFilter(filter);			
			int returnVal = roiFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				//ie. not if cancelled
				{
					rois=new File[roiFC.getSelectedFiles().length];
					rois=roiFC.getSelectedFiles();
					getListItems(rois,roiListModel);	//calls a method to add the names of the selected files to the list
				}				    
     	}         
     	
	    if (event.getActionCommand().equals("add_ems"))
	    {
	        dataFC = new JFileChooser("../my_files/data");
			dataFC.setMultiSelectionEnabled(true);
		    CustomFileFilter filter = new CustomFileFilter("txt","Text files");
		    dataFC.setFileFilter(filter);				
			int returnVal = dataFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					dataSources=new File[dataFC.getSelectedFiles().length];
					dataSources=dataFC.getSelectedFiles();
					getListItems(dataSources,dataListModel);
				}				    
     	}   
		
	    if (event.getActionCommand().equals("output") && (rois.length>0) && (dataList.getSelectedIndex()>0) && (roiReport.isSelected() || fixReport.isSelected()) )
	    {
			//if we're not including all fixations, get fixation limits
			int min,max;
			if(allFixes.isSelected())
			{
			min=0;
			max=10000;
			}
			else
			{
			min=fromFixModel.getNumber().intValue()-1;
			max=toFixModel.getNumber().intValue()-1;
			}
			
			//output the data to a text file with headings
			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
				System.out.println("writing to file... "+saveFC.getSelectedFile().getAbsolutePath());
				try
				{
					//create output files and headings where necessary				
					if(roiReport.isSelected())
					{
					fileOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath() + "_ROI.txt", "rw");
					fileOut.writeBytes("DATA_FILE"+"\t"+"SET_NAME" +"\t"+"ROI_FILE"+"\t"+ "ROI_ID");
						if(incTotalFix.isSelected()){fileOut.writeBytes("\t" + "TOTAL_FIXATIONS_CHECKED") ;}
						if(incFixCount.isSelected()){fileOut.writeBytes("\t" + "NUMBER_WITHIN_ROI") ;}
						if(incFFI.isSelected()){fileOut.writeBytes("\t" + "FIRST_FIXATION_INDEX") ;}
					fileOut.writeBytes("\n");
					}
					
					if(fixReport.isSelected())
					{					
					fixFileOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath() + "_FIX.txt", "rw");
					fixFileOut.writeBytes("DATA_FILE"+"\t"+"SET_NAME" +"\t"+"FIX_INDEX");
						if(incRoiID.isSelected()){fixFileOut.writeBytes("\t" + "ROI_ID") ;}
						if(incNearestID.isSelected()){fixFileOut.writeBytes("\t" + "NEAREST_ROI_ID") ;}
						if(incRegDist.isSelected()){fixFileOut.writeBytes("\t" + "DISTANCE_TO_NEAREST_ROI") ;}
					fixFileOut.writeBytes("\n");				
					}
				
					//If we're just analysing all trials with one ROI, and one is selected
					if(allTrials.isSelected() && (roiList.getSelectedIndex()>0))
					{
						//load the ROIs
						ROI r=new ROI();
						r.loadFromFile(rois[roiList.getSelectedIndex()-1].getAbsolutePath());
						String roilbl=r.label;	//roi file name
						
						//loop through data files
						for(int f=0;f<dataList.getSelectedValues().length;f++)
						{
							//parse this file, and loop through the scanpaths
							fp=new FixParse(dataSources[dataList.getSelectedIndices()[f]-1].getAbsolutePath());
							String d=dataSources[dataList.getSelectedIndices()[f]-1].getName();//data file name
							for(int t=0;t<fp.FixSeq.size();t++)
							{
								String s=fp.FixSeq.elementAt(t).fname;	//set name 
								
								//if we're getting roi data, scroll through the rois and each fixation to get the data
								if(roiReport.isSelected())
								{
									for(int roiCount=0;roiCount<r.rois.size();roiCount++)
									{
										int total=0,numberwithin=0,first=-1;									
										fileOut.writeBytes(d + "\t" + s + "\t" + roilbl + "\t" + r.ids.elementAt(roiCount));	//roi id
										for(int fix=min;fix<fp.FixSeq.elementAt(t).fixations.size();fix++)
										{
											total++;	//total fixations checked
											if(r.rois.elementAt(roiCount).contains(fp.FixSeq.elementAt(t).fixations.elementAt(fix)))
											{
												numberwithin++;	//number within roi
												if(numberwithin==1){first=fix;}	//first fix index
											}
											if(fix==max){fix=fp.FixSeq.elementAt(t).fixations.size();}
										}
										
									if(incTotalFix.isSelected()){fileOut.writeBytes("\t" + total) ;}
									if(incFixCount.isSelected()){fileOut.writeBytes("\t" + numberwithin) ;}
									if(incFFI.isSelected())
									{
										if(first==-1){fileOut.writeBytes("\t" + ".") ;}
										else{fileOut.writeBytes("\t" + (first+1)) ;}
									}
									fileOut.writeBytes("\n");
									
									}
								}
															
								//if we're getting fix data scroll through the fixations
								if(fixReport.isSelected())
								{								
									for(int fix=min;fix<fp.FixSeq.elementAt(t).fixations.size();fix++)
									{
										fixFileOut.writeBytes(d + "\t" + s + "\t" + (fix+1));
											if(incRoiID.isSelected())
											{
												int a=r.contains(fp.FixSeq.elementAt(t).fixations.elementAt(fix));//roiID
												if(a==-1){fixFileOut.writeBytes("\t" + ".");}
												else{fixFileOut.writeBytes("\t" + r.ids.elementAt(a));}
											}
											int b=r.getNearest(fp.FixSeq.elementAt(t).fixations.elementAt(fix));
											if(incNearestID.isSelected()){fixFileOut.writeBytes("\t" + r.ids.elementAt(b)) ;}
											if(incRegDist.isSelected()){fixFileOut.writeBytes("\t" + r.getDistance(fp.FixSeq.elementAt(t).fixations.elementAt(fix),b)) ;}
										fixFileOut.writeBytes("\n");
										if(fix==max){fix=fp.FixSeq.elementAt(t).fixations.size();}
									}	
								}							
								
							}
						}			
					}
						
					//If we're matching IAs to trial names
					if (matchROIFile.isSelected() )
					{
						//loop through data files
						for(int f=0;f<dataList.getSelectedValues().length;f++)
						{
							//parse this file, and loop through the scanpaths
							fp=new FixParse(dataSources[dataList.getSelectedIndices()[f]-1].getAbsolutePath());
							String d=dataSources[dataList.getSelectedIndices()[f]-1].getName();//data file name
							for(int t=0;t<fp.FixSeq.size();t++)
							{
								String s=fp.FixSeq.elementAt(t).fname;	//set name 
								//look for a ROI file with this name, but a different extension
								int i=roiList.getNextMatch(s.substring(0,s.length()-4),1,javax.swing.text.Position.Bias.Forward);
								if(i!=-1)//if a match is found
								{
									//load the ROIs
									ROI r=new ROI();
									r.loadFromFile(rois[i-1].getAbsolutePath());
									String roilbl=r.label;	//roi file name									
									
									//if we're getting roi data, scroll through the rois and each fixation to get the data
									if(roiReport.isSelected())
									{
										for(int roiCount=0;roiCount<r.rois.size();roiCount++)
										{
											int total=0,numberwithin=0,first=-1;									
											fileOut.writeBytes(d + "\t" + s + "\t" + roilbl + "\t" + r.ids.elementAt(roiCount));	//roi id
											for(int fix=min;fix<fp.FixSeq.elementAt(t).fixations.size();fix++)
											{
												total++;	//total fixations checked
												if(r.rois.elementAt(roiCount).contains(fp.FixSeq.elementAt(t).fixations.elementAt(fix)))
												{
													numberwithin++;	//number within roi
													if(numberwithin==1){first=fix;}	//first fix index
												}
												if(fix==max){fix=fp.FixSeq.elementAt(t).fixations.size();}
											}
											
										if(incTotalFix.isSelected()){fileOut.writeBytes("\t" + total) ;}
										if(incFixCount.isSelected()){fileOut.writeBytes("\t" + numberwithin) ;}
										if(incFFI.isSelected())
										{
											if(first==-1){fileOut.writeBytes("\t" + ".") ;}
											else{fileOut.writeBytes("\t" + (first+1)) ;}
										}
										fileOut.writeBytes("\n");
										
										}
									}
																
									//if we're getting fix data scroll through the fixations
									if(fixReport.isSelected())
									{								
										for(int fix=min;fix<fp.FixSeq.elementAt(t).fixations.size();fix++)
										{
											fixFileOut.writeBytes(d + "\t" + s + "\t" + (fix+1));
												if(incRoiID.isSelected())
												{
													int a=r.contains(fp.FixSeq.elementAt(t).fixations.elementAt(fix));//roiID
													if(a==-1){fixFileOut.writeBytes("\t" + ".");}
													else{fixFileOut.writeBytes("\t" + r.ids.elementAt(a));}
												}
												int b=r.getNearest(fp.FixSeq.elementAt(t).fixations.elementAt(fix));
												if(incNearestID.isSelected()){fixFileOut.writeBytes("\t" + r.ids.elementAt(b)) ;}
												if(incRegDist.isSelected()){fixFileOut.writeBytes("\t" + r.getDistance(fp.FixSeq.elementAt(t).fixations.elementAt(fix),b)) ;}
											fixFileOut.writeBytes("\n");
											if(fix==max){fix=fp.FixSeq.elementAt(t).fixations.size();}
										}	
									}							
								}
							}
						}
					}
						
					//If we're matching IAs within one file to trial names
					if (matchROIID.isSelected() && (roiList.getSelectedIndex()>0))
					{
						//load the ROIs
						ROI r=new ROI();
						r.loadFromFile(rois[roiList.getSelectedIndex()-1].getAbsolutePath());
						String roilbl=r.label;	//roi file name
												
						//loop through data files
						for(int f=0;f<dataList.getSelectedValues().length;f++)
						{
							//parse this file, and loop through the scanpaths
							fp=new FixParse(dataSources[dataList.getSelectedIndices()[f]-1].getAbsolutePath());
							String d=dataSources[dataList.getSelectedIndices()[f]-1].getName();//data file name
							for(int t=0;t<fp.FixSeq.size();t++)
							{
								String s=fp.FixSeq.elementAt(t).fname;	//set name 
								//look for a ROI ID with this name, but a different extension
								int i=r.findID(s.substring(0,s.length()-4));
								if(i!=-1)//if a match is found
								{								
									//if we're getting roi data, scroll through each fixation to get the data
									if(roiReport.isSelected())
									{
											int total=0,numberwithin=0,first=-1;									
											fileOut.writeBytes(d + "\t" + s + "\t" + roilbl + "\t" + r.ids.elementAt(i));	//roi id
											for(int fix=min;fix<fp.FixSeq.elementAt(t).fixations.size();fix++)
											{
												total++;	//total fixations checked
												if(r.rois.elementAt(i).contains(fp.FixSeq.elementAt(t).fixations.elementAt(fix)))
												{
													numberwithin++;	//number within roi
													if(numberwithin==1){first=fix;}	//first fix index
												}
												if(fix==max){fix=fp.FixSeq.elementAt(t).fixations.size();}
											}
											
										if(incTotalFix.isSelected()){fileOut.writeBytes("\t" + total) ;}
										if(incFixCount.isSelected()){fileOut.writeBytes("\t" + numberwithin) ;}
										if(incFFI.isSelected())
										{
											if(first==-1){fileOut.writeBytes("\t" + ".") ;}
											else{fileOut.writeBytes("\t" + (first+1)) ;}
										}
										fileOut.writeBytes("\n");																			
									}
																
									//if we're getting fix data scroll through the fixations
									if(fixReport.isSelected())
									{								
										for(int fix=min;fix<fp.FixSeq.elementAt(t).fixations.size();fix++)
										{
											fixFileOut.writeBytes(d + "\t" + s + "\t" + (fix+1));
												if(incRoiID.isSelected())
												{
													boolean a=r.rois.elementAt(i).contains(fp.FixSeq.elementAt(t).fixations.elementAt(fix));
													if(a){fixFileOut.writeBytes("\t" + r.ids.elementAt(i));}
													else{fixFileOut.writeBytes("\t" + ".");}
												}
												if(incNearestID.isSelected()){fixFileOut.writeBytes("\t" + r.ids.elementAt(i)) ;}
												if(incRegDist.isSelected()){fixFileOut.writeBytes("\t" + r.getDistance(fp.FixSeq.elementAt(t).fixations.elementAt(fix),i)) ;}
											fixFileOut.writeBytes("\n");
											if(fix==max){fix=fp.FixSeq.elementAt(t).fixations.size();}
										}	
									}							
								}
							}
						}						
					}
					
				}
				catch (IOException e) // NB remember the error handling.
				{
				  System.out.println("An i/o error has occurred ["+e+"]");
				}			
			}
     	}										    	
	mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));//Return to normal cursor 	
	}
    
    //METHOD TO POPULATE LIST WITH FILE NAMES
    public void getListItems(File[] files, DefaultListModel model)
    {
	    //loop through the files and add the name of each one to the list
	    for(int f=0;f<files.length;f++)
	    {
			model.addElement(files[f].getName());	    
	    }
    }
    
    //METHOD TO SET-UP THE LIST COMPONENTS
    public void makeList(JList list,DefaultListModel model, JScrollPane spane)
    {
	    model.clear();
        model.addElement("None");
        list.setVisibleRowCount(-1);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        spane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        spane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        spane.setPreferredSize(new Dimension(80, 80));	    

    }      

	
}



