	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* 
URLDisplay
a GUI class to display an html file e.g. a readme

*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.swing.event.*;

public class URLDisplay
{
	//define GUI objects
	static JPanel mainPanel;	//panels
	static JEditorPane myText;	//label to show all the text
    static JScrollPane  myTextScrollPane;	//button to proceed
    
    //define sourcefile
    RandomAccessFile fileIn;	//i/o file
			
	public URLDisplay(String source_file)
	//CONSTRUCTOR, LAYS OUT COMPONENTS
	{
		//instantiate panel
	    mainPanel = new JPanel(); 
	    mainPanel.setBorder(BorderFactory.createLoweredBevelBorder());      
	    
        //instantiate editor pane and try loading text
        myText=new JEditorPane ();
        myText.setEditable(false);

        String p="../resources/"+source_file;	      
        System.out.println(System.getProperty("user.dir")+"/"+p);
        File f=new File(System.getProperty("user.dir")+"/"+p);
        System.out.println(f.toURI());
        java.net.URI u=f.toURI();
       
        try
        {
			java.net.URL myURL = u.toURL();//URLDisplay.class.getResource(p);
			System.out.println("reading "+ myURL);
			if (myURL != null) 
			{
			    try 
			    {
			        myText.setPage(myURL);
			    } 
			    catch (IOException e) 
			    {
			        System.err.println("Attempted to read a bad URL: " + myURL);
			    }
			} 
			else 
			{
			    System.err.println("Couldn't find file: "+ source_file);
			}   
		}
		
	    catch (java.net.MalformedURLException e) 
	    {
	        System.err.println("Attempted to make a bad URL: " + u);
	    } 		       
        
        //instantiate the scrollpane
        myTextScrollPane = new JScrollPane(myText);
        myTextScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		myTextScrollPane.setPreferredSize(new Dimension(750, 750));
               
        //Add stuff to panels.               
        mainPanel.add(myTextScrollPane);     	       	        		
	    
    }

}
