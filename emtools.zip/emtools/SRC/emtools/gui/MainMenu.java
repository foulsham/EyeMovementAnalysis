	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* 
MainMenu
a GUI class presenting the different program options, and explaining what they do

*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.MouseEvent;
import javax.swing.event.*;

public class MainMenu implements ActionListener
{
	//define GUI objects
	static JPanel mainPanel,optionPanel,descriptionPanel;	//panels
	static JLabel description;	//label to show description
    static JRadioButton displayScanpathsButton, batchScanpathsButton,salRegionsButton,salMapButton, multiDisplay,readMeButton; //buttons to choose what to do 
    static JButton goButton;	//button to proceed
		
    static JFrame MainMenuFrame;
    	
	public MainMenu()
	//CONSTRUCTOR, LAYS OUT COMPONENTS
	{
		//instantiate panels
	    mainPanel = new JPanel();
	    	mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));	
		optionPanel = new JPanel(new GridLayout(0, 1));
	    descriptionPanel = new JPanel();         	
		descriptionPanel.setBorder(BorderFactory.createLoweredBevelBorder());
		
        //instantiate buttons
        displayScanpathsButton=new JRadioButton("View scanpaths...");
        batchScanpathsButton=new JRadioButton("Batch process scanpaths...");
        salRegionsButton=new JRadioButton("Process regions of interest...");
        salMapButton=new JRadioButton("Process feature maps...");    
        readMeButton=new JRadioButton("View README..."); 
        multiDisplay=new JRadioButton("Produce multi-plot...");
        goButton = new JButton("Go!");
        	goButton.addActionListener(this);
        	goButton.setActionCommand("go");        
        
        //Group the radio buttons and add listeners
        ButtonGroup options = new ButtonGroup();
        options.add(displayScanpathsButton);
        	displayScanpathsButton.addActionListener(this);
        	displayScanpathsButton.setActionCommand("dscan");
        	displayScanpathsButton.setSelected(true);
        options.add(batchScanpathsButton);
        	batchScanpathsButton.addActionListener(this);
        	batchScanpathsButton.setActionCommand("bscan"); 
        options.add(salRegionsButton);
        	salRegionsButton.addActionListener(this);
        	salRegionsButton.setActionCommand("sregs"); 
        options.add(salMapButton);
        	salMapButton.addActionListener(this);
        	salMapButton.setActionCommand("smaps"); 
        options.add(multiDisplay);
        	multiDisplay.addActionListener(this);
        	multiDisplay.setActionCommand("multi");        	
        options.add(readMeButton);
        	readMeButton.addActionListener(this);
        	readMeButton.setActionCommand("readme");  
        	
        //instantiate labels
        description=new JLabel ("Displays fixation locations and scanpaths for trial data stored in a text file, overlaid onto an image or a saliency map");
               
        //Add stuff to panels.               
        mainPanel.add(optionPanel);
        mainPanel.add(descriptionPanel);
        optionPanel.add(displayScanpathsButton);
        optionPanel.add(batchScanpathsButton);
        optionPanel.add(salRegionsButton);
        optionPanel.add(salMapButton);
        optionPanel.add(multiDisplay);
        optionPanel.add(readMeButton);
        descriptionPanel.add(description);  
        mainPanel.add(goButton);       	       	        		
	    
    }
    
    public void actionPerformed(ActionEvent event) 
    {
        if (event.getActionCommand().equals("dscan"))  
        {
	        description.setText("Displays fixation locations and scanpaths for trial data stored in a text file, overlaid onto an image or a saliency map");
        }
        if (event.getActionCommand().equals("bscan"))  
        {
	        description.setText("Runs scanpath comparisons on a batch of files");
        }   
        if (event.getActionCommand().equals("sregs"))  
        {
	        description.setText("Returns data on the fixations found within salient regions of interest");
        }              
        if (event.getActionCommand().equals("smaps"))  
        {
	        description.setText("Returns data based on saliency maps for a set of images");
        } 
        if (event.getActionCommand().equals("multi"))  
        {
	        description.setText("Plots fixations and/or saccades from a large number of sets");
        }         
        if (event.getActionCommand().equals("readme"))  
        {
	        description.setText("View the readme file");	        
        }  
        if (event.getActionCommand().equals("go"))  
        {
	        mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));//show egg-timer

	        if(readMeButton.isSelected())
	        {	        
		    JFrame.setDefaultLookAndFeelDecorated(true);	//make a frame
	        JFrame GUIDisplayFrame = new JFrame();
	        GUIDisplayFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        emtools.gui.URLDisplay textdisplay = new emtools.gui.URLDisplay("readme.html");
	        GUIDisplayFrame.setContentPane(textdisplay.mainPanel);
	        GUIDisplayFrame.setTitle("ReadMe");
        	GUIDisplayFrame.pack();	//display it
        	GUIDisplayFrame.setLocationRelativeTo(null);
	        GUIDisplayFrame.setVisible(true); 
	        }
        	
	        if(displayScanpathsButton.isSelected())
	        {
	        ScanpathViewerJAI scanpathviewer = new ScanpathViewerJAI();
	        scanpathviewer.setContentPane(scanpathviewer.mainPanel);
	        scanpathviewer.setTitle("Scanpath viewer");
	        scanpathviewer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        	scanpathviewer.pack();	//display it
        	//scanpathviewer.setLocationRelativeTo(null);
	        scanpathviewer.setVisible(true); 	        
        	} 
        	
	        if(batchScanpathsButton.isSelected())
	        {
	        ScanpathBatcher sb = new ScanpathBatcher();
	        sb.setContentPane(sb.mainPanel);
	        sb.setTitle("Scanpath viewer");
	        sb.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        	sb.pack();	//display it
        	//scanpathviewer.setLocationRelativeTo(null);
	        sb.setVisible(true); 	        
        	}         	  
        	
	        if(multiDisplay.isSelected())
	        {
	        MultiScanpathViewer scanpathviewer = new MultiScanpathViewer();
	        scanpathviewer.setContentPane(scanpathviewer.mainPanel);
	        scanpathviewer.setTitle("Multiple scanpath viewer");
	        scanpathviewer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        	scanpathviewer.pack();	//display it
        	//scanpathviewer.setLocationRelativeTo(null);
	        scanpathviewer.setVisible(true); 	        
        	}        	     	

	        if(salRegionsButton.isSelected())
	        {
	        RegionAnalyser ra = new RegionAnalyser();
	        ra.setContentPane(ra.mainPanel);
	        ra.setTitle("ROI analysis");
	        ra.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        	ra.pack();	//display it
        	//scanpathviewer.setLocationRelativeTo(null);
	        ra.setVisible(true); 	        
        	}
        	
	        if(salMapButton.isSelected())
	        {
	        MapAnalyser ma = new MapAnalyser();
	        ma.setContentPane(ma.mainPanel);
	        ma.setTitle("Map analysis");
	        ma.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        	ma.pack();	//display it
        	//scanpathviewer.setLocationRelativeTo(null);
	        ma.setVisible(true); 	        
        	}        	
				  
	        mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));//Return to normal cursor     
	        
        }                        
    }  
       
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create a new instance and so trigger constructor.
        MainMenu mainmenu = new MainMenu();

        //Create and set up the window.
        MainMenuFrame = new JFrame("Main menu");
        MainMenuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        MainMenuFrame.setContentPane(mainmenu.mainPanel);
        
        //Size and display the window.
       // Insets insets = RegionSelectorFrame.getInsets();
       //MainMenuFrame.setSize(750,750);
        MainMenuFrame.pack();
        //MainMenuFrame.setLocationRelativeTo(null);
        MainMenuFrame.setVisible(true);        
    }
   
     public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
