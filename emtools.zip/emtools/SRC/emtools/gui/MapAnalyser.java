	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* a GUI class which does the following:
	-allows user to choose data files and feature maps
	-stores the feature map value at each location, for a series of fixations
	-also performs various calculations on maps

*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.text.Position.*;
import java.net.URL;
import javax.swing.event.*;
import java.io.*;
import java.util.*;
import emtools.io.*;
import emtools.scanpath.*;

public class MapAnalyser extends JFrame implements ActionListener
{
	
	//GUI COMPONENTS
	static JPanel mainPanel,defPanel,sourcePanel,setsPanel,fixPanel,sizePanel,controlPanel;	//creates panels	
    static JButton getMapsBtn,getSourceDataBtn;//buttons to load external data
    static JButton outputBtn,avMapBtn,mapStatsBtn,defineBtn;	//buttons for other options
	static JRadioButton allTrials,matchOnly,allFixes,theseFixesOnly; //buttons to choose what to do     
    static JList mapList,dataList;//list the chosen files to display
    DefaultListModel mapListModel,dataListModel;
    static JScrollPane mapSP,dataSP; //scroll panes for long lists
    static JFileChooser mapFC,dataFC;//allow user to select the files they want
    File [] maps,dataSources;//the chosen files
    
    static JSpinner fromFix,toFix,areaSpin,xS,yS;	//allows user to filter fixations used
    static SpinnerNumberModel fromFixModel, toFixModel,areaModel,xMod,yMod;
    static JLabel lbl,areaLbl,dimLbl,byLbl; 
	
	//FIXATION DATA VARIABLES
	FixParse fp; //an instance of the fix parsing class which will hold all trials/sets from one data file
	RandomAccessFile fileOut; //a file to output to
	
    //CONSTRUCTOR WHICH BUILDS THE GUI
    public MapAnalyser()
    {
	    //BUILD PANELS
	    mainPanel = new JPanel();//contains everything else
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
	    	//mainPanel.setLayout(new GridLayout(0,1,5,3));
		sourcePanel = new JPanel();	//holds controls regarding which picture / data to use
			sourcePanel.setLayout(new GridLayout(2,2,5,3));
        setsPanel = new JPanel();
        fixPanel = new JPanel();
		sizePanel = new JPanel();
        defPanel = new JPanel();
        controlPanel = new JPanel();
        
        //initialise buttons
        getMapsBtn = new JButton("Add map files");
        	getMapsBtn.addActionListener(this);
        	getMapsBtn.setActionCommand("add_maps"); 
        getSourceDataBtn = new JButton("Add EM data");
        	getSourceDataBtn.addActionListener(this);
        	getSourceDataBtn.setActionCommand("add_ems"); 
        outputBtn = new JButton("Output value at fixation");
        	outputBtn.addActionListener(this);
        	outputBtn.setActionCommand("output");	  
        avMapBtn = new JButton("Calculate average map");
        	avMapBtn.addActionListener(this);
        	avMapBtn.setActionCommand("av");        
        mapStatsBtn = new JButton("Get map stats");
        	mapStatsBtn.addActionListener(this);
        	mapStatsBtn.setActionCommand("mapstats");               	        	        	
        defineBtn = new JButton("Define ROI from map");
        	defineBtn.addActionListener(this);
        	defineBtn.setActionCommand("define");
        allFixes=new JRadioButton("Load all fixations");
        theseFixesOnly=new JRadioButton("Load only fixations from");
        allTrials=new JRadioButton("Use this map for all"); 
        matchOnly=new JRadioButton("Match set to map filename");
                        	        
        areaModel =new SpinnerNumberModel(10, 1, 100,1);
        areaSpin=new JSpinner(areaModel);
        areaLbl=new JLabel(" % of area");       	     	               	      	
        toFixModel =new SpinnerNumberModel(10, 1, 100,1);
		fromFixModel =new SpinnerNumberModel(1, 1, 100,1);
        fromFix=new JSpinner(fromFixModel);
        toFix=new JSpinner(toFixModel);
        lbl=new JLabel(" to ");
        xMod =new SpinnerNumberModel(1024, 1, 5000,1);
		yMod =new SpinnerNumberModel(768, 1, 5000,1);
        yS=new JSpinner(yMod);
        xS=new JSpinner(xMod);
        dimLbl=new JLabel("Display size");
        byLbl=new JLabel(" by ");
        
        //Group the radio buttons and add listeners
        ButtonGroup trialOptions = new ButtonGroup();
        trialOptions.add(allTrials);
        	allTrials.setSelected(true);
        trialOptions.add(matchOnly);
        	matchOnly.setSelected(false);  
        ButtonGroup fixOptions = new ButtonGroup();
        fixOptions.add(allFixes);
        	allFixes.setSelected(true);
        fixOptions.add(theseFixesOnly);
        	theseFixesOnly.setSelected(false);   
        	              	
        //initialise lists
        mapListModel=new DefaultListModel();
        mapList=new JList (mapListModel);
        mapSP=new JScrollPane (mapList);
        makeList(mapList,mapListModel,mapSP);
        mapList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION); 
        dataListModel=new DefaultListModel();
        dataList=new JList (dataListModel);
        dataSP=new JScrollPane (dataList);
        makeList(dataList,dataListModel,dataSP);  
        dataList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);         
        
        //add stuff to the panels
		
        sourcePanel.add(getMapsBtn);
        sourcePanel.add(getSourceDataBtn);
		sourcePanel.add(mapSP);
        sourcePanel.add(dataSP);
		
        setsPanel.add(allTrials);
		setsPanel.add(matchOnly);
        fixPanel.add(allFixes);
        fixPanel.add(theseFixesOnly);
        fixPanel.add(fromFix);
        fixPanel.add(lbl);
        fixPanel.add(toFix);	
        sizePanel.add(dimLbl);
        sizePanel.add(xS);
        sizePanel.add(byLbl);        		     
		sizePanel.add(yS);
		defPanel.add(defineBtn);
		defPanel.add(areaSpin);
		defPanel.add(areaLbl);
		controlPanel.add(avMapBtn);
		controlPanel.add(mapStatsBtn);
		controlPanel.add(outputBtn);
			     	
        mainPanel.add(sourcePanel);   	       
		mainPanel.add(setsPanel);
		mainPanel.add(fixPanel);
		mainPanel.add(sizePanel);
		mainPanel.add(defPanel);
		mainPanel.add(controlPanel);
    }
    
    
    //METHOD REQUIRED BY THE ACTION LISTENER TRIGGERED BY BUTTON PRESS
    public void actionPerformed(ActionEvent event) 
    {
	    mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));//show egg-timer
	    
	    if (event.getActionCommand().equals("add_maps"))
	    {
	        //instantiates file chooser window which allows multiple files to be selected
	        mapFC = new JFileChooser("../my_files/maps");
			mapFC.setMultiSelectionEnabled(true);
			String exts[]={"jpg", "bmp","ppm","pgm","pnm"};
		    CustomFileFilter filter = new CustomFileFilter(exts, "Accepted image formats");
		    mapFC.setFileFilter(filter);			
			int returnVal = mapFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				//ie. not if cancelled
				{
					maps=new File[mapFC.getSelectedFiles().length];
					maps=mapFC.getSelectedFiles();
					getListItems(maps,mapListModel);	//calls a method to add the names of the selected files to the list
				}				    
     	}         
     	
	    if (event.getActionCommand().equals("add_ems"))
	    {
	        dataFC = new JFileChooser("../my_files/data");
			dataFC.setMultiSelectionEnabled(true);
		    CustomFileFilter filter = new CustomFileFilter("txt","Text files");
		    dataFC.setFileFilter(filter);				
			int returnVal = dataFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					dataSources=new File[dataFC.getSelectedFiles().length];
					dataSources=dataFC.getSelectedFiles();
					getListItems(dataSources,dataListModel);
				}				    
     	}   
		
	    if (event.getActionCommand().equals("output") )
	    //analyse the data at fixation
	    {
			//get fixation limits and ROI
			int min=fromFixModel.getNumber().intValue()-1;
			int max=toFixModel.getNumber().intValue()-1;
			
			//get tracked display size
			int dimX=xMod.getNumber().intValue();
			int dimY=yMod.getNumber().intValue();			
			
			//define a vector of maps, and if we're only using one map, load it
			Vector <RawMapPixels> ms=new Vector <RawMapPixels> ();
			
			if (allTrials.isSelected() && (mapList.getSelectedIndex()>0))
			{
			ms.add(new RawMapPixels(maps[mapList.getSelectedIndex()-1].getAbsolutePath()));			
			}
			else
			{
			ms.add(new RawMapPixels(1,1));	
			}
						
			//output the data to a text file with headings			
			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
				System.out.println("writing to file... "+saveFC.getSelectedFile().getAbsolutePath()+".txt");
				try
				{
				fileOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath()+".txt", "rw");
				fileOut.writeBytes("DATA_FILE"+"\t"+"SET_NAME" +"\t"+"MAP_FILE"+"\t"+ "FIX_INDEX" +"\t" + "SCALED_X" +"\t" + "SCALED_Y" +"\t" + "VALUE_AT_FIX"+"\n");

					//loop through data files
					for(int f=0;f<dataList.getSelectedValues().length;f++)
					{
						//parse this file, and loop through the scanpaths
						fp=new FixParse(dataSources[dataList.getSelectedIndices()[f]-1].getAbsolutePath());
						String d=dataSources[dataList.getSelectedIndices()[f]-1].getName(); //data file name
						for(int t=0;t<fp.FixSeq.size();t++)
						{
 							String s=fp.FixSeq.elementAt(t).fname;	//set name 
 							  
 							//m.printMapToFile("C:/Documents and Settings/Tom/Desktop/Progging/EMtools/gui/maps/test.txt",0);
 							
 							//if we're matching load the map if one fits and carry on
 							
 							int i=0;
 							if (matchOnly.isSelected() )
 							{
 							i=mapList.getNextMatch(s.substring(0,s.length()-4),1,javax.swing.text.Position.Bias.Forward);
							}
 							if(i!=-1)
 							{
	 							int k=0;//gives index of current map in vector
	 							if (matchOnly.isSelected() )
	 							{
		 							//if we've found a map check if its in vector and if not, add it
		 							k=-1;
		 							for(int m=0;m<ms.size();m++)
		 							{
		 								if( maps[i-1].getAbsolutePath()==ms.elementAt(m).filename )
		 								{
			 							k=m;	
		 								}
	 								}
	 								if(k==-1)
	 								{
		 								k=ms.size();
		 								ms.add(new RawMapPixels(maps[i-1].getAbsolutePath()));	
	 								}	 									 									 							
 								}	
 								
 								//zoom coordinates based on map size
 								int zX=dimX/ms.elementAt(k).map.length;
 								int zY=dimY/ms.elementAt(k).map[0].length;
 								fp.FixSeq.elementAt(t).zoomCoords(zX);
 								
	 							//loop through fixations	
								for(int fix=min;fix<fp.FixSeq.elementAt(t).fixations.size();fix++)
								{
									fileOut.writeBytes(d + "\t" + s + "\t" + ms.elementAt(k).filename + "\t" + (fix+1));
									fileOut.writeBytes("\t" + fp.FixSeq.elementAt(t).fixations.elementAt(fix).x);
									fileOut.writeBytes("\t" + fp.FixSeq.elementAt(t).fixations.elementAt(fix).y);
									int v=ms.elementAt(k).getValueSafely(fp.FixSeq.elementAt(t).fixations.elementAt(fix).x,fp.FixSeq.elementAt(t).fixations.elementAt(fix).y);
									if(v!=-1){fileOut.writeBytes("\t" + v);}
									else{fileOut.writeBytes("\t" + ".");}
									fileOut.writeBytes("\n");
									if(fix==max){fix=fp.FixSeq.elementAt(t).fixations.size();}
								}	 							
 							}
 									  
						}
					}			
					
				}
				catch (IOException e) // NB remember the error handling.
				{
				  System.out.println("An i/o error has occurred ["+e+"]");
				}			
			}
     	}
     	
     	if (event.getActionCommand().equals("av") && (mapList.getSelectedIndex()>0))
     	//average a bunch of maps							
     	{
	     	RawMapPixels av; //the base map, will start with all pixels at 0
			RawMapPixels m=new RawMapPixels(maps[mapList.getSelectedIndex()-1].getAbsolutePath()); //the first map selected
			av=new RawMapPixels(m.map.length,m.map[0].length);	//size it to the correct dimensions
			
			//now loop through the selected maps adding each pixel
			for(int f=0;f<mapList.getSelectedValues().length;f++)
			{
				m=new RawMapPixels(maps[mapList.getSelectedIndices()[f]-1].getAbsolutePath());
				for(int x=0;x<av.map.length;x++)
				{
					for(int y=0;y<av.map[0].length;y++)
					{			
						av.map[x][y]=av.map[x][y] + m.map[x][y];
					}
				}				
			}
			//divide each pixel by the number of maps, then scale to standard range
			for(int x=0;x<av.map.length;x++)
			{
				for(int y=0;y<av.map[0].length;y++)
				{			
					av.map[x][y]=av.map[x][y]/mapList.getSelectedValues().length;
				}
			}			
			av.scaleToRange();
	     	//output it
			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{	     	
	     	av.printMapToFile(saveFC.getSelectedFile().getAbsolutePath(),1);
     		}			
			
     	}
     	
     	if (event.getActionCommand().equals("mapstats") && (mapList.getSelectedIndex()>0))
     	//get stats on a bunch of maps							
     	{
			RawMapPixels m;
			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{	

				System.out.println("writing to file... "+saveFC.getSelectedFile().getAbsolutePath()+".txt");
				try
				{
					fileOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath()+".txt", "rw");
					fileOut.writeBytes("MAP_FILE"+"\t"+"MIN_PIX_VALUE" +"\t"+"MAX_PIX_VALUE"+"\t"+ "MEAN_PIX_VALUE" +"\n");
														
					//now loop through the selected maps and get the stats
					for(int f=0;f<mapList.getSelectedValues().length;f++)
					{
						m=new RawMapPixels(maps[mapList.getSelectedIndices()[f]-1].getAbsolutePath());
						m.setMinMaxMean();
						fileOut.writeBytes(m.filename+"\t"+ m.min_pixel +"\t"+m.max_pixel+"\t"+ m.map_mean +"\n");										
					}
				}
				catch (IOException e) // NB remember the error handling.
				{
				  System.out.println("An i/o error has occurred ["+e+"]");
				}				

     		}			
			
     	}     	
     	
     	if (event.getActionCommand().equals("define") && (mapList.getSelectedIndex()>0))
     	//define an ROI file from the selected map							
     	{
	     	RawMapPixels m=new RawMapPixels(maps[mapList.getSelectedIndex()-1].getAbsolutePath());
	     	
	     	double a=areaModel.getNumber().doubleValue();
	     	int t=m.getThresholdFromArea(a);
	     	ROI r;
	     	r=m.describeAreaAbove(t);
	     	
	     	//output it
			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{	     	
	     	r.printToFile(saveFC.getSelectedFile().getAbsolutePath()+".txt");
     		}
     	}     				    	
	
     	mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));//Return to normal cursor 	
	}
    
    //METHOD TO POPULATE LIST WITH FILE NAMES
    public void getListItems(File[] files, DefaultListModel model)
    {
	    //loop through the files and add the name of each one to the list
	    for(int f=0;f<files.length;f++)
	    {
			model.addElement(files[f].getName());	    
	    }
    }
    
    //METHOD TO SET-UP THE LIST COMPONENTS
    public void makeList(JList list,DefaultListModel model, JScrollPane spane)
    {
	    model.clear();
        model.addElement("None");
        list.setVisibleRowCount(-1);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        spane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        spane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        spane.setPreferredSize(new Dimension(80, 80));	    

    }      

	
}



