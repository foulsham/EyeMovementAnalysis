	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* a GUI class which does the following:
	-allows user to choose data files
	-compares the scanpaths, based on various user options
	-outputs to a file

*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.text.Position.*;
import java.net.URL;
import javax.swing.event.*;
import java.io.*;
import java.util.*;
import emtools.io.*;
import emtools.scanpath.*;

public class ScanpathBatcher extends JFrame implements ActionListener
{
	
	//GUI COMPONENTS
	static JPanel mainPanel,controlPanel,sourcePanel,setsPanel,fixPanel,dimPanel;	//creates panels	
    static JButton getA,getB;//buttons to load external data
    static JButton outputBtn,randBtn;	//buttons for other options
    static JList AList,BList;//list the chosen files to display
    DefaultListModel AListModel,BListModel;
    static JScrollPane ASP,BSP; //scroll panes for long lists
    static JFileChooser AFC,BFC;//allow user to select the files they want
    File [] As,Bs;//the chosen files
    static JRadioButton compSequentially,matchSetName,allFixes,theseFixesOnly; //buttons to choose what to do 
    
    //spin buttons to control which fixations to use
    static JSpinner fromFix,toFix;
    static SpinnerNumberModel fromFixModel, toFixModel;
    static JLabel lbl; 
    
    //spin buttons to control the size of the grid
	static SpinnerNumberModel modelX;
	static JSpinner gridXspin;
	static SpinnerNumberModel modelY;
	static JSpinner gridYspin; 
	
	//spin buttons to control the size of the display
	static SpinnerNumberModel modelDimX;
	static JSpinner dimXspin;
	static SpinnerNumberModel modelDimY;
	static JSpinner dimYspin;	    
	static JLabel griddims,dims,randlbl;
	
	//spin button to control the number of iterations for a random simulation
	static SpinnerNumberModel randModel;
	static JSpinner randSpin;		
	
	//options for which metrics to use, and for other options
	static JCheckBox useStringEdit,useMannan,useUA,useWeighted,compressSingle,makeEqual,useStringsOnly;
	
	//FIXATION DATA VARIABLES
	FixParse fpA,fpB; //an instance of the fix parsing class which will hold all trials/sets from each data file
	RandomAccessFile fileOut; //files to output to
	
    //CONSTRUCTOR WHICH BUILDS THE GUI
    public ScanpathBatcher()
    {
	    //BUILD PANELS
	    mainPanel = new JPanel();//contains everything else
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
	    	//mainPanel.setLayout(new GridLayout(0,1,5,3));
		sourcePanel = new JPanel();	//holds controls regarding which data to use
			sourcePanel.setLayout(new GridLayout(2,2,5,3));
        controlPanel = new JPanel();	//holds user controls
        controlPanel.setLayout(new GridLayout(2,2,5,5));
        setsPanel = new JPanel();
        fixPanel = new JPanel();
        dimPanel = new JPanel();
        	dimPanel.setLayout(new GridLayout(4,3,5,3));
        
        //initialise buttons
        getA = new JButton("Compare these files...");
        	getA.addActionListener(this);
        	getA.setActionCommand("get A"); 
        getB = new JButton("...To these files");
        	getB.addActionListener(this);
        	getB.setActionCommand("get B"); 
        outputBtn = new JButton("Output");
        	outputBtn.addActionListener(this);
        	outputBtn.setActionCommand("output");	
        randBtn = new JButton("Output simulations");
        	randBtn.addActionListener(this);
        	randBtn.setActionCommand("rand");        	          	        	
        compSequentially=new JRadioButton("Compare sequentially"); 
        matchSetName=new JRadioButton("Match set names");
        allFixes=new JRadioButton("Use all fixations");
        theseFixesOnly=new JRadioButton("Use only fixations from");
        
        toFixModel =new SpinnerNumberModel(10, 1, 100,1);
		fromFixModel =new SpinnerNumberModel(1, 1, 100,1);
        fromFix=new JSpinner(fromFixModel);
        toFix=new JSpinner(toFixModel);
        lbl=new JLabel(" to ");
          
	    //spin buttons to control the size of the grid
		modelX =new SpinnerNumberModel(5, 1, 20,1);
		gridXspin = new JSpinner(modelX);
		modelY =new SpinnerNumberModel(5, 1, 20,1);
		gridYspin = new JSpinner(modelY); 
		
		//spin buttons to control the size of the display
		modelDimX =new SpinnerNumberModel(1024, 1, 2400,1);
		dimXspin = new JSpinner(modelDimX);
		modelDimY =new SpinnerNumberModel(768, 1, 2400,1);
		dimYspin = new JSpinner(modelDimY);	
        griddims=new JLabel ("Grid dimensions");
        dims=new JLabel ("Display dimensions");
        
		randModel =new SpinnerNumberModel(1000, 100, 100000,100);
		randSpin = new JSpinner(randModel);	
        randlbl=new JLabel ("Simulate N scanpath pairs");        
        	        
        //Group the radio buttons
        ButtonGroup matchOptions = new ButtonGroup();
        matchOptions.add(compSequentially);
        	compSequentially.setSelected(true);
        matchOptions.add(matchSetName);
        	matchSetName.setSelected(false);            	
        ButtonGroup fixOptions = new ButtonGroup();
        fixOptions.add(allFixes);
        	allFixes.setSelected(true);
        fixOptions.add(theseFixesOnly);
        	theseFixesOnly.setSelected(false);         	     	               	      	
        	
        //initialise lists
        AListModel=new DefaultListModel();
        AList=new JList (AListModel);
        ASP=new JScrollPane (AList);
        makeList(AList,AListModel,ASP);
        AList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        BListModel=new DefaultListModel();
        BList=new JList (BListModel);
        BSP=new JScrollPane (BList);
        makeList(BList,BListModel,BSP);  
        BList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);         
		
		//initialise the checkboxes
		useStringEdit=new JCheckBox("Use string edit distance",true);
		useMannan=new JCheckBox("Use Mannan distance",true);
		useUA=new JCheckBox("Use unique-assignment distance",true);
		useWeighted=new JCheckBox("Use weighted string edit distance",true);
		compressSingle=new JCheckBox("Compress local fixations",false);
		makeEqual=new JCheckBox("Coerce to equal length",false);
		useStringsOnly=new JCheckBox("Compare strings from file only",false);
        
        //add stuff to the panels	
        sourcePanel.add(getA);
        sourcePanel.add(getB);
		sourcePanel.add(ASP);
        sourcePanel.add(BSP);
		mainPanel.add(sourcePanel);

		setsPanel.add(compSequentially);
        setsPanel.add(matchSetName);							  		          
        fixPanel.add(allFixes);
        fixPanel.add(theseFixesOnly);
        fixPanel.add(fromFix);
        fixPanel.add(lbl);
        fixPanel.add(toFix);  
		mainPanel.add(setsPanel);
		mainPanel.add(fixPanel);
				
		controlPanel.add(useStringEdit);	
		controlPanel.add(useMannan);
		controlPanel.add(useUA);
		controlPanel.add(useWeighted);	
		
		dimPanel.add(griddims);	
		dimPanel.add(gridXspin);
		dimPanel.add(gridYspin);		
		dimPanel.add(dims);			
		dimPanel.add(dimXspin);
		dimPanel.add(dimYspin);
		dimPanel.add(compressSingle);		
		dimPanel.add(makeEqual);
		dimPanel.add(useStringsOnly);
		dimPanel.add(randlbl);		
		dimPanel.add(randSpin);
		dimPanel.add(randBtn);		
							
      	//controlPanel.add(compressSingle);
		     	
        mainPanel.add(controlPanel);
        mainPanel.add(dimPanel);
        //mainPanel.add(compressSingle);
        mainPanel.add(outputBtn);   	       
    }
    
    
    //METHOD REQUIRED BY THE ACTION LISTENER TRIGGERED BY BUTTON PRESS
    public void actionPerformed(ActionEvent event) 
    {
	mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));//show egg-timer
		
		//if we're not including all fixations, get fixation limits
		int min,max;
		if(allFixes.isSelected())
		{
		min=0;
		max=10000;
		}
		else
		{
		min=fromFixModel.getNumber().intValue()-1;
		max=toFixModel.getNumber().intValue()-1;
		}
		
		//get grid and image size which are needed for metrics
		int gridx,gridy,imagex,imagey;
		gridx=modelX.getNumber().intValue();
		gridy=modelY.getNumber().intValue();
		imagex=modelDimX.getNumber().intValue();
		imagey=modelDimY.getNumber().intValue();

	    if (event.getActionCommand().equals("get A"))
	    {
	        //instantiates file chooser window which allows multiple files to be selected
	        AFC = new JFileChooser("../my_files/data");
			AFC.setMultiSelectionEnabled(true);
		    CustomFileFilter filter = new CustomFileFilter("txt","Text files");
		    AFC.setFileFilter(filter);			
			int returnVal = AFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				//ie. not if cancelled
				{
					As=new File[AFC.getSelectedFiles().length];
					As=AFC.getSelectedFiles();
					getListItems(As,AListModel);	//calls a method to add the names of the selected files to the list
				}				    
     	}         
     	
	    if (event.getActionCommand().equals("get B"))
	    {
	        BFC = new JFileChooser("../my_files/data");
			BFC.setMultiSelectionEnabled(true);
		    CustomFileFilter filter = new CustomFileFilter("txt","Text files");
		    BFC.setFileFilter(filter);				
			int returnVal = BFC.showOpenDialog(mainPanel);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					Bs=new File[BFC.getSelectedFiles().length];
					Bs=BFC.getSelectedFiles();
					getListItems(Bs,BListModel);
				}				    
     	}   
		
	    if ( event.getActionCommand().equals("output") && !useStringsOnly.isSelected() )
	    {			
			//output the data to a text file with headings
			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
				System.out.println("writing to file... "+saveFC.getSelectedFile().getAbsolutePath()+".txt");
				try
				{
					//create output file and necessary headings			
					fileOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath()+".txt", "rw");					
					fileOut.writeBytes("FILE_A"+"\t"+"SET_A" + "\t"+ "FILE_B"+"\t"+"SET_B");
						if(useStringEdit.isSelected())
						{
							fileOut.writeBytes("\t" + "STRING_A" + "\t" + "STRING_B") ;
							fileOut.writeBytes("\t" + "EDITS" + "\t" + "STRING_EDIT_SIMILARITY") ;
						}
						if(useMannan.isSelected()){fileOut.writeBytes("\t" + "MEAN_NORMALISED_DISTANCE" + "\t" + "MANNAN_SIMILARITY") ;}
						if(useUA.isSelected()){fileOut.writeBytes("\t" + "MIN_MEAN_NORMALISED_DISTANCE" + "\t" + "UA_SIMILARITY") ;}
						if(useWeighted.isSelected()){fileOut.writeBytes("\t" + "NORMALISED_WEIGHTED_DISTANCE" + "\t" + "WEIGHTED_SIMILARITY") ;}						
					fileOut.writeBytes("\n");
				
					//now loop through the data files
					for(int f=0;f<AList.getSelectedValues().length;f++)
					{
						//parse the file, and the corresponding one in B if its there
						fpA=new FixParse(As[AList.getSelectedIndices()[f]-1].getAbsolutePath());
						String nameA=As[AList.getSelectedIndices()[f]-1].getName();//data file name
						
						if(f < BList.getSelectedValues().length)
						{
							fpB=new FixParse(Bs[BList.getSelectedIndices()[f]-1].getAbsolutePath());
							String nameB=Bs[BList.getSelectedIndices()[f]-1].getName();//data file name
							
							//loop through the sets (in A)
							for(int t=0;t<fpA.FixSeq.size();t++)
							{
								//add to a new instance of the comparison class
								//match set name in B if necessary
								ScanpathComparison sc=null;
								String setB="",setA=fpA.FixSeq.elementAt(t).fname; //set name
								
								if(compSequentially.isSelected())
								{
									sc=new ScanpathComparison(fpA.FixSeq.elementAt(t),fpB.FixSeq.elementAt(t));
									setB=fpB.FixSeq.elementAt(t).fname;
								}
								else
								{
									int bRef=-1;
									for(int bLoop=0;bLoop<fpB.FixSeq.size();bLoop++)
									{
										//searches for a matching set
										//System.out.print("Comparing "+setA+" with "+fpB.FixSeq.elementAt(bLoop).fname);
										if(fpB.FixSeq.elementAt(bLoop).fname.equals(setA))
										{
											//System.out.println("Match! comparing "+t+" with "+bLoop);
											bRef=bLoop;
											bLoop=fpB.FixSeq.size();	
										}
									}
									if(bRef!=-1)
									//if one has been found
									{
										sc=new ScanpathComparison(fpA.FixSeq.elementAt(t),fpB.FixSeq.elementAt(bRef));	
										setB=fpB.FixSeq.elementAt(bRef).fname;
									}
								}
								
								//carry on only if SC has been initialised properly
								if(sc!=null)
								{
								//compare and print the required bits
								fileOut.writeBytes(nameA+"\t"+setA + "\t"+ nameB+"\t"+setB);
									if(useStringEdit.isSelected())
									{
										//get strings
										sc.getStrings(imagex,imagey,gridx,gridy);
										//trim/condense/equalise as required
										//NB order could be changed
										if(compressSingle.isSelected())
										{
										sc.condenseStrings();
										}
										sc.trimStrings(min,max,makeEqual.isSelected());
										
										sc.stringEditDistance();
										fileOut.writeBytes("\t" + sc.a + "\t" + sc.b) ;
										fileOut.writeBytes("\t" + sc.sd + "\t" + sc.sdSim) ;
									}
									//trim the scanpaths if necessary
									sc.trimScanpaths(min,max,makeEqual.isSelected());
									System.out.println("Size of A,B...."+sc.spA.fixations.size()+", "+sc.spB.fixations.size());
									if(useMannan.isSelected())
									{
										sc.mannanDistance(imagex, imagey);
										fileOut.writeBytes("\t" + sc.md + "\t");
										//get the drand value from a text file resource (only goes up to 50 x 50)
										if( (sc.spA.fixations.size()>50) || (sc.spB.fixations.size()>50) )
										{
										sc.rmd=sc.retrieveCell(50,50,"/../resources/drand.txt");
										fileOut.writeBytes("!") ;//print an error character
										}
										else
										{
										sc.rmd=sc.retrieveCell(sc.spA.fixations.size(),sc.spB.fixations.size(),"/../resources/drand.txt");	
										}		

										sc.mSim=(1-(sc.md/sc.rmd))*100;											
										fileOut.writeBytes(""+sc.mSim) ;
									}
									if(useUA.isSelected())
									{
										//check scanpaths are same size
										if(sc.spA.fixations.size() != sc.spB.fixations.size())
										{
											fileOut.writeBytes("\t" + "NOT EQUAL SIZE" + "\t" + "NOT EQUAL SIZE") ;
										}
										else
										{
											sc.uaDistance(imagex, imagey);
											fileOut.writeBytes("\t" + sc.uad + "\t");				
											//get the drand value from a text file resource (only goes up to 50 x 50)
											if( (sc.spA.fixations.size()>50) || (sc.spB.fixations.size()>50) )
											{
											sc.ruad=sc.retrieveCell(50,50,"/../resources/uadrand.txt");
											fileOut.writeBytes("!") ;//print an error character
											}
											else
											{
											sc.ruad=sc.retrieveCell(sc.spA.fixations.size(),sc.spB.fixations.size(),"/../resources/uadrand.txt");	
											}		
											sc.uaSim =(1-(sc.uad/sc.ruad))*100;																			
											fileOut.writeBytes(""+sc.uaSim) ;
										}									
									}
									if(useWeighted.isSelected())
									{
										//get strings
										//NB can't condense here as fixations would need to be combined
										sc.getStrings(imagex,imagey,gridx,gridy);					
										System.out.println("using strings..."+sc.a+", "+sc.b);					
										sc.weightedEditDistance(imagex, imagey);
										fileOut.writeBytes("\t" + sc.wdNorm + "\t" + sc.wdSim) ;
									}						
								fileOut.writeBytes("\n");											
								}
								
							}							
							
						}						
					}		
					
				}
				catch (IOException e) // NB remember the error handling.
				{
				  System.out.println("An i/o error has occurred ["+e+"]");
				}			
			}
     	}	
     	
	    if ( event.getActionCommand().equals("output") && useStringsOnly.isSelected() )
	    //this allows user to make their own strings and still do a batch comparison
	    {

			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
				System.out.println("writing to file... "+saveFC.getSelectedFile().getAbsolutePath()+".txt");
				try
				{
					//create output file and necessary headings			
					fileOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath()+".txt", "rw");					
					fileOut.writeBytes("FILE_A"+"\t"+ "FILE_B"+"\t" + "STRING_A" + "\t" + "STRING_B"+"\t" + "EDITS" + "\t" + "STRING_EDIT_SIMILARITY"+"\n");
					
					for(int f=0;f<AList.getSelectedValues().length;f++)
					{					
						if(f < BList.getSelectedValues().length)
						{					
							//read the two files into vectors of strings
							 Vector <String> aStrings=new Vector <String> ();
							 Vector <String> bStrings=new Vector <String> ();
							 RandomAccessFile fileIn=new RandomAccessFile(As[AList.getSelectedIndices()[f]-1].getAbsolutePath(),"rw");
							 	String s;
							 	while( (s=fileIn.readLine()) != null)
							 	{
								 	aStrings.add(s.trim());	
							 	}
							 fileIn=new RandomAccessFile(Bs[BList.getSelectedIndices()[f]-1].getAbsolutePath(),"rw");
							 	while( (s=fileIn.readLine()) != null)
							 	{
								 	bStrings.add(s.trim());	
							 	}	
							 //compare each string sequentially
							 ScanpathComparison sc=new ScanpathComparison(new FixationSequence(),new FixationSequence());
							 for(int t=0;t<aStrings.size();t++)
							 {
								String nameA=As[AList.getSelectedIndices()[f]-1].getName();//data file name
								String nameB=Bs[BList.getSelectedIndices()[f]-1].getName();//data file name
								fileOut.writeBytes(nameA+"\t"+ nameB);
								sc.a=aStrings.elementAt(t);
								sc.b=bStrings.elementAt(t);

								//trim/condense/equalise as required
								//NB order could be changed
								if(compressSingle.isSelected())
								{
								sc.condenseStrings();
								}
								sc.trimStrings(min,max,makeEqual.isSelected());								
								sc.stringEditDistance();
								fileOut.writeBytes("\t" + sc.a + "\t" + sc.b) ;
								fileOut.writeBytes("\t" + sc.sd + "\t" + sc.sdSim+ "\n") ;								 
							 }						 
				 	
						}
					}
				}
				
				catch (IOException e) // NB remember the error handling.
				{
				  System.out.println("An i/o error has occurred ["+e+"]");
				}
			}								    
	    }     	
     	
	    if (event.getActionCommand().equals("rand") )
	    //produce random simulations given the set options
	    {
		   int iterations = randModel.getNumber().intValue(); //the number of iterations (scanpath pairs)
		   
			//output the data to text files with headings
			JFileChooser saveFC = new JFileChooser("../my_files/output");
			int rv=saveFC.showSaveDialog(mainPanel);
			if (rv == JFileChooser.APPROVE_OPTION) 
			{
				System.out.println("writing to file... "+saveFC.getSelectedFile().getAbsolutePath()+".txt");
				try
				{
					//create output files and necessary headings			
					fileOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath()+".txt", "rw");					
					fileOut.writeBytes("ITERATION");
						if(useStringEdit.isSelected())
						{
							fileOut.writeBytes("\t" + "STRING_A" + "\t" + "STRING_B") ;
							fileOut.writeBytes("\t" + "EDITS" + "\t" + "STRING_EDIT_SIMILARITY") ;
						}
						if(useMannan.isSelected()){fileOut.writeBytes("\t" + "MEAN_NORMALISED_DISTANCE" + "\t" + "MANNAN_SIMILARITY") ;}
						if(useUA.isSelected()){fileOut.writeBytes("\t" + "MIN_MEAN_NORMALISED_DISTANCE" + "\t" + "UA_SIMILARITY") ;}
						if(useWeighted.isSelected()){fileOut.writeBytes("\t" + "NORMALISED_WEIGHTED_DISTANCE" + "\t" + "WEIGHTED_SIMILARITY") ;}						
					fileOut.writeBytes("\n");
					
					//create files to store the random coordinates
					RandomAccessFile aOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath()+"_A.txt", "rw");
					RandomAccessFile bOut=new RandomAccessFile(saveFC.getSelectedFile().getAbsolutePath()+"_B.txt", "rw");	
					
					FixationSequence fsA,fsB;
					//for each iteration...
					for(int i=0; i<iterations; i++)
					{
						//create two random scanpaths,using length options
						fsA=new FixationSequence();
						fsB=new FixationSequence();
						
						if(allFixes.isSelected())
						{
						fsA.fillRandom(0,imagex,imagey);
						fsB.fillRandom(0,imagex,imagey);	
						}
						else
						{
						fsA.fillRandom((max-min)+1,imagex,imagey);
						fsB.fillRandom((max-min)+1,imagex,imagey);								
						}
						
						//print them to the files
						fsA.printToFile(aOut);
						fsA.printToFile(bOut);
						
						//compare as necessary
						ScanpathComparison sc=new ScanpathComparison(fsA,fsB);
						fileOut.writeBytes(""+(i+1));
							if(useStringEdit.isSelected())
							{
								//get strings
								sc.getStrings(imagex,imagey,gridx,gridy);
								//condense/equalise as required
								//NB order could be changed
								if(compressSingle.isSelected())
								{
								sc.condenseStrings();
								}
								sc.trimStrings(0,1000,makeEqual.isSelected());								
								sc.stringEditDistance();
								fileOut.writeBytes("\t" + sc.a + "\t" + sc.b) ;
								fileOut.writeBytes("\t" + sc.sd + "\t" + sc.sdSim) ;
							}
							//equalise the scanpaths if necessary
							sc.trimScanpaths(0,1000,makeEqual.isSelected());
							System.out.println("Size of A,B...."+sc.spA.fixations.size()+", "+sc.spB.fixations.size());
							if(useMannan.isSelected())
							{
								sc.mannanDistance(imagex, imagey);
								fileOut.writeBytes("\t" + sc.md + "\t");
								//get the drand value from a text file resource (only goes up to 50 x 50)
								if( (sc.spA.fixations.size()>50) || (sc.spB.fixations.size()>50) )
								{
								sc.rmd=sc.retrieveCell(50,50,"drand.txt");
								fileOut.writeBytes("!") ;//print an error character
								}
								else
								{
								sc.rmd=sc.retrieveCell(sc.spA.fixations.size(),sc.spB.fixations.size(),"drand.txt");	
								}		

								sc.mSim=(1-(sc.md/sc.rmd))*100;											
								fileOut.writeBytes(""+sc.mSim) ;
							}
							if(useUA.isSelected())
							{
								//check scanpaths are same size
								if(sc.spA.fixations.size() != sc.spB.fixations.size())
								{
									fileOut.writeBytes("\t" + "NOT EQUAL SIZE" + "\t" + "NOT EQUAL SIZE") ;
								}
								else
								{
									sc.uaDistance(imagex, imagey);
									fileOut.writeBytes("\t" + sc.uad + "\t");				
									//get the drand value from a text file resource (only goes up to 50 x 50)
									if( (sc.spA.fixations.size()>50) || (sc.spB.fixations.size()>50) )
									{
									sc.ruad=sc.retrieveCell(50,50,"uadrand.txt");
									fileOut.writeBytes("!") ;//print an error character
									}
									else
									{
									sc.ruad=sc.retrieveCell(sc.spA.fixations.size(),sc.spB.fixations.size(),"uadrand.txt");	
									}		
									sc.uaSim =(1-(sc.uad/sc.ruad))*100;																			
									fileOut.writeBytes(""+sc.uaSim) ;
								}									
							}
							if(useWeighted.isSelected())
							{
								//get strings
								//NB can't condense here as fixations would need to be combined
								sc.getStrings(imagex,imagey,gridx,gridy);					
								System.out.println("using strings..."+sc.a+", "+sc.b);					
								sc.weightedEditDistance(imagex, imagey);
								fileOut.writeBytes("\t" + sc.wdNorm + "\t" + sc.wdSim) ;
							}						
						fileOut.writeBytes("\n");												
					}
				}
				
				catch (IOException e) // NB remember the error handling.
				{
				  System.out.println("An i/o error has occurred ["+e+"]");
				}
			}	
			   
	    }
	    
	         										    	
	mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));//Return to normal cursor 	
	}
    
    //METHOD TO POPULATE LIST WITH FILE NAMES
    public void getListItems(File[] files, DefaultListModel model)
    {
	    //loop through the files and add the name of each one to the list
	    for(int f=0;f<files.length;f++)
	    {
			model.addElement(files[f].getName());	    
	    }
    }
    
    //METHOD TO SET-UP THE LIST COMPONENTS
    public void makeList(JList list,DefaultListModel model, JScrollPane spane)
    {
	    model.clear();
        model.addElement("None");
        list.setVisibleRowCount(-1);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        spane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        spane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        spane.setPreferredSize(new Dimension(80, 80));	    

    }      

	
}



