	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* 
	-a GUI for changing the display options for a scanpath viewer
*/
package emtools.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.swing.event.*;

public class DisplayOptions implements ActionListener, ItemListener, ChangeListener
{
	//define GUI objects
	static JPanel mainPanel,glabelPanel,controlPanel;	//panels
	static GraphicPanel gpanel; //customized panel which shows the marker types
    static JButton  saveAndQuit,fix1change,fix2change,sac1change,sac2change,gridchange,numchange;	//button to proceed
    static JLabel griddims,fixdims,strokedims,dims,zoom;
    static JLabel[] glabels= new JLabel[6];//to label the graphics 
    static JLabel[] blanklabels= new JLabel[6];//to fill space
    
    //spin buttons to control the size of the grid
	static SpinnerModel modelX =new SpinnerNumberModel(5, 1, 20,1);
	static JSpinner gridXspin = new JSpinner(modelX);
	static SpinnerModel modelY =new SpinnerNumberModel(5, 1, 20,1);
	static JSpinner gridYspin = new JSpinner(modelY); 
	
	//spin buttons to control the size of the display
	static SpinnerModel modelDimX =new SpinnerNumberModel(1024, 1, 2400,1);
	static JSpinner dimXspin = new JSpinner(modelDimX);
	static SpinnerModel modelDimY =new SpinnerNumberModel(768, 1, 2400,1);
	static JSpinner dimYspin = new JSpinner(modelDimY);	
	static SpinnerModel modelZoom =new SpinnerNumberModel(2, 1, 10,1);
	static JSpinner zoomSpin = new JSpinner(modelZoom);
	
	//spin buttons to control the diameter of the fixation marker and the width of the objects
	static SpinnerModel modelFixDim =new SpinnerNumberModel(9, 1, 40,1);
	static JSpinner fixSpin = new JSpinner(modelFixDim);
	
	static SpinnerModel strokeDim =new SpinnerNumberModel(1, 1, 40,1);
	static JSpinner strokeSpin = new JSpinner(strokeDim);	
	
	//tick boxes to control what is shown
	static JCheckBox showFix;		
	static JCheckBox showSacs;
	static JCheckBox showGrid;
	static JCheckBox showNums;
	ScanpathViewerJAI container;
	MultiScanpathViewer containerB;
	
	//the properties which have been changed
	DisplayProps props=new DisplayProps(1);

	public DisplayOptions(DisplayProps oldprops,ScanpathViewerJAI container)
	//CONSTRUCTOR argument gives current properties
	{                       
     doConstruction(oldprops);
     this.container=container;
	}
	
	public DisplayOptions(DisplayProps oldprops,MultiScanpathViewer container)
	//alternative CONSTRUCTOR argument gives current properties
	{                       
     doConstruction(oldprops);
     this.containerB=container;
	}	
	
	public void doConstruction(DisplayProps oldprops)
	//method to do the constructor work
	{
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        glabelPanel = new JPanel();
		glabelPanel.setLayout(new GridLayout(0,6,5,3));
        controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(0,6,5,3));		
		props=oldprops;
		
        gpanel=new GraphicPanel(props);
        
        //instantiate buttons and add listeners
        saveAndQuit = new JButton("Done");
        	saveAndQuit.addActionListener(this);
        	saveAndQuit.setActionCommand("saveAndQuit");         
        fix1change = new JButton("Change colour..."); 
        	fix1change.addActionListener(this);
        	fix1change.setActionCommand("fix1change");         
        fix2change = new JButton("Change colour...");
        	fix2change.addActionListener(this);
        	fix2change.setActionCommand("fix2change");         
        sac1change = new JButton("Change colour...");
        	sac1change.addActionListener(this);
        	sac1change.setActionCommand("sac1change");         
        sac2change = new JButton("Change colour...");
        	sac2change.addActionListener(this);
        	sac2change.setActionCommand("sac2change");         
        gridchange = new JButton("Change colour...");
        	gridchange.addActionListener(this);
        	gridchange.setActionCommand("gridchange");         
        numchange = new JButton("Change colour...");     
        	numchange.addActionListener(this);
        	numchange.setActionCommand("numchange");   
		showFix=new JCheckBox("Show fixations");		
		showSacs=new JCheckBox("Show saccades");
		showGrid=new JCheckBox("Show grid");
		showNums=new JCheckBox("Show index");    	    	      
        	
        //add listeners to the spin buttons and check boxes
        gridXspin.addChangeListener(this); 
        gridYspin.addChangeListener(this);
        dimXspin.addChangeListener(this);
        dimYspin.addChangeListener(this);
        zoomSpin.addChangeListener(this);
        fixSpin.addChangeListener(this);
        strokeSpin.addChangeListener(this);
        showFix.addItemListener(this);
        showSacs.addItemListener(this);
        showGrid.addItemListener(this);
        showNums.addItemListener(this); 
        
        //instantiate labels
        griddims=new JLabel ("Grid dimensions");
        dims=new JLabel ("Display dimensions");
        fixdims=new JLabel ("Fixation diameter"); 
        strokedims=new JLabel ("Line thickness");  
        zoom=new JLabel ("Zoom factor  1:");
        
        for(int i=0;i<6;i++)
        {
	     String lbl="";
	     	switch(i)
	     	{
	     	case 0: lbl="Fixation (1)"; break;
	     	case 1: lbl="Fixation (2)"; break;
	     	case 2: lbl="Saccade (1)"; break;
	     	case 3: lbl="Saccade (2)"; break;
	     	case 4: lbl="Grid lines"; break;
	     	case 5: lbl="Fixation index"; break;
    	 	}   
    	 glabels[i]=new JLabel(lbl);
    	 blanklabels[i]=new JLabel();
    	 glabels[i].setHorizontalAlignment(SwingConstants.CENTER);
    	 glabelPanel.add(glabels[i]);
        }     
        loadProps(props); 
        mainPanel.add(glabelPanel);
        mainPanel.add(gpanel);    
        controlPanel.add(fix1change);
        controlPanel.add(fix2change);
        controlPanel.add(sac1change);
        controlPanel.add(sac2change);
        controlPanel.add(gridchange);
        controlPanel.add(numchange);
		controlPanel.add(griddims);
        controlPanel.add(gridXspin);
        controlPanel.add(gridYspin);
        controlPanel.add(dims);        
        controlPanel.add(dimXspin);
        controlPanel.add(dimYspin);
        controlPanel.add(fixdims);
        controlPanel.add(fixSpin);
        controlPanel.add(strokedims);
        controlPanel.add(strokeSpin);
        controlPanel.add(zoom);
        controlPanel.add(zoomSpin);
        controlPanel.add(showFix);
        controlPanel.add(blanklabels[4]);
        controlPanel.add(showSacs);
        controlPanel.add(blanklabels[5]);
        controlPanel.add(showGrid);
        controlPanel.add(showNums);           
        controlPanel.add(saveAndQuit);    
        mainPanel.add(controlPanel);   		
	}
	
	public void loadProps(DisplayProps props)
	//METHOD TO SET THE OPTIONS INLINE WITH THE CURRENT PROPERTIES
	{
		System.out.println("Loading props "+props.fixOn);
			showFix = new JCheckBox("Show fixations",props.fixOn);
			showSacs=new JCheckBox("Show saccades",props.sacsOn);
			showGrid=new JCheckBox("Show grid",props.gridOn);
			showNums=new JCheckBox("Show index",props.numsOn); 
	        showFix.addItemListener(this);
	        showSacs.addItemListener(this);
	        showGrid.addItemListener(this);
	        showNums.addItemListener(this); 							
			gridXspin.setValue(props.gridx);
			gridYspin.setValue(props.gridy);	
			dimXspin.setValue(props.imagex);
			dimYspin.setValue(props.imagey);
			zoomSpin.setValue(props.displayZoom);
			fixSpin.setValue(props.fixdim);
			strokeSpin.setValue(props.sacwidth);
			gpanel.update(props);
	}
	
    //METHOD REQUIRED BY THE ACTION LISTENER TRIGGERED BY BUTTON PRESS
    public void actionPerformed(ActionEvent event) 
    {
        if (event.getActionCommand().equals("fix1change"))
        //user is choosing a colour
        {
		Color newColor = JColorChooser.showDialog(mainPanel,"Choose Fixation Marker 1 Color",props.fix1col);	
			if (newColor != null) 
			{
    		props.fix1col=newColor;	
			}        
        }   
        if (event.getActionCommand().equals("fix2change"))
        //user is choosing a colour
		{
        Color newColor = JColorChooser.showDialog(mainPanel,"Choose Fixation Marker 2 Color",props.fix1col);	
			if (newColor != null) 
			{
    		props.fix2col=newColor;	
			}        
        } 
        if (event.getActionCommand().equals("sac1change"))
        //user is choosing a colour
		{
        Color newColor = JColorChooser.showDialog(mainPanel,"Choose Saccade 1 Color",props.fix1col);	
			if (newColor != null) 
			{
    		props.sac1col=newColor;	
			}        
        } 
        if (event.getActionCommand().equals("sac2change"))
        //user is choosing a colour
		{
        Color newColor = JColorChooser.showDialog(mainPanel,"Choose Saccade 2 Color",props.fix1col);	
			if (newColor != null) 
			{
    		props.sac2col=newColor;	
			}        
        } 
        if (event.getActionCommand().equals("gridchange"))
        //user is choosing a colour
		{
        Color newColor = JColorChooser.showDialog(mainPanel,"Choose Gridlines Color",props.fix1col);	
			if (newColor != null) 
			{
    		props.gridcol=newColor;	
			}        
        } 
        if (event.getActionCommand().equals("numchange"))
        //user is choosing a colour
		{
        Color newColor = JColorChooser.showDialog(mainPanel,"Choose Fixation Index Color",props.fix1col);	
			if (newColor != null) 
			{
    		props.numcol=newColor;	
			}        
        }                                                     
        gpanel.update(props);
        if (event.getActionCommand().equals("saveAndQuit"))
        //exit this frame and pass the new props back to the launching component
        {
	        if(containerB==null)
	        {
			container.passOptions(props);
			}
			else
			{
			containerB.passOptions(props);	
			}
        }        
    }
  
    public void itemStateChanged(ItemEvent e) 
    {
	//one of the checkboxes has changed, so may as well reset them all
	System.out.println("Loading props "+props.fixOn);
	props.fixOn=showFix.isSelected();
	props.sacsOn=showSacs.isSelected();
	props.gridOn=showGrid.isSelected();
	props.numsOn=showNums.isSelected();
	gpanel.update(props);
	}
	
	public void stateChanged(ChangeEvent e) 
	{
		props.gridx=((SpinnerNumberModel)modelX).getNumber().intValue();
		props.gridy=((SpinnerNumberModel)modelY).getNumber().intValue();
		props.imagex=((SpinnerNumberModel)modelDimX).getNumber().intValue();
		props.imagey=((SpinnerNumberModel)modelDimY).getNumber().intValue();    
		props.fixdim=((SpinnerNumberModel)modelFixDim).getNumber().intValue(); 
		props.sacwidth=((SpinnerNumberModel)strokeDim).getNumber().intValue(); 
		props.displayZoom=((SpinnerNumberModel)modelZoom).getNumber().intValue();   
		gpanel.update(props);
    }       
    	
}