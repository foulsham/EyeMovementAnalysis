	  //*****************************
	  // Eye movement processing programs
	  //*****************************
	  //coded by Tom Foulsham (lpxtf@psychology.nottingham.ac.uk)

/* 
	-a class to demo the graphical elements in a scanpath display
*/
package emtools.gui;

import javax.swing.*;
import java.awt.*;

public class GraphicPanel extends JPanel
{
DisplayProps props;

	public GraphicPanel(DisplayProps props)
	//CONSTRUCTOR takes an argument indicating the properties to use
	{
		this.props=props;
		setPreferredSize(new Dimension (400,80));
	}
	
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		//get the locations
		int div=getWidth()/6;
		int x=div/2;
		int y=getHeight()/2;
		
		g.setFont(new Font(g.getFont().getFontName(),Font.BOLD,14));
		
		//now paint each item if they're there		
		if(props.fixOn)//fixation marker
		{
            g.setColor(props.fix1col);        
            g.drawOval(x-((props.fixdim-1)/2), y -((props.fixdim-1)/2),props.fixdim, props.fixdim);		
		}
		x=x+div;
		
		if(props.fixOn)//fixation marker2
		{
            g.setColor(props.fix2col);        
            g.drawOval(x-((props.fixdim-1)/2), y -((props.fixdim-1)/2),props.fixdim, props.fixdim);		
		}		
		x=x+div;
		
		if(props.sacsOn)//saccade line
		{
            g.setColor(props.sac1col);
            g.fillRect(x-8,y-2,16,4);
            //g.drawLine(x-5,y,x+5,y);        	
		}
		x=x+div;
		
		if(props.sacsOn)//saccade line2
		{
            g.setColor(props.sac2col);
            g.fillRect(x-8,y-2,16,4);
            //g.drawLine(x-5,y,x+5,y);        	
		}
		x=x+div;
				
		if(props.gridOn)//grid lines
		{
			int griddimx=24-props.gridx;
			int griddimy=24-props.gridy;
			g.setColor(props.gridcol);        
            g.drawLine(x-griddimx-4,y-griddimy,x+griddimx+4,y-griddimy);
            g.drawLine(x-griddimx-4,y+griddimy,x+griddimx+4,y+griddimy);
			g.drawLine(x-griddimx,y-griddimy-4,x-griddimx,y+griddimy+4); 
			g.drawLine(x+griddimx,y-griddimy-4,x+griddimx,y+griddimy+4);					           	
		}
		x=x+div;

		if(props.numsOn)//numbers
		{        
            g.setColor(props.numcol);
            g.drawString("1",x-2,y+2);	
		}										
	}
	
	public void update(DisplayProps props)
	//updates the graphic when properties have changed
	{
		this.props=props;
		repaint();
	}
}