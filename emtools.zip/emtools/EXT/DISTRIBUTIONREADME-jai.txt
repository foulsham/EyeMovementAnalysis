DistributionREADME

DISTRIBUTION BY DEVELOPERS.  Subject to the terms and conditions of the Software License Agreement and the obligations, restrictions, and exceptions set forth below, You may reproduce and distribute the portions of Software identified below ("each a Redistributable"), provided that you comply with the following (note that You may be entitled to reproduce and distribute other portions of the Software not defined here as a Redistributable under certain other licenses as described in the THIRDPARTYLICENSEREADME):

(a) You distribute the Redistributable complete and unmodified and only bundled as part of Your applets and applications ("Programs"), 

(b) You do not distribute additional software intended to replace any
component(s) of the Redistributable,

(c) You do not remove or alter any proprietary legends or notices contained in or on the Redistributable.
 
(d) You only distribute the Redistributable subject to a license agreement that protects Sun's interests consistent with the terms contained in the Software License Agreement, and

(e) You agree to defend and indemnify Sun and its licensors from and against any damages, costs, liabilities, settlement amounts and/or expenses  (including attorneys' fees) incurred in connection with any claim, lawsuit or action by any third party that arises or results from the use or distribution of any and all Programs and/or Redistributable.  

The following files are each a Redistributable:

The following Redistributables may be redistributed only as a whole

JAVA Advanced Imaging API, Version 1.1.3


The following Redistributables may be redistributed separately

JAI Codecs - jai_codec.jar

JAI Java Implementation - jai_core.jar and jai_codec.jar (required to be redistributed together)
