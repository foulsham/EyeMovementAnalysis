function map=deriveBoundaryMask(win_dims,mask_dims,expfactor)
%derive a probability map where P declines exponentially away from a window
%boundary

%prep the mask and the centre
map=zeros(mask_dims(2),mask_dims(1));
x=mask_dims(1)/2;
y=mask_dims(2)/2;

%depending on the window size, we need to take angles relative to H or V
win_angle=rad2deg(atan(win_dims(2)/win_dims(1)));

%iterate through all points in the image
for i=1:mask_dims(2)
    for j=1:mask_dims(1)
        
        a=rad2deg(atan((i-y)/(j-x))); %angle of point from centre
        
        %first do it for points around the horizontal (this works ok)
        if (a<=win_angle && a>-win_angle) || a>=(win_angle+90) || a<-(win_angle+90)
            distfromcent=sqrt((i-y)^2+(j-x)^2); %distance of point from centre
            centtoboundary=(win_dims(1)/2)/cos(deg2rad(a));  %horizontal distance from centre to boundary
            distfromboundary=distfromcent-centtoboundary;%distance from point to boundary
            normdist=abs(distfromboundary/(expfactor)); %the expfactor scales the exponential decrease
            p=1/exp(normdist);            
            map(i,j)=p;
        else
        %try doing the vertical quadrants
            a=rad2deg(atan((j-x)/(i-y))); %angle of point from centre
            distfromcent=sqrt((i-y)^2+(j-x)^2); %distance of point from centre
            centtoboundary=(win_dims(2)/2)/cos(deg2rad(a));  %horizontal distance from centre to boundary
            distfromboundary=distfromcent-centtoboundary;%distance from point to boundary
            normdist=abs(distfromboundary/(expfactor)); %the expfactor scales the exponential decrease
            p=1/exp(normdist);            
            map(i,j)=p;            
        end
    end
end

%replace the odd NaN with 0
b=isnan(map);
map(b)=0;