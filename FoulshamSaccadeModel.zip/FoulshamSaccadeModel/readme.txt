SACCADE SIMULATIONS README

Code written by Tom Foulsham (foulsham@essex.ac.uk), 2011

This folder consists of several MATLAB .m files (functions) written to simulate saccades in complex images.  The modeling is discussed in Foulsham & Kingstone (under review, contact me for a pdf).


GETTING STARTED

To get started, navigate to the folder, type "demo" and enter.  
The function that does most of the work is "runModelSimulations.m", take a look at this or type "help runModelSimulations" to find out how you can call it with different arguments.


REQUIREMENTS

I wrote the code on Matlab R2008b on Mac OSX, but I've also tested it on R2011a (also on Mac).  At one point it was working on Octave and it should be easy enough to change if it's not working.

FOLDER CONTENTS

demo.m:
    A quick demo file which runs a couple of examples, displaying the output.
    
runModelSimulations.m:
    This is the main model function, which simulates a series of saccades and can display the output and/or return a data structure.
    
get2DRandomSample.m:
    This function returns a random coordinate sampled from the probability map.  Called by runModelSimulations.m.
    
randsample.m:
    This function was borrowed from the statistics toolbox and is called by get2DRandomSample.m.
    
deriveBoundaryMask.m:
    Running the simulations with a "boundary" model requires a probability map which drops off away from the window boundary. This takes a little time to compute, so it's easier to generate it in advance.  Called by runModelSimulations.m (only when using the boundary model.

testhouse01.jpg:
    An example image.  You can pass a different filename to the main function if necessary (it is just for graphics and makes no difference to the simulation).