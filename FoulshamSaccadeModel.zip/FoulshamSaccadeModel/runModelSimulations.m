function [modelStructure,handles]=runModelSimulations(win_dims,lastFix,modelTypes,supressOutput,waitforclick,customimage)
%[modelStructure,handles]=runModelSimulations(win_dims,lastFix,modelTypes,supressOutput,waitforclick,customimage)
%Simulate a series of saccades based on different modelling parameters. If
%output is enabled, simulations will display a moving window over the test
%image, along with the probability map and histograms of the saccades made.
%
%win_dims: a 2-item vector giving the w,h dimensions of the window
%
%lastFix: the number of simulated fixations/saccades to produce (i.e. how
%   long to keep going
%
%modelTypes: a cell array of strings specifying which model types to
%   simulate.  3 supported types: 'info','feature' and 'boundary'.
%   Default is all three
%
%supressOutput: a boolean controlling whether to supress graphical output
%   and saccade coordinates or not.  Default is 0 (displays graphics).
%
%waitforclick: a boolean controlling whether to wait for a mouse click
%   prior to each saccade.Default is 0 (doesn't wait).
%
%customimage: a string path to a different image to use from the standard.
%
%optional return values give data structures for the modelling results and
%handles for easier access to figure components
%
%EXAMPLES:
%   runModelSimulations([100,100],10);  simulates 10 saccades with a square
%   100 x 100 pixel window, using all model types and displaying all 3
%
%   info=runModelSimulations([100,300],20,{'info'},1);   runs the info seeking
%   model for 20 saccades on a rectangular window, without displaying the
%   graphics.  Returns a data structure with coordinates etc.

%set up the defaults
%set the window size for convenience
win_w=win_dims(1);
win_h=win_dims(2);

%check for the wait flag
if nargin<6
    customimage='testhouse01.jpg';
end

%check for the wait flag
if nargin<5
    waitforclick=0;
end

%if output argument is missing, display output
if nargin<4
    supressOutput=0;
end

%return with an error if we're trying to wait but not displaying anything
if waitforclick && supressOutput
   disp('Error cannot click through without displaying!');
   return
end

%if types aren't specified, use them all 
if nargin<3
    modelTypes={'info','feature','boundary'};
end
b=strcmp('info',modelTypes) | strcmp('feature',modelTypes) | strcmp('boundary',modelTypes);
modelTypes=modelTypes(b);
nMods=length(modelTypes);

if nargout>0
    modelStructure=[]; %return the model structure containing all the data
end
if nargout>1
    handles=[];
end


%print warning if other things are missing
if nargin<2 || nMods<1
    disp('ERROR: arguments missing or model types incorrect!');
    return
end

%load in image and save width and height
im=imread(customimage);
im_w=size(im,2);
im_h=size(im,1);
im_ar=im_w/im_h; %also save the aspect ratio (for scaling those pesky graphs to make stuff look neat

scale_factor=1/4; %scale parameter to speed up
imy=im_h*scale_factor; %recalculate these for use later
imx=im_w*scale_factor;
winx=round((win_w/2)*scale_factor);
winy=round((win_h/2)*scale_factor); 


%initialise model states
%now do this by looping through whichever models we're using
for i=1:nMods
    m.(modelTypes{i}).imdisplay=uint8(zeros(im_h,im_w,3));%what the image looks like on this fixation
        m.(modelTypes{i}).imdisplay(:,:,:)=110;%all grey to begin with     
    m.(modelTypes{i}).map=zeros(imy,imx);%a probability map.  
    %Fixation will go to the highest probability.  Scaled for speed.
    m.(modelTypes{i}).fixSequence=[im_w/2,im_h/2];%fixation coordinates, x,y, start in middle
    m.(modelTypes{i}).HV=[0 0];%keep track of saccade statistics
    m.(modelTypes{i}).Hamps=[];
    m.(modelTypes{i}).Vamps=[];    
    %set window at centre
    m.(modelTypes{i}).imdisplay((im_h/2)-(win_h/2):(im_h/2)+(win_h/2),...
        (im_w/2)-(win_w/2):(im_w/2)+(win_w/2),:)...
        =im((im_h/2)-(win_h/2):(im_h/2)+(win_h/2),...
        (im_w/2)-(win_w/2):(im_w/2)+(win_w/2),:);
end

if ~supressOutput

    disp(['Running simulation with window size of ',int2str(win_w),' x ',int2str(win_h),...
        ' for ',int2str(lastFix),' saccades.'])
    
    %initialise figure, store the handles
    h.fig=figure('Position',[100 100 1000 (200*nMods)+50]);
    
    %initialise plots for each model (i.e. each row in the figure)
    for i=1:nMods
        %first plot is the image as it looks on the current fixation
        h.(modelTypes{i}).pic=subplot(nMods,4,1+((i-1)*4)); %axis image;
        h.(modelTypes{i}).i=image(m.(modelTypes{i}).imdisplay,'Parent',h.(modelTypes{i}).pic);axis image;
        %title('GC saccade plot','FontSize',14)
        axis off
        
        %position the saccade plot over the top
        set(h.(modelTypes{i}).pic,'Units','pixels');
        p=get(h.(modelTypes{i}).pic,'Position');
        h.(modelTypes{i}).sac=axes('Units','pixels','Position',p);
        h.(modelTypes{i}).scat=plot(h.(modelTypes{i}).sac,[im_w/2,im_w/2],[im_h/2,im_h/2],'-ob'); %start off the saccade plot
        axis image;
        set(h.(modelTypes{i}).sac,'Color','none','XLimMode','manual','YLimMode','manual'...
        ,'YDir','reverse','XLim',[1 im_w],'YLim',[1 im_h]);
        axis off

        %add a title for this model, positioned with reference to the image
        %plot
        set(h.(modelTypes{i}).pic,'Units','normalized');
        p=get(h.(modelTypes{i}).pic,'Position');
        annotation('textbox',[p(1)-0.11,p(2)+0.16,0.1,p(4)/2],...
            'String',{'Model:',upper(modelTypes{i})},...
            'FontSize',14,...
            'HorizontalAlignment','center',...
            'VerticalAlignment','middle',...
            'LineStyle','none');
        
        %prepare the other plots, with titles
        h.(modelTypes{i}).prob=subplot(nMods,4,2+((i-1)*4)); 
            h.(modelTypes{i}).m=imagesc(m.(modelTypes{i}).map,'Parent',h.(modelTypes{i}).prob);axis image; axis off
            %title('Current probability plot','FontSize',14)
        h.(modelTypes{i}).dir=subplot(nMods,4,3+((i-1)*4));   
            h.(modelTypes{i}).hbar=bar(h.(modelTypes{i}).dir,[0,0],'r');
            set(h.(modelTypes{i}).dir,'NextPlot','add');
            h.(modelTypes{i}).vbar=bar(h.(modelTypes{i}).dir,[0,0],'g');
            set(h.(modelTypes{i}).dir,'XTickLabel',{'H';'V'});
            set(h.(modelTypes{i}).dir,'PlotBoxAspectRatio',[im_ar,1,1]);
            %title('Direction histogram','FontSize',14)
        h.(modelTypes{i}).amp=subplot(nMods,4,4+((i-1)*4));
            %title('Amplitude histogram','FontSize',14) 
            h.(modelTypes{i}).hline=line('Parent',h.(modelTypes{i}).amp,...
                'XData',0:0.05:1,'YData',zeros(1,21),'DisplayName','H','Color','r','LineWidth',3);
            h.(modelTypes{i}).vline=line('Parent',h.(modelTypes{i}).amp,...
                'XData',0:0.05:1,'YData',zeros(1,21),'DisplayName','V','Color','g','LineWidth',3);  
            legend(h.(modelTypes{i}).amp,'show');
            set(h.(modelTypes{i}).amp,'PlotBoxAspectRatio',[im_ar,1,1]);
    end
 
    %drawnow()
    
    %now we have all the plots in place, we need to check they're lined up
    %again! (probably better way to stop it resizing but heh!)
    for i=1:nMods
        set(h.(modelTypes{i}).pic,'Units','normalized');
        p=get(h.(modelTypes{i}).pic,'Position');
        set(h.(modelTypes{i}).sac,'Units','normalized','Position',p);      
    end
    
    %add titles for the columns, this works out neater than using TITLE
    p=[get(h.(modelTypes{1}).pic,'Position');...
        get(h.(modelTypes{1}).prob,'Position');...
        get(h.(modelTypes{1}).dir,'Position');...
        get(h.(modelTypes{1}).amp,'Position')];
    t={'GC saccade plot','Current probability plot','Direction histogram','Amplitude histogram'};
    for i=1:4
        annotation('textbox',[p(i,1)-0.02,p(i,2)+p(i,4)-0.02,p(i,3)+0.04,0.06],'String',t{i},...
            'FontSize',14,...
            'HorizontalAlignment','center',...
            'VerticalAlignment','bottom',...
            'LineStyle','none');
    end
    
    drawnow()
    
end

%prepare the boundary map in advance, if we're using this model
if sum(strcmp('boundary',modelTypes))
    %use the scaled version, but pad to a large enough size
   m.boundary.boundaryMask=deriveBoundaryMask([winx*2,winy*2],...the scaled window size
       [imx*3,imy*3],...the scaled image size, padded to avoid exceptions 
       imx/8);%FREE PARAMETER: exponential decrease away from the boundary, 
            %changed to 1/8 of scaled image width which seems to work ok
end

%repeat with every saccade
for f=1:lastFix
   
    %deal with each model in the user-specified order
    for i=1:nMods
        
        %get the current coordinates
        x=m.(modelTypes{i}).fixSequence(f,1);
        y=m.(modelTypes{i}).fixSequence(f,2);
        
        %scale them for the probability maps
        sx=round(x*scale_factor);%round to avoid exceptions
        sy=round(y*scale_factor);
        
        %SACCADE PROBABILITY MAP CALCULATION
        %different for different models
        %first step is to create the probability maps
        
        %make a scaled mask (used by the info and feature models)
        if strcmp(modelTypes{i},'info') || strcmp(modelTypes{i},'feature')
            scaled_mask=logical(zeros(imy*3,imx*3)); %#ok<LOGL> empty map
                scaled_mask(sy+imy-winy:sy+imy+winy,...set window to true
                    sx+imx-winx:sx+imx+winx)=1;        
        end
        
        %compute the probability map FOR THE INFO SEEKING MODEL
        if strcmp(modelTypes{i},'info')
            anti_mask=scaled_mask;% invert the main part of the scaled mask
            anti_mask(imy+1:imy*2,imx+1:imx*2)=not(anti_mask(imy+1:imy*2,imx+1:imx*2));

            %iterate through scaled image space, at each point work out the number of new pixels that would be
            %covered by a window at this location            
            for k=1:imy
                for j=1:imx
                    win=anti_mask(k+imy-winy:k+imy+winy,j+imx-winx:j+imx+winx);
                    m.(modelTypes{i}).map(k,j)=sum(sum(win));
                end
            end          
        end
        
        %the probability map for the FEATURE SEEKING MODEL is easy!
        if strcmp(modelTypes{i},'feature')
            m.(modelTypes{i}).map(scaled_mask(imy+1:imy*2,imx+1:imx*2))=1;
            m.(modelTypes{i}).map(~scaled_mask(imy+1:imy*2,imx+1:imx*2))=0;
            ...
            %     rand((2*winy)+1,(2*winx)+1);%areas outside the window stay at zero.  Those inside are random.
        end
        
        %compute the map for the new boundary version
        %just transpose the mask we made earlier
        if strcmp(modelTypes{i},'boundary')
            bx=round((imx*3)/2);%the centre of the mask (rounded to avoid exceptions)
            by=round((imy*3)/2);
            m.(modelTypes{i}).map=...
                m.boundary.boundaryMask(by-sy+1:by+(imy-sy),bx-sx+1:bx+(imx-sx));
        end
        
        %draw the probability maps
        if ~supressOutput
            h.(modelTypes{i}).m=imagesc(m.(modelTypes{i}).map,'Parent',h.(modelTypes{i}).prob);
            axis(h.(modelTypes{i}).prob,'image')
            axis(h.(modelTypes{i}).prob,'off')
        end
        
    end %of the probability map computations
    
    %now wait for a click or button press if necessary
    if waitforclick
        t=waitforbuttonpress;
    end
    drawnow() %ensures the maps get shown first
    
    %now simulate the next saccade    
    for i=1:nMods   
        %GENERATE A RANDOM SACCADE DESTINATION, DRAWN BY WEIGHTED SAMPLING FROM
        %PROBABILITY DISTRIBUTIONS
        yx=get2DRandomSample(m.(modelTypes{i}).map,1);        
        yx=round(yx./scale_factor); %remember to scale back up and then add to sequence
        x=yx(2);
        y=yx(1);
        m.(modelTypes{i}).fixSequence=[m.(modelTypes{i}).fixSequence;x,y];
        
        %work out which direction the saccade went (H or V), and add this to
        %the current histogram.  Make polar instead?
        %also store the amplitude of the current saccade
        
        a=atan2(y-m.(modelTypes{i}).fixSequence(f,2),x-m.(modelTypes{i}).fixSequence(f,1));
        if (a<(-pi/4) && a>=(-pi+(pi/4))) || (a>=(pi/4) && a<(pi-(pi/4)))
            m.(modelTypes{i}).HV(2)=m.(modelTypes{i}).HV(2)+1;
            m.(modelTypes{i}).Vamps=[m.(modelTypes{i}).Vamps;...
                sqrt((y-m.(modelTypes{i}).fixSequence(f,2))^2 ...pythag
                + (x-m.(modelTypes{i}).fixSequence(f,1))^2)]; 
        else
            m.(modelTypes{i}).HV(1)=m.(modelTypes{i}).HV(1)+1;
            m.(modelTypes{i}).Hamps=[m.(modelTypes{i}).Hamps;...
                sqrt((y-m.(modelTypes{i}).fixSequence(f,2))^2 ...pythag
                + (x-m.(modelTypes{i}).fixSequence(f,1))^2)]; 
        end
        
        %if we're displaying...
        %generate a moving window, then draw everything
        if ~supressOutput
            
            %make a mask around the current location (padded to avoid
            %overflow
            mask=logical(zeros(im_h*3,im_w*3)); %#ok<LOGL>
            mask(y+im_h-(win_h/2):y+im_h+(win_h/2),x+im_w-(win_w/2):x+im_w+(win_w/2))=1;            
            mask=mask(im_h+1:im_h*2,im_w+1:im_w*2);
            mask=repmat(mask,[1,1,3]); %tile to make 3D
            
            %set the image and draw it
            m.(modelTypes{i}).imdisplay(:,:,:)=110;%all grey to begin with
            m.(modelTypes{i}).imdisplay(mask)=im(mask);
            set(h.(modelTypes{i}).i,'CData',m.(modelTypes{i}).imdisplay);            
            
            set(h.(modelTypes{i}).scat,'XData',m.(modelTypes{i}).fixSequence(:,1),'YData',m.(modelTypes{i}).fixSequence(:,2))
            set(h.(modelTypes{i}).hbar,'YData',[m.(modelTypes{i}).HV(1),0]);
            set(h.(modelTypes{i}).vbar,'YData',[0,m.(modelTypes{i}).HV(2)]);
            if ~isempty(m.(modelTypes{i}).Hamps)
                n=histc(m.(modelTypes{i}).Hamps./1024,0:0.05:1);
                    set(h.(modelTypes{i}).hline,'YData',n);
            end
            if ~isempty(m.(modelTypes{i}).Vamps)
                n=hist(m.(modelTypes{i}).Vamps./1024,0:0.05:1);
                    set(h.(modelTypes{i}).vline,'YData',n);
            end
            
            %print a message
            disp(['New saccade generated by ',modelTypes{i}, ' seek model to ',int2str(x),', ',int2str(y)])
         
        end
        

    end
    
    drawnow(); %make sure we're showing everything
    
end

    if nargout>0
        modelStructure=m; %return the model structure containing all the data
    end
    if nargout>1 && ~supressOutput
        handles=h;
    end
    
end % of function

