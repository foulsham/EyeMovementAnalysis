function demo()
%a quick demo of the different models

%tell the user what's coming up
uiwait(msgbox('This is a quick demo which will check the models are working and display the results.  Click OK to see the feature driven model run for 5 saccades','Saccade simulation','modal'))

%run a quick simulation and display the results
runModelSimulations([200,200],5,{'feature'});

%close and run a different simulation
uiwait(msgbox('Click OK to see the information driven model run for 5 saccades, but with a rectangular window.','Saccade simulation','modal'))
close gcf
runModelSimulations([100,400],5,{'info'});

uiwait(msgbox('Done!','Saccade simulation','modal'))

end