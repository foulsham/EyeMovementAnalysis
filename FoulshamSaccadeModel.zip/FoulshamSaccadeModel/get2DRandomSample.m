function rv=get2DRandomSample(dist,n)
%R=GET2DRANDOMSAMPLE(DIST,N)
%get a random 2D coordinate, sampled non-uniformly according to the
%distribution in dist.  Generates n samples, and returns an n*2 matrix of
%y,x coordinates.
%now uses RANDSAMPLE from the stats toolbox, then just converts to 2D.


%first, put the map into a 1D vector
v=reshape(dist,size(dist,1)*size(dist,2),1);

%then use randsample to sample randomly, with replacement, according to the
%probabilities in v.
R=randsample(size(dist,1)*size(dist,2),n,true,v);

%then convert back to 2D
[y,x]=ind2sub(size(dist),R);
rv=[y,x];

%OLD WAY
%get the cumulative sum (i.e. each value added cumulatively)
% c=cumsum(v);
% 
% %define random numbers in the range 0-sum(v)
% r=ceil(rand(n,1)*c(length(v)));
% 
% %the random seed determines which index in vector is sampled
% for i=1:n
%     b=c<r(i);%what is the last index where r is greater than c
%     z=find(b, 1, 'last' );
%     [y,x]=ind2sub(size(dist),z);%convert back to subscripts into dist
%     rv(i,:)=[y,x];
% end