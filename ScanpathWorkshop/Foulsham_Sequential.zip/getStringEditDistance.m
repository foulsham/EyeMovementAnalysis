function [d, strings] =getStringEditDistance(sp1,sp2,gridXY, imsize, condense)
%GETSTRINGEDITDISTANCE.M
%Returns the string edit difference (or Levenshtein distance), calculated
%by transforming the scanpaths into a character string.
%[d, strings] = getStringEditDistance(sp1,sp2,gridYX,imsize, condense)
%
%     d = getStringEditDistance(sp1,sp2) compares the two scanpaths.
%     If sp1 and sp2 are numeric, they should be N x 2 or N x 3 matrixes of
%     fixation data, and by default a 5 x 5 grid is used to transform them
%     into a character sequence.
%       If sp1 and sp2 are strings, they are compared directly.
%     
%     d = getStringEditDistance(sp1,sp2,gridYX) uses the [rows,
%     columns] in gridYX rather than the default 5 x 5.
%
%     d = getStringEditDistance(sp1,sp2,gridYX,imsize) uses a
%     display size with [rows, columns] given in imsize. Default is [768
%     1024].
%
%     d = getStringEditDistance(sp1,sp2,gridYX,imsize, condense)
%     toggles whether repetitions in the string should be condensed into a
%     single character e.g., ABBCCDD > ABCD. Default is false.
%
%     [d, strings] = getStringEditDistance(...) also returns the two
%     character strings (after any condensing)


%default grid dimensions
if nargin<3
    gridXY=[5,5];
else
    if isempty(gridXY)
        gridXY=[5,5];
    end
end

%default image dimensions
if nargin<4
    imsize=[768 1024];
else
    if isempty(imsize)
        imsize=[768 1024];
    end
end
 
%if we have numeric scanpaths, transform to strings using grid
if isnumeric(sp1)
    %use ascii characters to make strings
    %start at A
    gridCodes=(1:gridXY(1)*gridXY(2))+64;
    gridCodes=reshape(gridCodes,[gridXY(2),gridXY(1)]);
    gridCodes=gridCodes';%i prefer it going L>R
    w=imsize(2)/gridXY(2);
    h=imsize(1)/gridXY(1);

    %get grid square coordinates
    %these are linear indexes into the grid
    g1 = sub2ind(gridXY,ceil(sp1(:,2)./h),ceil(sp1(:,1)./w));
    g2 = sub2ind(gridXY,ceil(sp2(:,2)./h),ceil(sp2(:,1)./w));
    string1 = char(gridCodes(g1));
    string2 = char(gridCodes(g2));
else
    string1=sp1;
    string2=sp2;
end


%if necessary, condense the strings
if nargin==5
   if condense
      temp(1,1)=string1(1);
      for c=2:length(string1)
         if ~strcmp(string1(c),string1(c-1))
             temp=[temp;string1(c)];
         end
      end
      string1=temp;
      
      clear temp; temp(1,1)=string2(1);
      for c=2:length(string2)
         if ~strcmp(string2(c),string2(c-1))
             temp=[temp;string2(c)];
         end
      end
      string2=temp;      
   end
end

%now do the comparison by making the cost matrix
cM = zeros(length(string1)+1,length(string2)+1);
%first row and column dictated by N
cM(2:end,1)=(1:length(string1))';
cM(1,2:end)=1:length(string2);
for i=1:length(string1)
    for j=1:length(string2)
        cost=~strcmp(string1(i),string2(j));
        cM(i+1,j+1)=min([cM(i,j+1)+1, cM(i+1,j)+1, cM(i,j)+cost]);
    end
end

d=cM(end,end)/max(length(string1),length(string2));

%return the strings if necessary
if nargout==2
    strings = {string1, string2};
end

