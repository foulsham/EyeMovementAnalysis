function [d, pairs] =getUniqueAssignmentDistance(sp1,sp2)
%GETUNIQUEASSIGNMENTDISTANCE.M
%Returns the average linear distance between fixations in each scanpath,
%calculated by matching each fixation to one only in the other set.
%[d, pairs] = getUniqueAssignmentDistance(sp1,sp2)
%
%     d = getUniqueAssignmentDistance(sp1,sp2) compares each fixation in sp1
%     with another in sp2 (and vice versa). Both should be N x 2 or N x 3 
%     matrices. Returns d, the average distance, in pixels. The pairing
%     with the closest mean difference is used. Requires that the length of
%     sp1 and sp2 is the same.
%
%     [d, pairs] = getLinearDistance(...) also returns a matrix giving the
%     indexes of the matching pairs between sp1 and sp2.

%get a matrix of inter-fixation distances
for i=1:size(sp1,1)
    for j=1:size(sp2,1)
        dM(i,j) = sqrt( ( (sp1(i,1) - sp2(j,1) )^2 ) + ( (sp1(i,2) - sp2(j,2) )^2 ) );
    end
end

%check every permutation of comparing A to B
%NB, perms is impractical for very long scanpaths
if size(sp1,1)~=size(sp2,1)
    disp('ERROR: scanpaths must be the same size')
    return
end

if size(sp1,1)>10
   disp('WARNING: getting the permutations of a long scanpath can take a long time!') 
end

allPerms = perms(1:size(sp1,1));
d=zeros(size(allPerms,1),1);
for p=1:length(allPerms)
    %for each permutation, get the mean distance
    d(p)= mean( dM(sub2ind(size(dM),1:size(dM,1),allPerms(p,:))) );
end

%find the lowest distance
[d,i]=min(d);

%return a matrix showing the matching pairs if necessary
if nargout==2
    pairs=[1:size(sp1,1);allPerms(i,:)];
end

