function h=plotScanpaths(sp1,sp2,im,imsize,ax)
%PLOTSCANPATHS.M
%Convenient function for plotting one or two individual scanpaths
%h = plotScanpaths(sp1,sp2,im,imsize,ax)
%
%     plotScanpaths(sp1) plots a single scanpath as a series of lines and
%     circles. sp1 is an N x 2 matrix giving x, y coordinates, or an N x 3
%     matrix giving x, y and duration values for a series of fixations.
%     
%     plotScanpaths(sp1,sp2) plots two scanpaths on the same axis.
%     
%     plotScanpaths(sp1,sp2,im) displays an image under the scanpaths. 
%     im is a path to an image which should be the same size as the display size.
%     
%     plotScanpaths(....imsize) changes the size of the display (default is [768 1024])
%         
%     plotScanpaths(...ax) plots into the axis ax rather than the new/current axis.
%         
%     h = plotSCanpaths(...) returns a handle to the axis

%formatting parameters
cols={'r','b'}; %the colours we will plot with

%check for proper scanpaths
toPlot={};
p=1;
if nargin>=1 && size(sp1,2)>=2 && size(sp1,1)>=1
    toPlot{p}=sp1;
    p=2;
end

if nargin>=2 && size(sp2,2)>=2 && size(sp2,1)>=1
    toPlot{p}=sp2;
end

%return an error if we don't have at least one
if isempty(toPlot)
    disp('ERROR: no scanpaths given')
    return
end

%if using recent mac versions of octave, this is a better GUI
try
	graphics_toolkit fltk
	figure
end

%check for arguments
if nargin < 5
    ax=gca;
end

if nargin<4
    imsize=[768 1024];
end

%make sure we clear plots first
cla(ax)
hold(ax,'on');

%display an image if we've got one
if nargin>=3 && ~isempty(im) && exist('im','var')
    %note that octave doesn't always seem to support image function, hence
    %the try block...
   try
        myimage=imread(im);
        image(myimage)
   catch
        myimage=imread(im);
        imshow(myimage)      
   end
end

%set axis limits etc
set(ax,'XLim',[0 imsize(2)],'YLim',[0 imsize(1)],...
    'XTick',0:imsize(2)/5:imsize(2),...
    'YTick',0:imsize(1)/5:imsize(1));
axis(ax,'image')
axis(ax,'ij')


%loop through the scanpaths
for s=1:length(toPlot)
    sp=toPlot{s};
    
    %do we have durations to plot? If so, calculate the marker sizes in advance
    if size(sp,2)==3
       m = (sp(:,3)./200) * 10;
    else
       m = ones(size(sp,1),1)*10; 
    end
    
    %for each fixation...
    for i = 1:size(sp,1)-1
        xc = [sp(i,1),sp(i+1,1)];%x coordinates of saccade
        yc = [sp(i,2),sp(i+1,2)];%y coordinates of saccade
        plot(ax,xc,yc,[cols{s},'--']); %plot a line for the saccade
        %plot the fixation...
        if i == 1 %fill the first marker to show the start
            plot(ax,xc(1),yc(1),[cols{s},'o'],'MarkerSize',m(i),'MarkerFacecolor',cols{s})
        else
            plot(ax,xc(1),yc(1),[cols{s},'o'],'MarkerSize',m(i))
        end
    end
    plot(ax,xc(2),yc(2),[cols{s},'o'],'MarkerSize',m(i))
end
hold(ax,'off');

%optional formatting stuff
set(ax,'Box','on')
grid(ax,'on')

%if necessary return the handle
if nargout==1
    h=ax;
end