%DEMOSCANMATCH
%a script to demonstrate running ScanMatch

%add the ScanMatch folder to the current path
addpath ScanMatch

%load some example data
load ScanMatchInfo
load ScanMatch_DataExample

%change to sequence of characters
A=ScanMatch_FixationToSequence(data1,ScanMatchInfo);
B=ScanMatch_FixationToSequence(data2,ScanMatchInfo);

%run ScanMatch
%the 'ShowViewer' argument runs a little GUI
ScanMatch(A,B,ScanMatchInfo,'ShowViewer',1) %returns similarity from 0 to 1

pause

%try changing the settings in ScanMatch to take into account duration
ScanMatchInfo.TempBin = 50; %now it will bin durations into bins of 50ms

A=ScanMatch_FixationToSequence(data1,ScanMatchInfo);
B=ScanMatch_FixationToSequence(data2,ScanMatchInfo);
ScanMatch(A,B,ScanMatchInfo,'ShowViewer',1) %returns similarity from 0 to 1

pause

%try changing the "gap penalty"
load ScanMatchInfo
A=ScanMatch_FixationToSequence(data1,ScanMatchInfo);
B=ScanMatch_FixationToSequence(data2,ScanMatchInfo);
ScanMatchInfo.GapValue = -2;%this will make gaps less likely
ScanMatch(A,B,ScanMatchInfo,'ShowViewer',1) %returns similarity from 0 to 1
