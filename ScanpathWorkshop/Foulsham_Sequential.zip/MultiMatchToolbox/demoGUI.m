
function f=demoGUI(scanpathA,scanpathB)
%DEMOGUI.M
% Launches a graphical interface demonstrating a scanpath comparison with the MultiMatch method.
% 
%   demoGUI() - launches the demo with two random scanpaths being compared
% 
%   demoGUI(scanpathA, scanpathB) -launches the demo and compares the two scanpaths given. 
%   The two arguments are N x 3 matrices with x,y,duration values for a
%   series of fixations. For the purposes of this demo the display area is
%   assumed to be 1024 x 768 pixels in size.

%check the arguments
if nargin<2
   disp('Launching demo GUI with randomly generated scanpaths...')
   r=rand(16,3);
   r(:,1)=ceil(r(:,1)*1024);
   r(:,2)=ceil(r(:,2)*768);
   r(:,3)=ceil(r(:,3)*600);
   scanpathA=r(1:8,:); %#ok<NOPRT>
   scanpathB=r(9:16,:); %#ok<NOPRT>
end

%transform into scanpath structure
global sp1;
global sp2;
sp1 = generateStructureArrayScanpath(scanpathA);
sp2 = generateStructureArrayScanpath(scanpathB);

%make the main figure which will display everything
f=figure('MenuBar','none','DockControls','off','Name','MultiMatch Demo','NumberTitle','off','Position',[100,100,800,600]);

%make the axes which will show the scanpaths
originalSpAx=subplot(5,2,[1 3]);
set(originalSpAx,'XLim',[0 1024],'YLim',[0 768],'Box','on');
axis image
title('Scanpaths (original)','FontSize',14)
simplifiedSpAx=subplot(5,2,[7 9]);
set(simplifiedSpAx,'XLim',[0 1024],'YLim',[0 768],'Box','on','Tag','simpAx');
axis image
title('Scanpaths (simplified)','FontSize',14)

%plot the original scanpaths
plotTheseScanpaths(originalSpAx,sp1,sp2);

%use the other axes to layout the GUI nicely
%this one just gives us the title and a reference
thresholdBox=subplot(5,2,2);axis off;
title('Simplification settings','FontSize',14)
p=get(thresholdBox,'Position');

%add sliders for threshold settings etc
%neater way to do this...
global c;
c=cell(3,5);%store all three controls in a cell array
c{1,1}='Amplitude (pix)';c{1,2}='ampSlider';c{1,3}=[0,1024,128,1/64,1/16];
c{2,1}='Direction (deg)';c{2,2}='dirSlider';c{2,3}=[0,180,45,1/180,1/45];
c{3,1}='Duration (ms)';c{3,2}='durSlider';c{3,3}=[0,1000,1000,0.01,0.1];
for s=1:3
    v=p(2)+p(4)-(s*0.06);%vertical position

    uicontrol(gcf,'Units','normalized','Style','text','String',c{s,1},...% text label
        'BackgroundColor',[0.80,0.80,0.80],'Position',[p(1)-0.1,v,0.2,0.04]);
     
    c{s,4}=uicontrol(gcf,'Units','normalized','Style','slider','Position',[p(1)+0.1,v,0.2,0.04],'Tag',c{s,2},...
        'Min',c{s,3}(1),'Max',c{s,3}(2),'Value',c{s,3}(3),'Callback',@changeSlider,'SliderStep',c{s,3}(4:5));  %slider 
    
    c{s,5}=uicontrol(gcf,'Units','normalized','Style','text','String',num2str(c{s,3}(3)),...% text labels to show current value
        'Position',[p(1)+0.3,v,0.1,0.04],'BackgroundColor',[0.80,0.80,0.80]);
end
    
%add a button for doing the simplification
buttonBox=subplot(5,2,4);axis off;
p=get(buttonBox,'Position');p(1)=p(1)+(p(3)*0.125);p(2)=p(2)+(p(4)*0.125);p(3)=p(3)*0.75;p(4)=p(4)*0.75;
uicontrol(gcf,'Style','pushbutton','String','Simplify + Compare',...
    'Units','normalized','Position',p,'FontSize',14,'Tag','simplifyControl',...
    'Callback',@buttoncb);

%define a rectangle which will hold the path mapping and results
resultsBox=subplot(5,2,[6 8 10]);
axis off;
title('Path mapping and results','FontSize',14)
pRes=get(resultsBox,'Position');

%add a table which will show the results
% resultsBox=subplot(5,2,[8 10]);
% axis off;
% title('Path mapping and results','FontSize',14)
% p=get(resultsBox,'Position');

%can't change font of row names? so just use it as data...
d={'Vector similarity',NaN;'Length similarity',NaN;'Direction similarity',NaN;...
    'Position similarity',NaN;'Duration similarity',NaN};
p=pRes;p(4)=p(4)*0.5;
%get pixels for table widths
set(resultsBox,'Units','pixels');
px=get(resultsBox,'Position');
set(resultsBox,'Units','normalized');
resTable=uitable('Units','normalized','Position',p,'Enable','on','Tag','tab',...
    'RowName',[],'ColumnName',[],'Data',d,'FontSize',14,'ColumnWidth',{px(3)*0.7,px(3)*0.3}); %column widths don't resize well
drawnow()
e=get(resTable,'Extent');e=e+0.005;
set(resTable,'Position',[p(1)+((p(3)-e(3))/2),p(2)+((p(4)-e(4))/2),e(3),e(4)]);

%also want to show a representation of the mapping between scanpaths
p=pRes;p(4)=p(4)*0.4;p(2)=p(2)+((p(4)-e(4))/2)+e(4)+0.05;

mapBox=axes('Units','normalized','Box','on','XLim',[0 1],'YLim',[0 1],'Position',p,...
    'XTickLabel','','YTickLabel','','XTick',[0:1/size(scanpathA,1):1],'YTick',[0:1/size(scanpathA,1):1],'Tag','mAx');
grid on
axis square


%-----------------
%when the user changes a slider...
function changeSlider(hObject, eventdata, handles)
global c;
thistag=get(hObject,'Tag');%find which slider it was
thisval=get(hObject,'Value');
b=strcmp(thistag,c(:,2));
set(c{b,5},'String',thisval);

%-----------------
%when we plot these scanpaths
function plotTheseScanpaths(h, sp1, sp2)
%set(h,'XLim',[0 1024],'YLim',[0 768],'Box','on','Grid','on');
offset = 0.01;
sp=[sp1,sp2];
cols={'r','b'};

%make sure we clear plots first
cla(h)
hold(h,'on');
for s=1:2
    for i = 1:length(sp(s).saccade.x)
        xc = [sp(s).saccade.x(i),sp(s).saccade.x(i) + sp(s).saccade.lenx(i)]+offset;
        yc = [sp(s).saccade.y(i),sp(s).saccade.y(i) + sp(s).saccade.leny(i)]+offset;
        plot(h,xc,yc,[cols{s},'--']);         
        if i == 1
            plot(h,xc(1),yc(1),[cols{s},'o'],'MarkerSize',10*sp(s).fixation.dur(i)/200,'MarkerFacecolor',cols{s})
        else
            plot(h,xc(1),yc(1),[cols{s},'o'],'MarkerSize',10*sp(s).fixation.dur(i)/200)
        end
    end
    plot(h,xc(2),yc(2),[cols{s},'o'],'MarkerSize',10*sp(s).fixation.dur(i+1)/200)
end
hold(h,'off');

%-----------------
%when the user clicks one of the buttons
function buttoncb(hObject, eventdata, handles)
global c;
global sp1;
global sp2;
%call the main scanpathComparison method, using the thresholds given.
GT=get(c{1,4},'Value');
DT=get(c{2,4},'Value');
DuT=get(c{3,4},'Value');
[simp1,simp2,rv,path,M_assignment,ki,kj] = mainProposed(sp1,sp2,GT,DT,DuT,[1024 768]);

%plot the simplified scanpaths into the prepared axis
ax=findobj('Tag','simpAx');
plotTheseScanpaths(ax,simp1,simp2);

%highlight the mapping between scanpaths
m=findobj('Tag','mAx');
cla(m)
i=size(M_assignment,2);
j=size(M_assignment,1);
set(m,'XTick',[0:1/i:1],'YTick',[0:1/j:1]);
for k=1:length(path)
    [a b]=find(M_assignment==path(k));
    x=(b-1)*(1/i);y=(a-1)*(1/j);
    patch([x,x+1/i,x+1/i,x,x],[y,y,y+1/j,y+1/j,y],'r');
end

%display the returned similarity values in the table
t=findobj('Tag','tab');
d=get(t,'Data');
for i=1:5
   d{i,2}=rv(i); 
end
set(t,'Data',d);