function [d, pairs] =getLinearDistance(sp1,sp2)
%GETLINEARDISTANCE.M
%Returns the average linear distance between fixations in each scanpath
%[d, pairs] = getLinearDistance(sp1,sp2)
%
%     d = getLinearDistance(sp1,sp2) compares each fixation in sp1 with the
%     closest one in sp2 (and vice versa). Both should be N x 2 or N x 3 
%     matrices. Returns d, the average distance, in pixels.
%
%     [d, pairs] = getLinearDistance(...) also returns a matrix giving the
%     indexes of the matching pairs between sp1 and sp2.

%get a matrix of inter-fixation distances
for i=1:size(sp1,1)
    for j=1:size(sp2,1)
        dM(i,j) = sqrt( ( (sp1(i,1) - sp2(j,1) )^2 ) + ( (sp1(i,2) - sp2(j,2) )^2 ) );
    end
end

%find the lowest in each COLUMN, giving the closest match between fixations
[y,i]=min(dM);
d1 = mean(y);

%find the lowest in each ROW, giving the closest match between fixations
[y,i]=min(dM');
d2 = mean(y);

%linear distance is the mean of the distances
d=mean([d1,d2]);

%return a matrix showing the matching pairs if necessary
if nargout==2
    pairs=[1:size(sp1,1);i];
end

