function demo(sp1,sp2)
%DEMO.M
%Demonstration of scanpath comparison functions
% 
% demo() asks the user to click to select two scanpaths with 5 fixations, before choosing which comparison method to use
% 
% demo(sp1,sp2) provides the scanpaths as N x 2 or N x 3 matrices.

%this bit enables a better plotter in octave on my system
try
	graphics_toolkit fltk
	figure
end

if nargin==2 %we have scanpaths provided

    p{1}=sp1;
    p{2}=sp2;
    
else %ask user to click and choose

    gridYX=[5 5];
    imsize=[768 1024];
    cols='rb';

    %make an axis and draw the grid
    axis;
    box on
    grid on
    axis ij
    set(gca,'XLim',[0 imsize(2)],'YLim',[0 imsize(1)],...
        'XTick',0:imsize(2)/gridYX(2):imsize(2),...
        'YTick',0:imsize(1)/gridYX(1):imsize(1));
    hold on

    %ask for user to define the scanpaths
    n=5;
    for scanpath=1:2
        p{scanpath}=zeros(5,2);
       for fixation=1:n
           title(['Click to place Scanpath ',int2str(scanpath),', Fixation ',int2str(fixation),'...'])
           disp(['Click to place Scanpath ',int2str(scanpath),', Fixation ',int2str(fixation),'...'])
           waitforbuttonpress
           xy=get(gca,'CurrentPoint');
           p{scanpath}(fixation,:) = xy(1,1:2);
           plot(xy(1,1),xy(1,2),[cols(scanpath),'x'])
       end
    end

end

%plot them more nicely
plotScanpaths(p{1},p{2})

%carry on til we want to finish, allowing us to run multiple methods on the
%same scanpaths
carryon=1;
while carryon

    %ask user which type of comparison to run...
    title('Waiting for comparison choice...')
    disp(' ')
    i=input('***Which type of comparison would you like to try?\ntype 1 (LinearDistance), 2 (UniqueAssignment), 3 (StringEdit)\n..or press any other key to finish...','s');
    disp(' ')

    switch i
        case '1'
            %Linear distance comparison
            disp('Using Linear Distance comparison...')
            d=getLinearDistance(p{1},p{2})
            
            %compare to randomly generated scanpaths (easy to do in advance
            %with makeRandomScanpaths etc)
            m=221; sd=55;
            disp('The mean (SD) linear distance between randomly-generated scanpaths of this size is 221 (55)')
            sim= (1-(d/m)) * 100;
            disp(['This gives a similarity score of ',num2str(sim),' out of 100'])
            disp(' ')
            
        case '2'
            %Unique assignment version
            disp('Using Unique Assignment comparison...')
            d=getUniqueAssignmentDistance(p{1},p{2})
            
            %compare to randomly generated scanpaths (easy to do in advance
            %with makeRandomScanpaths etc)
            m=298; sd=81;
            disp('The mean (SD) unique assignment distance between randomly-generated scanpaths of this size is 298 (81)')
            sim= (1-(d/m)) * 100;
            disp(['This gives a similarity score of ',num2str(sim),' out of 100'])            
            disp(' ')
            
        case '3'
            %string edit version
            disp('Using String Edit comparison...')
            [d, string]=getStringEditDistance(p{1},p{2},[],[],1);
            d
            disp(['String A: ',string{1}'])
            disp(['String B: ',string{2}'])
            edits=d*5;
            disp(['Transforming one string into the other requires ',int2str(edits),' edits']) 
            sim=1-d;
            disp(['The similarity score is ',num2str(sim),' out of 1']) 
            m=0.049; sd=0.096;
            disp('The mean (SD) string edit similarity between randomly-generated scanpaths of this size is 0.049 (0.096)')            
            disp(' ')
            
        otherwise
            disp('Finishing...')
            disp(' ')
            carryon=0;
            close(gcf)
    end

end
