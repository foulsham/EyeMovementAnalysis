%DEMOMULTIMATCH
%a script to demonstrate running MultiMatch

%add the ScanMatch folder to the current path
addpath MultiMatchToolbox

%load some example data
load MultiMatch_DataExample

%run demo GUI
demoGUI(data1,data2)
