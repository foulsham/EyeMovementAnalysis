function sp=makeRandomScanpath(N,imsize)
%MAKERANDOMSCANPATH.M
%make a random N x 3 matrix representing a scanpath
%sp = makeRandomScanpath(N, imsize)
%
%   sp = makeRandomScanpath(N) returns an N x 3 matrix giving x, y and
%   duration values. x values are drawn randomly from [0:1024], y values
%   from [0:768] and durations from [100:500].
%
%   sp = makeRandomScanpath(N, imsize) uses the [rows columns] size in
%   imsize to limit x and y values.

if nargin==1
    imsize = [768 1024];
end

sp=rand(N,3);
sp(:,1)=sp(:,1).*imsize(2);
sp(:,2)=sp(:,2).*imsize(1);
sp(:,3)=100 + sp(:,3).*400;
