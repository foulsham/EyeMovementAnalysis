function getMovingIA(xDim,yDim)

%GETMOVINGIA(xdim,ydim)
%Store the coordinates for an area of interest which moves during a video
%clip.  
%re-written to work with mmread which is much better at reading different
%codecs
%   Dims are the dimensions of the IA in the form
%   x,y
%returns an m x 2 array where the two columns are x,y coordinates of the
%centrepoint of the IA and m is the number of frames.

%add the subdirectory to the path so that we can call mmread
addpath(fullfile(cd,'EXT'));

%check for arguments
if nargin<2
    disp('ERROR: please give dimensions of the region')
    return
end

%ask for the movie
[FileName,PathName,FilterIndex] = uigetfile('*.avi','Choose the video file');

if FileName==0
    return
end

disp('Attempting to load frames...')
disp('NB: this may take a while!')

%load the video
%now requires MMREAD function available from MATLAB file exchange
v=mmread([PathName,FileName],[],[],false,true);
numFrames = v.nrFramesTotal;
dims=[v.width,v.height];
t=0;

%check for loading errors
if numFrames<1 || dims(1)<1 || dims(2)<1
   disp('ERROR: problem loading video') 
   return
end

%let the user know it worked
%failsafe for large files?
disp(['Loaded ',int2str(numFrames),' frames from movie file!'])

%start the figure
figure('Units','pixels','Position',[0 0 dims],'WindowButtonMotionFcn',@wbmcb,...
    'WindowButtonDownFcn',@wbdcb,'CloseRequestFcn',@finishUp);
axHandle=axes('Units','pixels','Position',[0 0 dims]);
currentFrame=v.frames(1).cdata;
imHandle=image('Parent',axHandle,'CData',currentFrame);
axis(axHandle,'image','ij');
hold on 

%preallocate the return array
set(gcf,'UserData',zeros(numFrames,2));

%location of the box centre
tl=[1 1];
%plot the ia box (starting at 1,1)
x=[tl(1,1)-(xDim/2),tl(1,1)+(xDim/2),tl(1,1)+(xDim/2),tl(1,1)-(xDim/2),tl(1,1)-(xDim/2)];
y=[tl(1,2)-(yDim/2),tl(1,2)-(yDim/2),tl(1,2)+(yDim/2),tl(1,2)+(yDim/2),tl(1,2)-(yDim/2)];
plotHandle=plot(axHandle,x,y);

%control the frames with a timer
t = timer('TimerFcn',@timercallback, 'Period', 0.05,...
        'ExecutionMode','fixedDelay','StartDelay',0.05,...
        'TasksToExecute',numFrames);
    
%display one frame at a time
f=1;

    function timercallback(obj,event)
        disp(['Frame: ',int2str(f)])
        %draw the image
        if f<numFrames
        currentFrame=v.frames(f).cdata;
        set(imHandle,'CData',currentFrame);

        %store the current position before moving on
        %may not cope with rapid motion very well
        temp=get(gcf,'UserData');
        temp(f,1)=tl(1,1);
        temp(f,2)=tl(1,2);
        set(gcf,'UserData',temp);
        
        f=f+1;
        else
            stop(t)
            disp('End of video!')
            close all
        end
    end

    %function callback executed every time mouse is moved
    function wbmcb(src,evnt)
       tl = get(axHandle,'CurrentPoint');
        x=[tl(1,1)-(xDim/2),tl(1,1)+(xDim/2),tl(1,1)+(xDim/2),tl(1,1)-(xDim/2),tl(1,1)-(xDim/2)];
        y=[tl(1,2)-(yDim/2),tl(1,2)-(yDim/2),tl(1,2)+(yDim/2),tl(1,2)+(yDim/2),tl(1,2)-(yDim/2)];
       set(plotHandle,'XData',x,'YData',y);drawnow
    end

    function wbdcb(src,evnt)
       %toggle playing
        p=strcmp(get(t,'Running'),'on');
        if p
            stop(t); 
            disp('Paused')          
        else
            start(t);
            disp('Playing')
        end 
    end

    function finishUp(src,evnt)
                disp('Closing...')
    if exist('t','var')
    stop(t);
    delete(t);
    end
    rv=get(gcf,'UserData');
    assignin('base','ans',rv);
    %ask for the output filename
    [FileName,PathName,FilterIndex] = uiputfile('*.txt','Choose a place to save the data....');
    if FileName~=0
        dlmwrite([PathName,FileName],rv,'\t');
    end    
    delete(gcf);
    end
end



